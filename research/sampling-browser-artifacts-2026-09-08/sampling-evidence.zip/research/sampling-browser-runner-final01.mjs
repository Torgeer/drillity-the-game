#!/usr/bin/env node
// Real native DOM sampling workflow and native document/storage reload.
// This is a DOM/simulation acceptance harness, not WebGL, FPS or phone evidence.
import assert from 'node:assert/strict';
import { build } from 'esbuild';
import { chromium } from 'playwright';
import { createServer } from 'node:http';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const arg = (name, fallback) => { const i = process.argv.indexOf('--' + name); return i < 0 ? fallback : process.argv[i + 1]; };
const port = Number(arg('port', '5252')), lease = arg('lease', 'sampling-browser');
assert(![5178, 5180].includes(port), 'Protected user ports');
const output = resolve(root, arg('output', 'evidence/sampling-browser'));
const index = await readFile(resolve(root, 'index.html'), 'utf8');
const fonts = [...index.matchAll(/<link\b[^>]*href="https:\/\/fonts\.(?:googleapis|gstatic)\.com[^>]*>/g)].map(m => m[0]).join('\n');
assert.match(fonts, /family=Inter.*family=Oswald/);
const bundle = await build({ absWorkingDir: root, entryPoints: ['tools/fixtures/sampling-browser.js'], bundle: true,
  format: 'esm', write: false, outdir: 'unused-sampling-output', metafile: true, loader: { '.png': 'dataurl' }, logLevel: 'silent' });
const js = bundle.outputFiles.find(f => f.path.endsWith('.js')).contents;
const css = bundle.outputFiles.find(f => f.path.endsWith('.css')).contents;
const digest = async path => createHash('sha256').update(await readFile(resolve(root, path))).digest('hex');
const paths = [...Object.keys(bundle.metafile.inputs), 'tools/checksampling-browser.mjs', 'index.html'];
const hashes = Object.fromEntries(await Promise.all(paths.map(async path => [path, await digest(path)])));
if (process.argv.includes('--prepare-only')) {
  console.log(JSON.stringify({ status: 'PREPARED_NOT_RUN', sourceHashes: hashes })); process.exit(0);
}
assert.equal((await readFile(resolve(root, '../drillity-coordination/gpu-owner.txt'), 'utf8')).trim(), lease, 'Coordinator browser lease required');
const report = { schema: 'sampling-browser-v1', startedAt: new Date().toISOString(), status: 'RUNNING', sourceHashes: hashes,
  scope: 'Native desktop Chrome, 390x844 and 320x568 portrait DOM. Real shell/Site/Results/progression/sim/geology query modules and native localStorage. Explicit resource/XP setup, actual purchases, canonical public board tenders and native acceptance/sampling actions. Repeated unmodified1/60 simulation updates; at most20 deliberately adverse drilling-phase seconds in the first interval, then public optimal controls/rod timing. Exposure is genuinely produced, never injected. No renderer, WebGL, naturally earned career, material-recovery quality, phone or performance claim. Sonic dimensional compatibility remains unverified.',
  methods: [], errors: [], warnings: [], requestFailures: [], navigations: [], documentsServed: 0 };
let browser, context, activeMethod;
const server = createServer((req, res) => {
  if (req.url === '/fixture.js') { res.setHeader('Content-Type', 'text/javascript'); res.end(js); }
  else if (req.url === '/fixture.css') { res.setHeader('Content-Type', 'text/css'); res.end(css); }
  else if (req.url === '/favicon.ico') { res.writeHead(204); res.end(); }
  else if (req.url?.startsWith('/?method=')) {
    report.documentsServed++; res.setHeader('Content-Type', 'text/html');
    res.end('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="icon" href="data:,">'
      + fonts + '<link rel="stylesheet" href="/fixture.css"><title>Sampling acceptance</title><body><div id="ui"></div><script type="module" src="/fixture.js"></script></body></html>');
  } else { res.writeHead(404); res.end('Unknown fixture resource'); }
});
const snap = async (page, name) => {
  // Site intentionally paints telemetry at 8 Hz; retain its rendered state,
  // not a stale DOM read immediately after an accelerated simulation step.
  await page.waitForTimeout(140);
  await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
  const state = await page.evaluate(name => samplingFixture.snapshot(name), name);
  activeMethod.snapshots.push(state); return state;
};
const equalProduct = (a, b, message) => assert.deepEqual(a.drill.sampleProduct, b.drill.sampleProduct, message);
const receipts = s => s.career.receipts.length;
const advance = (page, options) => page.evaluate(options => samplingFixture.advance(options), options);
const escaped = label => label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
async function ready(page, scene) {
  await page.waitForFunction(() => !!window.samplingFixture, null, { timeout: 60000 });
  await page.waitForFunction(expected => samplingFixture.snapshot('ready').scene === expected, scene);
  const loaded = await page.evaluate(async () => {
    await Promise.all([document.fonts.load('700 13px Inter', 'Sampling receipt'), document.fonts.load('700 13px Oswald', 'SAMPLING')]);
    await document.fonts.ready;
    return [...document.fonts].filter(f => f.status === 'loaded').map(f => f.family.replace(/["']/g, ''));
  });
  assert(loaded.includes('Inter') && loaded.includes('Oswald'), 'Actual production fonts loaded');
  assert.deepEqual(await page.evaluate(() => webglAttempts), []);
}
async function geometry(page, name, selector = 'button.railbtn:not([hidden])') {
  const rows = await page.locator(selector).evaluateAll(elements => elements.filter(el => el.getClientRects().length).map(el => {
    const r = el.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2;
    const hit = document.elementFromPoint(x, y);
    const textRects = [], walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
    for (let node = walker.nextNode(); node; node = walker.nextNode()) if (node.textContent.trim()) {
      const range = document.createRange(); range.selectNodeContents(node);
      for (const line of range.getClientRects()) if (line.width && line.height) textRects.push({ left: line.left, right: line.right, top: line.top, bottom: line.bottom });
    }
    const paintedNotifications = [...document.querySelectorAll('.toast,[role="alert"]')].filter(notice => {
      if (!notice.getClientRects().length || notice.contains(el) || el.contains(notice)) return false;
      for (let node = notice; node; node = node.parentElement) {
        const s = getComputedStyle(node); if (s.display === 'none' || s.visibility === 'hidden' || Number(s.opacity) === 0) return false;
      }
      return true;
    }).map(notice => { const q = notice.getBoundingClientRect(); return { text: notice.innerText,
      x: q.x, y: q.y, width: q.width, height: q.height,
      intersects: Math.min(r.right,q.right)-Math.max(r.left,q.left)>1 && Math.min(r.bottom,q.bottom)-Math.max(r.top,q.top)>1 }; });
    return { text: el.innerText, disabled: !!el.disabled, x: r.x, y: r.y, width: r.width, height: r.height,
      inViewport: r.left >= -.5 && r.top >= -.5 && r.right <= innerWidth + .5 && r.bottom <= innerHeight + .5,
      labelClipped: textRects.some(q => q.left < r.left-.5 || q.right > r.right+.5 || q.top < r.top-.5 || q.bottom > r.bottom+.5),
      textRects, paintedNotifications, hit: hit === el || el.contains(hit) };
  }));
  activeMethod.geometry.push({ name, rows });
  assert(rows.length > 0, 'Geometry gate needs real visible targets: ' + name);
  for (const r of rows) {
    assert(r.width >= 43.99 && r.height >= 43.99, name + ': 44px target ' + JSON.stringify(r));
    assert(r.inViewport, name + ': target inside viewport ' + JSON.stringify(r));
    assert(!r.labelClipped, name + ': label fits its target ' + JSON.stringify(r));
    assert(!r.paintedNotifications.some(notice => notice.intersects), name + ': painted notification overlaps target ' + JSON.stringify(r));
    if (!r.disabled) assert(r.hit, name + ': native target is unobscured ' + JSON.stringify(r));
  }
  for (let i = 0; i < rows.length; i++) for (let j = i + 1; j < rows.length; j++) {
    const a = rows[i], b = rows[j];
    assert(!(Math.min(a.x+a.width,b.x+b.width)-Math.max(a.x,b.x)>1
      && Math.min(a.y+a.height,b.y+b.height)-Math.max(a.y,b.y)>1), name + ': targets overlap');
  }
}
async function capture(page, name) {
  const path = resolve(output, activeMethod.methodId + '-' + name + '.png');
  await page.screenshot({ path, fullPage: false }); activeMethod.screenshots.push({ name, path });
}
async function sampleTextGeometry(page, name) {
  const record = await page.locator('.unitcard:not([hidden])').evaluate(card => {
    const rect = node => { const r = node.getBoundingClientRect(); return { x:r.x,y:r.y,width:r.width,height:r.height }; };
    const blocks = [...card.querySelectorAll('.unitcard__t,.ucell__k,.ucell__v,.unitcard__n')]
      .filter(el => el.getClientRects().length).map(el => {
        const lines=[],walker=document.createTreeWalker(el,NodeFilter.SHOW_TEXT);
        for(let node=walker.nextNode();node;node=walker.nextNode()) {
          const range=document.createRange();range.selectNodeContents(node);
          for(const r of range.getClientRects()) if(r.width&&r.height) lines.push({x:r.x,y:r.y,width:r.width,height:r.height});
        }
        return {text:el.innerText,className:el.className,rect:rect(el),container:rect(el.parentElement),lines,
          lineClamp:getComputedStyle(el).webkitLineClamp,overflow:getComputedStyle(el).overflow};
      });
    return {viewport:{width:innerWidth,height:innerHeight},card:rect(card),blocks};
  });
  activeMethod.noteGeometry.push({name,...record});
  for(const block of record.blocks) for(const line of block.lines) assert(line.x >= block.rect.x-.5
    && line.x+line.width <= block.rect.x+block.rect.width+.5 && line.y >= block.rect.y-.5
    && line.y+line.height <= block.rect.y+block.rect.height+.5, name+': actual Site text is not clipped: '+block.text);
}
async function operatingRows(page, name, expectedCount) {
  const records = page.locator('.results details .spec').filter({ has: page.locator('dt', { hasText: /^Operating record$/ }) });
  assert.equal(await records.count(), expectedCount, 'Every settled interval renders its operating record');
  const rows = await records.evaluateAll(elements => elements.map(el => {
    const key = el.querySelector('dt'), value = el.querySelector('dd');
    const rect = node => { const r = node.getBoundingClientRect(); return { x:r.x,y:r.y,width:r.width,height:r.height }; };
    const lines = [], walker = document.createTreeWalker(value, NodeFilter.SHOW_TEXT);
    for (let node=walker.nextNode();node;node=walker.nextNode()) {
      const range=document.createRange();range.selectNodeContents(node);
      for(const r of range.getClientRects()) if(r.width&&r.height) lines.push({x:r.x,y:r.y,width:r.width,height:r.height});
    }
    return { text:value.innerText,row:rect(el),key:rect(key),value:rect(value),lines };
  }));
  for (const row of rows) {
    assert(row.row.x >= -.5 && row.row.x+row.row.width <= page.viewportSize().width+.5, name+': condition row fits width');
    assert(row.key.x+row.key.width <= row.value.x+.5, name+': condition label and value do not overlap');
    for(const line of row.lines) assert(line.x >= row.value.x-.5 && line.x+line.width <= row.value.x+row.value.width+.5
      && line.y >= row.value.y-.5 && line.y+line.height <= row.value.y+row.value.height+.5, name+': full condition value wraps without clipping');
  }
  const maximum = rows.reduce((max,row,i) => row.text.length > rows[max].text.length ? i : max,0);
  await records.nth(maximum).scrollIntoViewIfNeeded();
  activeMethod.conditionGeometry.push({ name, rows, maximum });
  await snap(page,name); await capture(page,name);
}
async function nativeSample(page, before, action) {
  const operation = { action: action.id, label: action.label, before: before.name };
  activeMethod.operations.push(operation);
  await geometry(page, before.name);
  await page.getByRole('button', { name: new RegExp('^' + escaped(action.label) + '$', 'i') }).click();
  const started = await snap(page, before.name + ':started'); operation.started = started.name;
  assert.match(started.drill.phase, /^sample-(case|retrieve|handle)$/);
  const beatText = action.id === 'sampleCase' ? 'Advancing casing'
    : action.id === 'sampleRetrieve' ? (activeMethod.methodId === 'core' ? 'Retrieving inner tube' : 'Extracting barrel')
      : activeMethod.methodId === 'core' ? 'Boxing and logging' : 'Sleeving and labelling';
  assert(started.ui.text.includes(beatText), 'Actual timed operation notification renders: ' + beatText);
  equalProduct(started, before, 'Starting an operation cannot create a completed receipt');
  assert.equal(receipts(started), receipts(before)); assert.equal(started.career.money, before.career.money);
  const repeat = await page.evaluate(id => samplingFixture.rejectPulse(id), action.id);
  const repeated = await snap(page, before.name + ':repeat-rejected');
  operation.repeat = { result: repeat, snapshot: repeated.name };
  assert.equal(repeat.ok, false); equalProduct(repeated, started, 'Repeat pulse must not complete operation');
  const early = await advance(page, { count: 30, stop: 'none' });
  assert.equal(early.iterations, 30);
  const underway = await snap(page, before.name + ':underway'); operation.underway = underway.name;
  equalProduct(underway, before, 'Operation needs its actual duration');
  assert.equal(receipts(underway), receipts(before)); assert.equal(underway.career.money, before.career.money);
  assert((await advance(page, { stop: 'phase-change' })).stopped, 'Timed operation completed naturally');
  const completed = await snap(page, before.name + ':completed'); operation.completed = completed.name;
  assert.equal(completed.drill.sampleProduct.lastEvent.type, { sampleCase: 'case', sampleRetrieve: 'retrieve', sampleHandle: 'handle' }[action.id]);
  assert.equal(completed.drill.sampleProduct.lastEvent.sequence, before.drill.sampleProduct.lastEvent.sequence + 1);
  if (completed.drill.active && action.id !== 'sampleCase') {
    const card = page.locator('.unitcard:not([hidden])'); await card.waitFor({ state: 'visible' });
    const cardText = await card.innerText(); operation.notification = cardText;
    assert.match(cardText, /Material recovery\s+Unmeasured/);
    assert.match(cardText, /Operating record \(play time\):/);
    assert.match(cardText, activeMethod.methodId === 'core'
      ? (action.id === 'sampleRetrieve' ? /Inner tube retrieved/ : /Core boxed and logged/)
      : (action.id === 'sampleRetrieve' ? /Barrel extracted/ : /Sample sleeved and labelled/));
    await geometry(page, before.name + ':sample-card', '.unitcard:not([hidden])');
    if (!activeMethod.screenshots.some(s => s.name === action.id + '-card')) await capture(page, action.id + '-card');
    if(cardText.length > (activeMethod.longestCard?.length || 0)) {
      const priorViewport=page.viewportSize();
      const name='site-longest-condition-'+activeMethod.operations.length+'-320';
      activeMethod.longestCard={length:cardText.length,operation:activeMethod.operations.length,text:cardText,name};
      await page.setViewportSize({width:320,height:568});
      await snap(page,name); await capture(page,name);
      await geometry(page,name,'.unitcard:not([hidden])'); await sampleTextGeometry(page,name);
      await page.setViewportSize(priorViewport);
    }
    await card.click();
    const dismissed = await snap(page, before.name + ':card-dismissed'); operation.dismissed = dismissed.name;
    equalProduct(dismissed, completed, 'Native notification dismissal cannot alter sample evidence');
  }
  return completed;
}
async function waitBarrier(page, name) {
  assert((await advance(page, {})).stopped, 'Reached real sampling boundary before step limit');
  const s = await snap(page, name);
  assert(s.drill.active, 'Attempt must remain active until final handling');
  assert.equal(s.drill.phase, 'sample-wait');
  assert(s.drill.actions.some(a => a.enabled && a.id.startsWith('sample')));
  return s;
}
try {
  await mkdir(output, { recursive: true });
  await new Promise((resolve, reject) => { server.once('error', reject); server.listen(port, '127.0.0.1', resolve); });
  browser = await chromium.launch({ channel: 'chrome', headless: true, args: ['--mute-audio'] });
  for (const methodId of ['core', 'sonic']) {
    activeMethod = { methodId, status: 'RUNNING', snapshots: [], operations: [], negatives: [], geometry: [], conditionGeometry: [], noteGeometry: [], screenshots: [] };
    report.methods.push(activeMethod);
    await context?.close();
    context = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 1, reducedMotion: 'reduce' });
    const page = await context.newPage(); page.setDefaultTimeout(10000);
    page.on('pageerror', error => report.errors.push({ methodId, error: error.message }));
    page.on('console', msg => { if (['error','warning'].includes(msg.type())) report[msg.type() === 'error' ? 'errors' : 'warnings'].push({ methodId, text: msg.text() }); });
    page.on('requestfailed', req => report.requestFailures.push({ methodId, url: req.url(), error: req.failure()?.errorText }));
    page.on('framenavigated', frame => { if (frame === page.mainFrame()) report.navigations.push({ methodId, url: frame.url() }); });
    await page.addInitScript(() => {
      const original = HTMLCanvasElement.prototype.getContext; window.webglAttempts = [];
      HTMLCanvasElement.prototype.getContext = function(type, ...args) {
        if (/webgl/i.test(type)) { webglAttempts.push(type); throw Error('Sampling DOM acceptance forbids WebGL'); }
        return original.call(this, type, ...args);
      };
    });
    await page.goto(`http://127.0.0.1:${port}/?method=${methodId}&mute`, { waitUntil: 'networkidle' });
    await ready(page, 'contracts');
    const board = await snap(page, 'board'); activeMethod.contract = board.setup.board.contract;
    if (methodId === 'core') assert.equal(activeMethod.contract.holeDia, 75.7, 'Actual supported NQ nominal tender');
    await page.locator(`[data-contract-id="${activeMethod.contract.id}"]`).click();
    await page.getByRole('button', { name: 'Accept contract', exact: true }).waitFor();
    await snap(page, 'offer-detail');
    await page.getByRole('button', { name: 'Accept contract', exact: true }).click();
    await page.waitForFunction(() => samplingFixture.snapshot('s').scene === 'site');
    const accepted = await snap(page, 'accepted');
    assert.equal(accepted.career.pending.id, activeMethod.contract.id);
    for (const [key, value] of Object.entries(activeMethod.contract)) assert.deepEqual(accepted.career.pending[key], value, 'Unchanged actual tender field ' + key);
    assert.equal(accepted.drill.depth, 0); assert(accepted.drill.geologyProfile.length > 0);
    assert.equal(receipts(accepted), 0);
    const wrong = await page.evaluate(() => samplingFixture.rejectPulse('sampleHandle'));
    const wrongAfter = await snap(page, 'drilling-wrong-phase');
    assert.equal(wrong.ok, false); equalProduct(wrongAfter, accepted, 'Wrong phase cannot forge handling');
    activeMethod.negatives.push({ type: 'wrong-phase', before: accepted.name, after: wrongAfter.name, result: wrong });
    let barrier = await waitBarrier(page, 'first-capacity');
    await capture(page, 'first-capacity-390');
    await page.setViewportSize({ width: 320, height: 568 });
    await geometry(page, 'first-capacity-320'); await snap(page, 'first-capacity-320'); await capture(page, 'first-capacity-320');
    await page.setViewportSize({ width: 390, height: 844 });
    const held = await advance(page, { count: 360, stop: 'none' }); assert.equal(held.iterations, 360);
    const hold = await snap(page, 'first-capacity-held');
    equalProduct(hold, barrier, 'Six simulated seconds cannot overfill waiting barrel');
    assert.equal(hold.drill.depth, barrier.drill.depth); assert.equal(receipts(hold), 0);
    activeMethod.negatives.push({ type: 'capacity-hold', before: barrier.name, after: hold.name });
    // Complete the first barrel using only native sample actions, then reload
    // its genuine pending run. Restart-on-reload means a new attempt at zero.
    for (let op = 0; op < 3; op++) {
      const action = barrier.drill.actions.find(a => a.enabled && a.id.startsWith('sample'));
      const done = await nativeSample(page, barrier, action);
      if (action.id === 'sampleHandle') { barrier = done; break; }
      barrier = await waitBarrier(page, 'restart-barrel-' + op);
    }
    assert(barrier.drill.programme.summary.handledIntervalM > 0); assert.equal(receipts(barrier), 0);
    assert.equal(await page.evaluate(() => samplingFixture.save()), true);
    const beforeReload = await snap(page, 'pending-before-reload');
    await page.reload({ waitUntil: 'networkidle' }); await ready(page, 'menu');
    const loadedPending = await snap(page, 'pending-loaded-menu');
    assert.notEqual(loadedPending.documentId, beforeReload.documentId); assert.equal(loadedPending.navigationType, 'reload');
    assert.equal(loadedPending.career.pending.id, activeMethod.contract.id); assert.equal(receipts(loadedPending), 0);
    await page.getByRole('button', { name: /^(Continue|Play|Resume)/i }).click();
    await page.waitForFunction(() => samplingFixture.snapshot('s').scene === 'site');
    const restart = await snap(page, 'pending-restarted');
    assert.equal(restart.drill.depth, 0); assert.equal(restart.drill.sampleProduct.intervals.length, 0);
    assert.notEqual(restart.drill.attemptId, beforeReload.drill.attemptId);
    activeMethod.pendingReload = { before: beforeReload.name, loaded: loadedPending.name, restarted: restart.name };
    const settlementBaseline = restart.career.money;
    let finalBefore, settled;
    for (let operation = 0; operation < 1500; operation++) {
      barrier = await waitBarrier(page, 'operation-' + operation);
      const action = barrier.drill.actions.find(a => a.enabled && a.id.startsWith('sample'));
      const final = action.id === 'sampleHandle' && barrier.drill.programme.summary.targetReached;
      if (final) {
        finalBefore = barrier;
        assert.equal(barrier.drill.programme.summary.finalPartialPending, true, 'Real tender ends in a partial barrel');
        assert.equal(receipts(barrier), 0); assert.equal(barrier.career.money, settlementBaseline);
        await advance(page, { count: 360, stop: 'none' });
        const finalHeld = await snap(page, 'final-handling-held');
        equalProduct(finalHeld, barrier, 'Final partial barrel cannot pay before handling');
        assert.equal(receipts(finalHeld), 0); assert.equal(finalHeld.career.money, settlementBaseline);
        activeMethod.negatives.push({ type: 'final-handling-gate', before: barrier.name, after: finalHeld.name });
        await page.setViewportSize({ width: 320, height: 568 });
        await geometry(page, 'final-handling-320'); await snap(page, 'final-handling-320'); await capture(page, 'final-handling-320');
      }
      const done = await nativeSample(page, barrier, action);
      if (final) { settled = done; break; }
      assert.equal(receipts(done), 0); assert.equal(done.career.money, settlementBaseline);
    }
    assert(finalBefore && settled, 'Real canonical tender completed within operation bound');
    await page.waitForFunction(() => samplingFixture.snapshot('s').scene === 'results');
    assert.equal(settled.drill.active, false); assert.equal(receipts(settled), 1);
    assert.equal(settled.completions.length, 1); assert.equal(settled.career.pending, null);
    assert.deepEqual(settled.career.receipts[0].sampleProduct, settled.drill.sampleProduct);
    assert.equal(settled.career.money - settlementBaseline, settled.career.receipts[0].net);
    assert(settled.drill.sampleProduct.intervals.every(row => row.operatingConditions?.cuttingSec > 0), 'Every cut interval carries actual operating observations');
    assert(settled.drill.sampleProduct.intervals.some(row => methodId === 'core' ? row.operatingConditions.lowFlushSec > 0
      : row.operatingConditions.overheatSec > 0 || row.operatingConditions.overtorqueSec > 0), 'Deliberately adverse public controls produced a real exposure label');
    await page.setViewportSize({ width: 390, height: 844 });
    const summary = page.getByText('View sample interval log', { exact: true });
    await summary.scrollIntoViewIfNeeded(); await summary.click();
    await geometry(page, 'results-log-summary', 'summary');
    const results = await snap(page, 'results-expanded');
    assert.match(results.ui.text, /Material recovery\s+Unmeasured/);
    assert.match(results.ui.text, methodId === 'core' ? /boxed intervals/ : /sleeved intervals/);
    assert.match(results.ui.text, methodId === 'core' ? /Inner tube capacity/ : /Sampling run limit/);
    assert.match(results.ui.text, /Operating limits\s+Game thresholds; material condition is unmeasured/);
    assert.match(results.ui.text, /drilling play time/);
    assert.match(results.ui.text, /1\.\s*|Box 1|Sleeve 1/);
    await capture(page, 'results-expanded-390');
    await operatingRows(page,'results-maximum-condition-390',settled.drill.sampleProduct.intervals.length);
    await page.setViewportSize({ width: 320, height: 568 }); await summary.scrollIntoViewIfNeeded();
    await geometry(page, 'results-log-summary-320', 'summary'); await snap(page, 'results-expanded-320'); await capture(page, 'results-expanded-320');
    await operatingRows(page,'results-maximum-condition-320',settled.drill.sampleProduct.intervals.length);
    activeMethod.immutable = await page.evaluate(() => samplingFixture.immutableReceipt());
    assert.equal(activeMethod.immutable.before, activeMethod.immutable.after);
    assert(activeMethod.immutable.frozen && activeMethod.immutable.nestedFrozen);
    assert.deepEqual(activeMethod.immutable.attempts, ['TypeError', 'TypeError', 'TypeError']);
    assert.equal(await page.evaluate(() => samplingFixture.save()), true);
    const beforeReceiptReload = await snap(page, 'receipt-before-reload');
    const storedReceipts = JSON.parse(beforeReceiptReload.career.storageRaw).player.career.ledger;
    assert.deepEqual(storedReceipts, beforeReceiptReload.career.receipts);
    await page.reload({ waitUntil: 'networkidle' }); await ready(page, 'menu');
    const loadedReceipt = await snap(page, 'receipt-loaded-menu');
    assert.notEqual(loadedReceipt.documentId, beforeReceiptReload.documentId); assert.equal(loadedReceipt.navigationType, 'reload');
    assert.deepEqual(loadedReceipt.career.receipts, beforeReceiptReload.career.receipts);
    assert.equal(loadedReceipt.career.money, beforeReceiptReload.career.money);
    assert.equal(loadedReceipt.career.pending, null);
    activeMethod.receiptReload = { before: beforeReceiptReload.name, loaded: loadedReceipt.name,
      beforeReceiptBytes: JSON.stringify(storedReceipts), afterReceiptBytes: JSON.stringify(JSON.parse(loadedReceipt.career.storageRaw).player.career.ledger) };
    assert.equal(activeMethod.receiptReload.beforeReceiptBytes, activeMethod.receiptReload.afterReceiptBytes);
    activeMethod.finalHandling = { before: finalBefore.name, settled: settled.name, results: results.name };
    activeMethod.status = 'PASS'; console.log('PASS ' + methodId + ': ' + activeMethod.operations.length + ' native sampling operations, actual Results, pending/settled document reloads');
  }
  assert.equal(report.methods.length, 2); assert.deepEqual(report.errors, []);
  for (const [path, hash] of Object.entries(hashes)) assert.equal(await digest(path), hash, 'Source changed during capture: ' + path);
  report.status = 'PASS';
} catch (error) {
  report.status = 'FAIL'; report.failure = error.stack;
  if (activeMethod) activeMethod.status = 'FAIL';
  const page = context?.pages()[0];
  if (page && !page.isClosed()) {
    report.failureState = await page.evaluate(() => window.samplingFixture?.snapshot('failure') || { bootstrap: window.samplingBootstrap, text: document.body.innerText }).catch(e => ({ error: String(e) }));
    await page.screenshot({ path: resolve(output, 'failure.png') }).catch(() => {});
  }
  process.exitCode = 1;
} finally {
  const cleanup = await Promise.allSettled([browser?.close(), server.listening ? new Promise((resolve, reject) => server.close(error => error ? reject(error) : resolve())) : Promise.resolve()]);
  report.cleanup = { browserClosed: !browser?.isConnected(), serverClosed: !server.listening,
    errors: cleanup.filter(r => r.status === 'rejected').map(r => String(r.reason)) };
  if (report.cleanup.errors.length || !report.cleanup.browserClosed || !report.cleanup.serverClosed) { report.status = 'FAIL'; process.exitCode = 1; }
  await mkdir(output, { recursive: true }); await writeFile(resolve(output, 'current.json'), JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify({ status: report.status, failure: report.failure, output, cleanup: report.cleanup }));
}
