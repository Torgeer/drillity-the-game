# Sampling browser acceptance — incomplete, 320 px caption truncation reproduced

The separately approved final02 retry completed the first native core retrieval, then stopped at a concrete **320×568 sample-card readability failure**. `INNER TUBE CAPACITY` and `MATERIAL RECOVERY` are visibly ellipsized. The 296×120 px card itself fits its viewport and is unobscured; its labels use `white-space: nowrap; overflow: hidden; text-overflow: ellipsis`. The material-recovery text's full range ends at x319.844 while the card ends at x308. The operating note fits two lines in this observed state.

Final02 additionally proves actual native retrieval starts without advancing its receipt, repeat requests are refused, the timed operation cannot complete early or pay, and completed retrieval adds exactly one correct ledger event. No handling, Results, real reload or sonic workflow has been accepted. The next production fix is readable captions at320 px, preserving factual capacity/recovery distinctions and44 px controls; it needs a new independently reviewed capture. **No third run or source fix was performed.**

Final02 command used output `evidence/sampling-browser-final-02`. Its runner SHA is `e949da00097c8256e656560fc30fd7b767f522e757986bdad4e832ee4a6c268f`. The only runner changes from final01 were the actual recognized accessible-name suffix and case-insensitive matching of the same expected CSS-uppercase captions. Numeric, product, receipt, timing and geometry gates were retained. Production and fixture hashes did not change.

## Preserved first attempt

The single authorized run stopped on an **author harness locator error** before its first sampling action. This is not a demonstrated production defect and does not approve the complete sampling workflow.

Command from this candidate:

```text
node tools/checksampling-browser.mjs --port 5252 --lease sampling-browser --output evidence/sampling-browser-final-01
```

The test sought a button whose entire accessible name was `RETRIEVE INNER TUBE`. The real enabled button correctly exposes `RETRIEVE INNER TUBE. Retrieval started; handling follows`. The frozen exact-name locator therefore timed out. Its actual label, accessible name, 160.359×44 px rectangle and unobscured center hit are retained in the failure snapshot. The next harness revision should identify the unique visible native action rail button by its exact visible label, or include its actual explanatory accessible name. It must preserve native clicking and all action assertions.

## Evidence achieved before the failure

- Actual public purchases/default fitting and the unchanged canonical core board tender `ct-nordic-core-36g53`, 89.5 m and **75.7 mm nominal**, reached native contract acceptance.
- Real production geology queries and simulation reached the first **1.5 m** capacity stop. Wrong-phase handling was refused; another 360 unmodified simulation updates left depth and sample evidence unchanged and produced no receipt.
- Disclosed public low-flush input produced a genuine operating record: 2.125 player/simulation seconds below the authored flush threshold. Material recovery remains unmeasured.
- The actual retrieval target passed minimum 44 px, viewport containment, native hit testing, label bounds and painted-notification intersection checks at 390×844 and 320×568. Actual Inter and Oswald fonts loaded.

No native retrieval, casing, extraction, handling, final partial barrel, Results, pending/settled reload or sonic workflow was exercised. The operation entry records an attempted test step, **not a successful click**. Longest-condition card/Results wrapping is unverified. The fixture deliberately omits the renderer; the blank stage in these DOM captures is not evidence of a game-rendering defect. Desktop Chrome is not a phone test.

## Frozen identities and cleanup

- Harness: `d4e965932d94f74f927d44cdc13b32dfa8bc00f5a5ec1c2557d427a47d601a94`.
- Fixture: `a790f8c5e652c259899e8ef3f6189ff46cd8e724128f17c4909e4d4257997d5e`.
- Final drilling source: `17c164f5cbe8f50c51e2ca0cdd312fc38944854b91076974285559f76a74b324`.
- Final composition manifest: `078101780dfe3c2b263ef7eea3dfe38c1640a587e58877c350f4ed5daf392dda`.

All 38 composed JavaScript files were independently checked against frozen MAIN before capture. The original 300-file baseline and pre-vibro composition are preserved. The run records every bundled source hash in `evidence/sampling-browser-final-01/current.json`; artifact hashes are retained in `research/sampling-browser-final-01-artifact-hashes.json`.

Both runs' finally blocks closed their browsers and HTTP servers without cleanup errors. Independent Windows listener checks confirmed port5252 free after each run, then the owned lease was returned to `idle`. The original final01 runner bytes remain at `research/sampling-browser-runner-final01.mjs`; both raw reports and all PNGs remain unchanged. No production source fix, commit or further run followed final02. Root authorized only the durable MAIN research bundle during final wind-down.
