// Actual UI/progression/simulation/geology queries in native browser storage.
// Explicit fixture resources/XP; public purchases and fitting. No phase, depth,
// receipt, success event, physical tuning, or tender mutation is permitted here.
import { createUI } from '../../src/ui/shell.js';
import { createGameState, createBus, makeRandom, SCENES, EVENTS } from '../../src/core/contract.js';
import { createProgression, SAVE_KEY, SAVE_BACKUP_KEY } from '../../src/game/progression.js';
import { createDrillSim } from '../../src/sim/drilling.js';
import { createGeology } from '../../src/world/geology.js';
import * as game from '../../src/game/data.js';

const methodId = new URL(location.href).searchParams.get('method') || 'core';
if (!['core', 'sonic'].includes(methodId)) throw Error('Unsupported sampling fixture');
const level = methodId === 'core' ? 18 : 42;
const seed = 713, marker = 'sampling-browser-seeded', metaKey = 'sampling-browser-setup';
window.samplingBootstrap = { phase: 'seed', methodId };
const clone = value => value == null ? value : JSON.parse(JSON.stringify(value));
const requireOK = (result, label) => {
  if (!result?.ok) throw Error(label + ': ' + JSON.stringify(result));
  return clone(result);
};
function context() {
  const state = createGameState(), bus = createBus();
  state.settings.reducedMotion = true; state.settings.haptics = false;
  return { state, bus, rand: makeRandom(seed), SCENES, EVENTS, game, uiRoot: document.querySelector('#ui') };
}
if (!sessionStorage.getItem(marker)) {
  const seedCtx = context();
  const seedProgression = seedCtx.progression = createProgression(seedCtx);
  await seedProgression.init();
  // These resources and XP are disclosed fixture setup, not an earned career.
  seedProgression.addMoney(100000000, 'Sampling browser fixture resources');
  seedProgression.addXP(game.LEVELS.cumulative[level - 1], 'Sampling browser fixture seniority');
  if (seedCtx.state.player.level !== level) throw Error('Fixture XP did not reach requested level');
  const purchases = [], method = game.getMethod(methodId), rigId = method.rigIds[0];
  if (!seedCtx.state.unlocked.rigs.includes(rigId)) purchases.push({ action: 'purchaseRig', id: rigId,
    result: requireOK(seedProgression.purchaseRig(rigId), 'Buy rig') });
  requireOK(seedProgression.selectRig(rigId), 'Select actual owned rig');
  const loadout = game.defaultLoadoutFor(methodId, level);
  for (const slot of Object.keys(seedCtx.state.garage.loadout)) requireOK(seedProgression.equip(slot, null), 'Remove previous ' + slot);
  for (const [slot, id] of Object.entries(loadout)) if (id) {
    if (!seedCtx.state.garage.owned.includes(id)) purchases.push({ action: 'purchase', id,
      result: requireOK(seedProgression.purchase(id), 'Buy ' + id) });
    purchases.push({ action: 'equip', slot, id, result: requireOK(seedProgression.equip(slot, id), 'Fit ' + id) });
  }
  seedProgression.requestSave();
  if (!seedProgression.save()) throw Error('Fixture resources could not be saved');
  sessionStorage.setItem(metaKey, JSON.stringify({ methodId, level, seed, purchases,
    loadout: clone(seedCtx.state.garage.loadout), seededMoney: 100000000,
    acceleration: 'Repeated unmodified sim.update(1/60); public controls and rod timing. Native sampling buttons only.',
    controlPolicy: 'First interval: at most20 drilling-phase seconds with core low flush0.01 or sonic feed/rpm1 and flush0.05, then actual optimal inputs. This deliberately produces genuine game-condition exposure for UI wrapping; no exposure record is injected.' }));
  seedProgression.dispose(); sessionStorage.setItem(marker, '1');
}
const ctx = context(), { state, bus } = ctx;
const progression = ctx.progression = createProgression(ctx);
const sim = ctx.sim = createDrillSim(ctx);
const geology = ctx.geology = createGeology(ctx);
const ui = ctx.ui = createUI(ctx);
// Match production boot: UI subscribes before simulation/progression init.
await ui.init(); sim.init(); await progression.init();
// Use the production geology's real profile/query API, without building or
// drawing section meshes. This is the shipping CONTRACT_ACCEPT mapping.
function profile(c) {
  geology.generateProfile({ regionId: c.regionId, applicationId: c.applicationId,
    targetDepth: c.targetDepth, seed: c.seed, difficulty: c.difficulty,
    holeDiaMm: c.holeDia, methodId: c.methodId, profileMode: c.profileMode,
    commodity: c.commodity ?? null, oreConfidence: c.oreConfidence });
}
bus.on(EVENTS.CONTRACT_ACCEPT, ({ contract }) => profile(contract));
if (state.contract) profile(state.contract);
const setup = JSON.parse(sessionStorage.getItem(metaKey));
let selectedContract = null;
if (!state.contract && !state.player.career.ledger.length) {
  // Select an unchanged, ordinary board offer with one hole and a final partial
  // barrel; refreshing/selecting a real board is not a synthetic short tender.
  for (let refresh = 0; refresh < 2000; refresh++) {
    const board = refresh ? progression.refreshContracts() : progression.getContracts();
    selectedContract = board.find(c => c.methodId === methodId && c.holes === 1
      && c.targetDepth % (methodId === 'core' ? 1.5 : 3) > .01
      && c.targetDepth < (methodId === 'core' ? 100 : 40)
      && progression.previewContract(c).ok);
    if (selectedContract) {
      setup.board = { refresh, ids: board.map(c => c.id), contract: clone(selectedContract) };
      sessionStorage.setItem(metaKey, JSON.stringify(setup)); break;
    }
  }
  if (!selectedContract) throw Error('No ordinary one-hole partial-barrel sampling offer found');
}
const completions = [], eventLog = [];
for (const event of [EVENTS.HOLE_COMPLETE, EVENTS.DRILL_START, EVENTS.ROD_ADDED, EVENTS.CONTRACT_ACCEPT]) {
  bus.on(event, payload => {
    eventLog.push({ event, payload: clone(payload) });
    if (event === EVENTS.HOLE_COMPLETE) completions.push(payload);
  });
}
ui.resize(innerWidth, innerHeight, devicePixelRatio);
ui.show(selectedContract ? SCENES.CONTRACTS : SCENES.MENU);
ui.setLoadingProgress(1); ui.update(3);
addEventListener('resize', () => ui.resize(innerWidth, innerHeight, devicePixelRatio));
let previous = performance.now();
function frame(now) { ui.update(Math.min(.05, (now - previous) / 1000)); previous = now; requestAnimationFrame(frame); }
requestAnimationFrame(frame);
const documentId = crypto.randomUUID();
let steps = 0, adverseSteps = 0;
function tick() {
  const telemetry = sim.getTelemetry();
  const adverse = telemetry.phase === 'drilling' && adverseSteps < 1200
    && (telemetry.programme?.intervals.length ?? 0) <= 1;
  sim.setInput('feed', adverse && methodId === 'sonic' ? 1 : telemetry.optimal.wob);
  sim.setInput('rpm', adverse && methodId === 'sonic' ? 1 : telemetry.optimal.rpm);
  sim.setInput('flush', adverse ? (methodId === 'core' ? .01 : .05) : telemetry.optimal.flush);
  if (adverse) adverseSteps++;
  if (telemetry.rodAdd && !telemetry.rodAdd.hit && telemetry.rodAdd.t >= telemetry.rodAdd.windowStart
      && telemetry.rodAdd.t <= telemetry.rodAdd.windowEnd) requireOK(sim.pulse('rodStab'), 'Actual rod timing');
  sim.update(1 / 60); steps++;
}
function visible(el) {
  if (!el.getClientRects().length) return false;
  for (let node = el; node; node = node.parentElement) {
    const style = getComputedStyle(node);
    if (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity) === 0) return false;
  }
  return true;
}
function snapshot(name) {
  const t = sim.getTelemetry();
  return { name, documentId, navigationType: performance.getEntriesByType('navigation')[0]?.type,
    steps, adverseSteps, scene: ui.currentScene, methodId, setup: clone(setup),
    run: clone(progression.run),
    drill: { active: t.active, phase: t.phase, runId: t.runId, attemptId: t.attemptId,
      depth: t.depth, targetDepth: t.target, time: t.timeSec, beat: clone(t.beat), jam: clone(t.jam),
      programme: clone(t.programme), sampleProduct: clone(state.drill.sampleProduct), actions: clone(t.actions),
      ground: clone(t.stratum), geologyProfile: clone(geology.strata) },
    career: { money: state.player.money, pending: clone(state.contract), receipts: clone(state.player.career.ledger),
      storageRaw: localStorage.getItem(SAVE_KEY), backupRaw: localStorage.getItem(SAVE_BACKUP_KEY),
      saveStatus: clone(progression.getSaveStatus()) },
    completions: clone(completions), events: clone(eventLog),
    ui: { text: document.body.innerText, viewport: { width: innerWidth, height: innerHeight },
      notifications: [...document.querySelectorAll('.toast')].filter(visible).map(el => el.innerText),
      fonts: [...document.fonts].filter(face => face.status === 'loaded').map(face => face.family.replace(/["']/g, '')),
      buttons: [...document.querySelectorAll('button,summary')].filter(visible).map(el => {
        const r = el.getBoundingClientRect(); return { text: el.innerText, label: el.getAttribute('aria-label'),
          disabled: !!el.disabled, tag: el.tagName, rect: { x: r.x, y: r.y, width: r.width, height: r.height },
          inViewport: r.left >= -.5 && r.right <= innerWidth + .5 && r.top >= -.5 && r.bottom <= innerHeight + .5 };
      }) },
  };
}
window.samplingFixture = { documentId, methodId, setup, selectedContract, snapshot,
  advance({ count = 240000, stop = 'boundary' } = {}) {
    const startPhase = sim.getTelemetry().phase;
    for (let i = 0; i < count; i++) {
      const t = sim.getTelemetry();
      if (!t.active || (stop === 'boundary' && t.actions.some(a => a.enabled && a.id.startsWith('sample')))
          || (stop === 'phase-change' && t.phase !== startPhase)) return { iterations: i, stopped: true };
      tick();
    }
    return { iterations: count, stopped: false };
  },
  rejectPulse(id) { return clone(sim.pulse(id)); },
  save() { progression.requestSave(); return progression.save(); },
  immutableReceipt() {
    const receipt = state.player.career.ledger[0];
    if (!receipt?.sampleProduct) throw Error('No genuine receipt to inspect');
    const before = JSON.stringify(receipt.sampleProduct); const attempts = [];
    for (const action of [() => { receipt.sampleProduct.drilledDepthM = -99; },
      () => { receipt.sampleProduct.intervals[0].toM = -99; },
      () => { receipt.sampleProduct.intervals.push({}); }]) {
      try { action(); attempts.push('accepted'); } catch (error) { attempts.push(error.name); }
    }
    return { before, after: JSON.stringify(receipt.sampleProduct), attempts,
      frozen: Object.isFrozen(receipt.sampleProduct), nestedFrozen: Object.isFrozen(receipt.sampleProduct.intervals[0]) };
  },
};
window.samplingBootstrap.phase = 'ready';
