#!/usr/bin/env node
/** Independent browser-evidence oracle. No production sampling validator is
 * imported and no DOM or successful gameplay event is manufactured here.
 * These functions validate retained actual-browser observations. They do not
 * certify screenshots, typography or physical-phone performance by themselves.
 */
import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { resolve } from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';

const METHODS = {
  core: { provenance: 'wireline-inner-tube', container: 'box', basis: 'inner-tube-length' },
  sonic: { provenance: 'sonic-barrel-extraction', container: 'sleeve', basis: 'gameplay-run-limit' },
};
const positiveId = value => Number.isSafeInteger(value) && value > 0;
const finite = (value, label) => assert(typeof value === 'number' && Number.isFinite(value), label);
const same = (actual, expected, label) => assert.deepEqual(actual, expected, label);

/** Operating time is recorded game exposure, not recovered material quality. */
export function assertOperatingConditions(value, methodId) {
  assert(value && typeof value === 'object', 'Actual operating conditions retained');
  same(value.version, 1, 'Known operating record version');
  same(value.basis, 'authored-simulation-thresholds', 'Operating limits are authored game thresholds');
  same(value.clock, 'player-simulation-seconds', 'Operating exposure uses play time');
  assert(positiveId(value.steps), 'Positive observed drilling steps');
  finite(value.cuttingSec, 'Recorded cutting time'); assert(value.cuttingSec > 0);
  for (const key of ['overheatSec', 'overtorqueSec', ...(methodId === 'core' ? ['lowFlushSec'] : [])]) {
    finite(value[key], key); assert(value[key] >= 0 && value[key] <= value.cuttingSec, 'Individual exposure stays within observed cutting time');
  }
  for (const key of ['heatMax', 'torqueMax', ...(methodId === 'core' ? ['effectiveFlushMin'] : [])]) {
    finite(value.limits[key], 'Recorded limit ' + key); assert(value.limits[key] > 0, 'Positive recorded game limit');
  }
  if (methodId === 'sonic') {
    same(value.lowFlushSec, null, 'Sonic has no measured low-flush exposure');
    same(value.limits.effectiveFlushMin, null, 'Sonic has no invented minimum-flush threshold');
  }
  const seconds = elapsed => elapsed > 0 && elapsed < .1 ? '<0.1 s' : `${elapsed.toFixed(1)} s`;
  const exposures = [['Low flush', value.lowFlushSec], ['Overheat', value.overheatSec], ['Over torque', value.overtorqueSec]]
    .filter(([, elapsed]) => typeof elapsed === 'number' && elapsed > 0);
  return { hasExposure: exposures.length > 0, text: exposures.length
    ? exposures.map(([label, elapsed]) => `${label} ${seconds(elapsed)}`).join(' · ')
    : `No recorded ${methodId === 'sonic' ? 'heat or torque' : 'operating-limit'} exceedance`,
    cuttingTime: seconds(value.cuttingSec) };
}

/** An independent coordinate/operation oracle; deliberately does not restore
 * through sample-ledger.js or call readSampleProduct(). */
export function assertLedgerSnapshot(product, expected = {}) {
  assert(product && typeof product === 'object', 'Actual sample product must be recorded');
  const rule = METHODS[product.methodId];
  assert(rule, 'Method is core or sonic');
  same(product.version, 1, 'Known interval record version');
  assert(positiveId(product.runId) && positiveId(product.attemptId), 'Positive run/attempt identity');
  for (const key of ['methodId', 'runId', 'attemptId', 'targetDepthM', 'barrelCapacityM']) {
    if (Object.hasOwn(expected, key)) same(product[key], expected[key], 'Expected ' + key);
  }
  for (const key of ['targetDepthM', 'barrelCapacityM', 'drilledDepthM', 'casedDepthM']) finite(product[key], key);
  assert(product.targetDepthM > 0 && product.barrelCapacityM > 0, 'Positive target and explicit capacity');
  assert(product.drilledDepthM >= 0 && product.drilledDepthM <= product.targetDepthM, 'Bore stays within target');
  assert(product.casedDepthM >= 0 && product.casedDepthM <= product.drilledDepthM, 'Casing stays within drilled bore');
  if (product.methodId === 'core') same(product.casedDepthM, 0, 'Core has no sonic casing receipt');
  assert(Array.isArray(product.intervals) && product.intervals.length <= 1024, 'Complete bounded interval array');
  let end = 0, retrievedThrough = 0, handledThrough = 0, priorHandlingSequence = 0;
  for (let index = 0; index < product.intervals.length; index++) {
    const row = product.intervals[index];
    same(row.index, index + 1, 'Sequential container number');
    same(row.fromM, end, 'No gap or duplicate bore interval');
    finite(row.toM, 'Interval endpoint');
    assert(row.toM > row.fromM, 'Positive drilled interval');
    assert(row.toM <= Math.min(product.targetDepthM, row.fromM + product.barrelCapacityM), 'No capacity overrun');
    if (Object.hasOwn(row, 'operatingConditions')) {
      assertOperatingConditions(row.operatingConditions, product.methodId);
      assert(row.operatingConditions.steps <= product.lastEvent.sequence - priorHandlingSequence, 'Operating steps fit this interval event history');
    }
    if (row.retrieval !== null) {
      assert(row.retrieval && positiveId(row.retrieval.sequence), 'Completed retrieval sequence');
      same(row.retrieval.provenance, rule.provenance, 'Method-specific retrieval');
      assert(row.retrieval.sequence > priorHandlingSequence + (product.methodId === 'sonic' ? 2 : 1), 'Advance/casing precede retrieval');
      if (product.methodId === 'sonic') assert(product.casedDepthM >= row.toM, 'Casing covers extracted interval');
      retrievedThrough = row.toM;
    }
    if (row.handling !== null) {
      assert(row.retrieval && row.handling && positiveId(row.handling.sequence), 'Handling follows completed retrieval');
      same(row.handling.container, rule.container, 'Method-specific container');
      assert(row.handling.sequence > row.retrieval.sequence, 'Handling sequence follows retrieval');
      priorHandlingSequence = row.handling.sequence;
      handledThrough = row.toM;
    }
    if (index < product.intervals.length - 1) assert(row.handling, 'Earlier barrel handled before next bore interval');
    end = row.toM;
  }
  same(end, product.drilledDepthM, 'Intervals account for all drilled bore');
  if (product.intervals.length) {
    assert(product.lastEvent && positiveId(product.lastEvent.sequence), 'Actual event watermark');
    same(product.lastEvent.runId, product.runId, 'Watermark run');
    same(product.lastEvent.attemptId, product.attemptId, 'Watermark attempt');
    for (const row of product.intervals) {
      if (row.retrieval) assert(row.retrieval.sequence <= product.lastEvent.sequence, 'Retrieval not ahead of watermark');
      if (row.handling) assert(row.handling.sequence <= product.lastEvent.sequence, 'Handling not ahead of watermark');
    }
  } else same(product.lastEvent, null, 'Empty attempt has no completed sample event');
  return { count: product.intervals.length, drilledThrough: end, retrievedThrough, handledThrough,
    complete: end === product.targetDepthM && handledThrough === end && end > 0,
    basis: rule.basis, finalPartial: !!product.intervals.length
      && product.intervals.at(-1).toM - product.intervals.at(-1).fromM < product.barrelCapacityM };
}

export function assertSettledSamplingReceipt(receipt, expected = {}) {
  assert(receipt && receipt.sampleProduct, 'Authoritative settled receipt exists');
  const product = receipt.sampleProduct;
  const coverage = assertLedgerSnapshot(product, expected);
  assert(coverage.complete, 'Every final interval handled before payment');
  same(receipt.sampleCapacityBasis, METHODS[product.methodId].basis, 'Receipt carries truthful capacity basis');
  same(receipt.methodId, product.methodId, 'Receipt method identity');
  if (Object.hasOwn(receipt, 'runId')) same(receipt.runId, product.runId, 'Receipt run identity');
  if (Object.hasOwn(receipt, 'attemptId')) same(receipt.attemptId, product.attemptId, 'Receipt attempt identity');
  return coverage;
}

/** The adapter must supply complete actual states, not precomputed pass flags. */
export function assertOperationPair({ before, after, action, accepted, completed }) {
  assert(before && after, 'Both operation states retained');
  const oldCoverage = assertLedgerSnapshot(before.product);
  const nextCoverage = assertLedgerSnapshot(after.product, {
    methodId: before.product.methodId, runId: before.product.runId,
    attemptId: before.product.attemptId, targetDepthM: before.product.targetDepthM,
    barrelCapacityM: before.product.barrelCapacityM,
  });
  assert(['sampleCase', 'sampleRetrieve', 'sampleHandle'].includes(action), 'Recorded sample operation');
  finite(before.depth, 'Before physical depth'); finite(after.depth, 'After physical depth');
  same(before.depth, before.product.drilledDepthM, 'Before ledger agrees with physical bore');
  same(after.depth, after.product.drilledDepthM, 'After ledger agrees with physical bore');
  same(after.depth, before.depth, 'Handling operation does not drill');
  assert(Array.isArray(before.receipts) && Array.isArray(after.receipts), 'Career receipt arrays retained');
  if (!accepted || !completed) {
    same(after.product, before.product, 'Refused/start-only operation cannot publish completion');
    same(after.receipts, before.receipts, 'Refused/start-only operation cannot settle');
    same(after.money, before.money, 'Refused/start-only operation cannot pay');
    if (accepted) {
      same(before.phase, 'sample-wait', 'Only a due sample step can start');
      same(after.phase, { sampleCase: 'sample-case', sampleRetrieve: 'sample-retrieve', sampleHandle: 'sample-handle' }[action], 'Started beat is the requested operation');
    } else same(after.phase, before.phase, 'Refusal cannot start a different operation');
  } else if (nextCoverage.complete && !oldCoverage.complete) {
    same(action, 'sampleHandle', 'Only final handling completes sampling');
    same(after.receipts.length, before.receipts.length + 1, 'Exactly one new settlement');
    const matching = after.receipts.filter(row => row.runId === after.product.runId
      && row.attemptId === after.product.attemptId && row.sampleProduct);
    same(matching.length, 1, 'One receipt for this completed attempt');
    same(matching[0].sampleProduct, after.product, 'Paid receipt equals completed actual product');
    assertSettledSamplingReceipt(matching[0]);
  } else {
    same(after.receipts, before.receipts, 'Intermediate handling cannot settle');
    same(after.money, before.money, 'Intermediate handling cannot pay');
  }
  if (accepted && completed) {
    same(before.phase, 'sample-wait', 'Completed pair begins at the native due-action click');
    const oldRows = before.product.intervals, nextRows = after.product.intervals;
    same(nextRows.length, oldRows.length, 'Handling cannot add a drilled interval');
    same(nextRows.slice(0, -1), oldRows.slice(0, -1), 'Prior containers remain immutable');
    same(after.product.lastEvent.sequence, before.product.lastEvent.sequence + 1, 'One completed event per action');
    same(after.product.lastEvent.type, { sampleCase: 'case', sampleRetrieve: 'retrieve', sampleHandle: 'handle' }[action], 'Completed event matches action');
    const prior = oldRows.at(-1), next = nextRows.at(-1);
    assert(prior && next, 'Handling applies to an actual drilled interval');
    same(next.operatingConditions, prior.operatingConditions, 'Sample handling does not invent further drilling exposure');
    if (action === 'sampleCase') {
      same(before.product.methodId, 'sonic', 'Only sonic has this casing step');
      same(after.product.casedDepthM, prior.toM, 'Casing reaches this interval end');
      same(nextRows, oldRows, 'Casing cannot manufacture retrieval or handling');
    } else {
      same(after.product.casedDepthM, before.product.casedDepthM, 'Extraction/handling cannot advance casing');
      same(next.fromM, prior.fromM, 'Interval start unchanged');
      same(next.toM, prior.toM, 'Interval end unchanged');
      if (action === 'sampleRetrieve') {
        same(prior.retrieval, null, 'Retrieve an unretrieved interval');
        assert(next.retrieval, 'Completed retrieval recorded');
        same(next.handling, null, 'Retrieval cannot log the container early');
      } else {
        assert(prior.retrieval, 'Handling requires earlier retrieval');
        same(prior.handling, null, 'Handle this interval once');
        same(next.retrieval, prior.retrieval, 'Handling preserves retrieval provenance');
        assert(next.handling, 'Completed container recorded');
      }
    }
  }
  return { complete: nextCoverage.complete, finalPartial: nextCoverage.finalPartial };
}

export function assertSamplingResultsText(text, receipt) {
  assert(typeof text === 'string' && text.length, 'Actual rendered Results text retained');
  const product = receipt.sampleProduct, rule = METHODS[product.methodId];
  const coverage = assertSettledSamplingReceipt(receipt);
  const words = text.replace(/\s+/g, ' ');
  // Caption casing is presentation: shipping .spec__k uses uppercase.
  const caption = expected => words.toLowerCase().includes(expected.toLowerCase());
  assert(words.includes(`${coverage.count} ${product.methodId === 'core' ? 'boxed' : 'sleeved'} intervals`), 'Rendered count matches receipt');
  assert(caption('Bore interval covered') && words.includes(`${product.drilledDepthM.toFixed(2)} m`), 'Bore coverage is labelled');
  assert(/Material recovery\s+Unmeasured/i.test(words), 'Material recovery remains unmeasured');
  assert(!/\b(?:TCR|SCR|RQD)\b\s*(?::|=)?\s*\d|(?:material recovery|sample yield)\s*(?::|=)?\s*\d[\d.]*\s*%/i.test(words), 'No invented material recovery measurement');
  if (rule.basis === 'gameplay-run-limit') assert(caption('Sampling run limit')
    && words.includes('game setting; usable inner capacity unmeasured'), 'Sonic limit is labelled a game setting');
  else assert(caption('Inner tube capacity') && words.includes('inner-tube length'), 'Core capacity basis retained');
  for (const row of product.intervals) assert(caption(`${rule.container === 'box' ? 'Box' : 'Sleeve'} ${row.index}`)
    && words.includes(`${row.fromM.toFixed(2)}–${row.toM.toFixed(2)} m · logged`), 'Opened interval log matches receipt row ' + row.index);
  for (const row of product.intervals) if (row.operatingConditions) {
    const operating = assertOperatingConditions(row.operatingConditions, product.methodId);
    assert(words.includes(`${operating.text} · ${operating.cuttingTime} drilling play time`), 'Actual operating presentation matches raw recorded times');
    assert(caption('Operating limits') && words.includes('Game thresholds; material condition is unmeasured'), 'Operating exposure is not material quality');
  }
}

/** Portable preflight mode for raw records emitted by a browser harness.
 * The report adapter remains a separate explicit layer; no data is inferred. */
export async function checkRawSamplingRecords(path) {
  const bytes = await readFile(path), report = JSON.parse(bytes);
  if (report.schema === 'sampling-browser-v1') return checkAuthorBrowserReport(report, path, bytes);
  same(report.schema, 'sampling-browser-critic-input-v1', 'Known explicit evidence adapter schema');
  assert(Array.isArray(report.operations) && report.operations.length > 0, 'Actual operation pairs retained');
  const results = report.operations.map(assertOperationPair);
  assert(Array.isArray(report.results) && report.results.length >= 2, 'Both method Results retained');
  same([...new Set(report.results.map(row => row.receipt.sampleProduct.methodId))].sort(), ['core', 'sonic'], 'Both methods');
  for (const row of report.results) assertSamplingResultsText(row.text, row.receipt);
  return { status: 'SEMANTIC_RECORDS_PASS', sourceReport: resolve(path),
    sourceReportSha256: createHash('sha256').update(bytes).digest('hex'), operationPairs: results.length,
    resultRecords: report.results.length,
    limitations: 'Record semantics only. No screenshot/font/source-manifest approval or real-phone claim is produced by this checker.' };
}

/** Explicit adapter for assembled_ui_fixture's retained native-browser schema.
 * Raw snapshots are checked independently; author PASS flags are necessary
 * provenance, never a substitute for checking the recorded state. */
export async function checkAuthorBrowserReport(report, path, bytes) {
  same(report.status, 'PASS', 'Only a completed capture can seek acceptance');
  same(report.errors, [], 'No browser errors');
  same(report.requestFailures, [], 'No failed resource requests');
  assert(report.cleanup?.browserClosed && report.cleanup?.serverClosed, 'Owned resources closed');
  same(report.cleanup.errors, [], 'Clean shutdown');
  assert(report.sourceHashes && Object.keys(report.sourceHashes).length > 20, 'Served source manifest retained');
  const sourceRoot = fileURLToPath(new URL('../', import.meta.url));
  for (const [source, expectedHash] of Object.entries(report.sourceHashes)) {
    assert.match(expectedHash, /^[a-f0-9]{64}$/, 'Complete SHA-256 for ' + source);
    same(createHash('sha256').update(await readFile(resolve(sourceRoot, source))).digest('hex'),
      expectedHash, 'Retained capture source matches current frozen file: ' + source);
  }
  same(report.methods.map(row => row.methodId).sort(), ['core', 'sonic'], 'Both methods captured once');
  const frame = snapshot => ({ product: snapshot.drill.sampleProduct, phase: snapshot.drill.phase,
    depth: snapshot.drill.depth, receipts: snapshot.career.receipts, money: snapshot.career.money });
  const outcomes = [];
  for (const method of report.methods) {
    same(method.status, 'PASS', 'Method capture completed');
    const states = new Map();
    for (const snapshot of method.snapshots) {
      assert(!states.has(snapshot.name), 'Snapshot names must be unique: ' + snapshot.name);
      states.set(snapshot.name, snapshot);
      same(snapshot.methodId, method.methodId, 'Snapshot method matches actual case');
      assert(snapshot.ui.fonts.includes('Inter') && snapshot.ui.fonts.includes('Oswald'), 'Loaded production fonts in every retained snapshot');
      if (snapshot.drill.sampleProduct) {
        assertLedgerSnapshot(snapshot.drill.sampleProduct, { methodId: method.methodId,
          targetDepthM: method.contract.targetDepth });
        same(snapshot.drill.depth, snapshot.drill.sampleProduct.drilledDepthM, 'Actual physical depth matches ledger at ' + snapshot.name);
        same(snapshot.drill.runId, snapshot.drill.sampleProduct.runId, 'Telemetry run matches product');
        same(snapshot.drill.attemptId, snapshot.drill.sampleProduct.attemptId, 'Telemetry attempt matches product');
      }
    }
    const get = name => { assert(states.has(name), 'Referenced raw snapshot exists: ' + name); return states.get(name); };
    const accepted = get('accepted');
    same(accepted.career.receipts.length, 0, 'Fresh career has no settlement');
    same(accepted.career.pending.id, method.contract.id, 'Native accepted canonical contract');
    for (const [key, value] of Object.entries(method.contract)) same(accepted.career.pending[key], value, 'Canonical tender unchanged: ' + key);
    assert(accepted.drill.geologyProfile.length > 0, 'Actual geology profile retained');
    assert(accepted.setup.purchases.length > 0 && accepted.setup.purchases.every(row => row.result?.ok), 'Actual successful purchase/equip results retained');
    assert(method.operations.length > 0, 'Native operations retained');
    for (const operation of method.operations) {
      const before = get(operation.before), started = get(operation.started), repeated = get(operation.repeat.snapshot);
      const underway = get(operation.underway), completed = get(operation.completed);
      assertOperationPair({ before: frame(before), after: frame(started), action: operation.action, accepted: true, completed: false });
      same(operation.repeat.result.ok, false, 'Repeated action rejected by actual consumer');
      assertOperationPair({ before: frame(started), after: frame(repeated), action: operation.action, accepted: false, completed: false });
      same(underway.drill.sampleProduct, before.drill.sampleProduct, 'Underway cannot publish completed operation');
      same(underway.career.receipts, before.career.receipts, 'Underway cannot pay');
      same(underway.career.money, before.career.money, 'Underway money unchanged');
      assertOperationPair({ before: frame(before), after: frame(completed), action: operation.action, accepted: true, completed: true });
      if (operation.dismissed) {
        const dismissed = get(operation.dismissed);
        same(dismissed.drill.sampleProduct, completed.drill.sampleProduct, 'Native notice dismissal preserves actual sample record');
        same(dismissed.career.receipts, completed.career.receipts, 'Notice dismissal cannot settle');
        same(dismissed.career.money, completed.career.money, 'Notice dismissal cannot pay');
        assert(/Material recovery\s+Unmeasured/i.test(operation.notification), 'Actual completed notification distinguishes material recovery');
      }
    }
    for (const type of ['wrong-phase', 'capacity-hold', 'final-handling-gate']) {
      const rows = method.negatives.filter(row => row.type === type); assert(rows.length > 0, 'Negative boundary exercised: ' + type);
      for (const row of rows) {
        const before = get(row.before), after = get(row.after);
        same(after.drill.sampleProduct, before.drill.sampleProduct, type + ': product unchanged');
        same(after.drill.depth, before.drill.depth, type + ': physical bore unchanged');
        same(after.career.receipts, before.career.receipts, type + ': receipts unchanged');
        same(after.career.money, before.career.money, type + ': money unchanged');
        if (type === 'wrong-phase') same(row.result.ok, false, 'Wrong-phase refusal is explicit');
      }
    }
    const finalBefore = get(method.finalHandling.before), settled = get(method.finalHandling.settled);
    const finalCoverage = assertLedgerSnapshot(finalBefore.drill.sampleProduct);
    assert(finalCoverage.finalPartial && !finalCoverage.complete, 'Final shorter barrel remains unhandled before payment');
    same(finalBefore.drill.depth, method.contract.targetDepth, 'Target reached before final handling');
    same(finalBefore.career.receipts.length, 0, 'Target alone has not paid');
    same(settled.career.receipts.length, 1, 'Exactly one settled job');
    const receipt = settled.career.receipts[0];
    assertSettledSamplingReceipt(receipt, { methodId: method.methodId, targetDepthM: method.contract.targetDepth });
    const operatingRows = receipt.sampleProduct.intervals.map(row => assertOperatingConditions(row.operatingConditions, method.methodId));
    assert(operatingRows.some(row => row.hasExposure), 'Disclosed real public-input policy produced an actual exposure');
    same(settled.career.money - finalBefore.career.money, receipt.net, 'Actual money change equals authoritative net');
    same(settled.completions.length, 1, 'One real completion event');
    same(settled.career.pending, null, 'One-hole canonical contract closes');
    assertSamplingResultsText(get(method.finalHandling.results).ui.text, receipt);
    const pendingBefore = get(method.pendingReload.before), pendingLoaded = get(method.pendingReload.loaded), restarted = get(method.pendingReload.restarted);
    assert(pendingLoaded.documentId !== pendingBefore.documentId, 'Pending reload creates a new document');
    same(pendingLoaded.navigationType, 'reload', 'Real pending document reload');
    same(restarted.drill.depth, 0, 'Intended physical restart at zero');
    same(restarted.drill.sampleProduct.intervals, [], 'Old in-flight samples are not transplanted');
    assert(restarted.drill.attemptId !== pendingBefore.drill.attemptId, 'New physical attempt identity');
    same(restarted.career.money, pendingBefore.career.money, 'Reload does not charge mobilisation again');
    same(restarted.career.pending.id, pendingBefore.career.pending.id, 'Accepted contract retained');
    const receiptBefore = get(method.receiptReload.before), receiptLoaded = get(method.receiptReload.loaded);
    assert(receiptBefore.documentId !== receiptLoaded.documentId, 'Settled reload creates a new document');
    same(receiptLoaded.navigationType, 'reload', 'Real settled document reload');
    same(receiptLoaded.career.receipts, receiptBefore.career.receipts, 'Complete receipt survives reload');
    same(receiptLoaded.career.money, receiptBefore.career.money, 'Reload does not pay again');
    const savedBefore = JSON.parse(receiptBefore.career.storageRaw), savedAfter = JSON.parse(receiptLoaded.career.storageRaw);
    same(savedBefore.player.career.ledger, receiptBefore.career.receipts, 'Native stored receipt equals actual career');
    same(savedAfter.player.career.ledger, savedBefore.player.career.ledger, 'Saved receipt data unchanged after reload');
    const geometryRows = method.geometry.flatMap(group => group.rows);
    const actualNotices = method.operations.map(row => row.notification).filter(text => typeof text === 'string');
    assert(actualNotices.length > 0, 'Actual native sample notices recorded');
    const longestNotice = actualNotices.reduce((longest, text) => text.length > longest.length ? text : longest, '');
    same(method.longestCard.text, longestNotice, 'Narrow capture identifies longest actual notice');
    same(method.longestCard.length, longestNotice.length, 'Actual longest notice length');
    assert(Array.isArray(method.noteGeometry) && method.noteGeometry.some(row => row.name === method.longestCard.name), 'Longest native notice has retained text geometry');
    for (const notice of method.noteGeometry) {
      same(notice.viewport.width, 320, 'Narrow Site notice was actually measured at 320 CSS pixels');
      assert(notice.blocks.length > 0, 'Retained actual title, labels, values and note');
      for (const block of notice.blocks) {
        assert(block.rect.x >= notice.card.x - .5 && block.rect.x + block.rect.width <= notice.card.x + notice.card.width + .5
          && block.rect.y >= notice.card.y - .5 && block.rect.y + block.rect.height <= notice.card.y + notice.card.height + .5, 'Site text block stays inside actual card');
        for (const line of block.lines) assert(line.x >= block.rect.x - .5 && line.x + line.width <= block.rect.x + block.rect.width + .5
          && line.y >= block.rect.y - .5 && line.y + line.height <= block.rect.y + block.rect.height + .5, 'Independent Site text line containment');
      }
      for (let i = 0; i < notice.blocks.length; i++) for (let j = i + 1; j < notice.blocks.length; j++) {
        const a = notice.blocks[i].rect, b = notice.blocks[j].rect;
        assert(!(Math.min(a.x + a.width, b.x + b.width) - Math.max(a.x, b.x) > 1
          && Math.min(a.y + a.height, b.y + b.height) - Math.max(a.y, b.y) > 1), 'Independent Site text blocks do not overlap');
      }
    }
    assert(Array.isArray(method.conditionGeometry) && method.conditionGeometry.length >= 2, 'Retained actual Results operating rows at both widths');
    for (const group of method.conditionGeometry) {
      same(group.rows.length, receipt.sampleProduct.intervals.length, 'Every actual operating row measured');
      const viewport = get(group.name).ui.viewport;
      group.rows.forEach((row, index) => {
        same(row.text.replace(/\s+/g, ' '), `${operatingRows[index].text} · ${operatingRows[index].cuttingTime} drilling play time`, 'Rendered operating row matches its receipt interval');
        assert(row.row.x >= -.5 && row.row.x + row.row.width <= viewport.width + .5, 'Operating row fits actual width');
        assert(row.key.x + row.key.width <= row.value.x + .5, 'Operating label/value boxes do not overlap');
        for (const line of row.lines) assert(line.x >= row.value.x - .5 && line.x + line.width <= row.value.x + row.value.width + .5
          && line.y >= row.value.y - .5 && line.y + line.height <= row.value.y + row.value.height + .5, 'Independent full operating value line containment');
      });
      same(group.maximum, group.rows.reduce((max, row, index) => row.text.length > group.rows[max].text.length ? index : max, 0), 'Capture selected longest real operating row');
    }
    assert(geometryRows.length > 0, 'Actual geometry records exist');
    for (const row of geometryRows) {
      assert(row.width >= 43.99 && row.height >= 43.99, 'True 44 CSS pixel target: ' + row.text);
      assert(row.inViewport, 'Checked target fits viewport: ' + row.text);
      assert(!row.labelClipped, 'Recorded target label fits: ' + row.text);
      assert(Array.isArray(row.textRects), 'Retained painted label rectangles: ' + row.text);
      for (const line of row.textRects) assert(line.left >= row.x - .5 && line.right <= row.x + row.width + .5
        && line.top >= row.y - .5 && line.bottom <= row.y + row.height + .5, 'Independent label fit: ' + row.text);
      for (const notice of row.paintedNotifications) {
        for (const key of ['x', 'y', 'width', 'height']) finite(notice[key], 'Painted notification ' + key);
        const overlaps = Math.min(row.x + row.width, notice.x + notice.width) - Math.max(row.x, notice.x) > 1
          && Math.min(row.y + row.height, notice.y + notice.height) - Math.max(row.y, notice.y) > 1;
        assert(!overlaps, 'Painted notification cannot overlap target: ' + row.text);
      }
      if (!row.disabled) assert(row.hit, 'Checked enabled target receives hit: ' + row.text);
    }
    for (const group of method.geometry) for (let i = 0; i < group.rows.length; i++) for (let j = i + 1; j < group.rows.length; j++) {
      const a = group.rows[i], b = group.rows[j];
      assert(!(Math.min(a.x + a.width, b.x + b.width) - Math.max(a.x, b.x) > 1
        && Math.min(a.y + a.height, b.y + b.height) - Math.max(a.y, b.y) > 1), 'Independent target pair overlap: ' + group.name);
    }
    const screenshotHashes = [];
    for (const screenshot of method.screenshots) {
      const png = await readFile(screenshot.path); assert(png.length > 0, 'Actual screenshot artifact exists');
      screenshotHashes.push({ path: screenshot.path, sha256: createHash('sha256').update(png).digest('hex') });
    }
    outcomes.push({ methodId: method.methodId, snapshots: method.snapshots.length,
      nativeOperations: method.operations.length, intervals: receipt.sampleProduct.intervals.length,
      targetDepthM: method.contract.targetDepth, geometryRows: geometryRows.length,
      screenshotCount: method.screenshots.length, screenshotHashes,
      viewports: [...new Set(method.snapshots.map(s => `${s.ui.viewport.width}x${s.ui.viewport.height}`))] });
  }
  return { status: 'SEMANTIC_RECORDS_PASS', sourceReport: resolve(path),
    sourceReportSha256: createHash('sha256').update(bytes).digest('hex'), frozenSourceCount: Object.keys(report.sourceHashes).length, outcomes,
    limitations: 'Raw browser semantics and recorded local target geometry only. Manual screenshot/painted overlap review remains required. Software-limit start, mid-operation reload, save faults and actual phones are not inferred from these records.' };
}

export async function selfTestOracle() {
  const source = new URL('../research/sample-gameplay-adversarial-2026-09-08.json', import.meta.url);
  const bytes = await readFile(source), existing = JSON.parse(bytes);
  const rows = existing.observations.filter(row => row.product && METHODS[row.product.methodId]);
  assert(rows.length >= 2, 'Retained actual-CPU product observations are present');
  same([...new Set(rows.map(row => row.product.methodId))].sort(), ['core', 'sonic'], 'Both retained method examples');
  let positives = 0, negatives = 0;
  for (const row of rows) {
    const product = row.product;
    assert(assertLedgerSnapshot(product).complete); positives++;
    for (const mutate of [
      value => { value.intervals[0].fromM = 0.125; },
      value => { value.barrelCapacityM = 0; },
      value => { value.intervals.at(-1).retrieval.provenance = 'unrecorded-extraction'; },
      value => { value.intervals.at(-1).handling.sequence = value.intervals.at(-1).retrieval.sequence; },
      value => { value.drilledDepthM += 0.25; },
    ]) {
      const changed = structuredClone(product); mutate(changed);
      assert.throws(() => assertLedgerSnapshot(changed)); negatives++;
    }
    const unhandled = structuredClone(product); unhandled.intervals.at(-1).handling = null;
    assert.throws(() => assertSettledSamplingReceipt({ methodId: product.methodId,
      sampleCapacityBasis: METHODS[product.methodId].basis, sampleProduct: unhandled })); negatives++;
  }
  return { status: 'ORACLE_SELFTEST_PASS_NOT_BROWSER_ACCEPTANCE', retainedProductExamples: positives,
    deliberateInvalidRecordsRejected: negatives, input: source.href,
    inputSha256: createHash('sha256').update(bytes).digest('hex'),
    scope: 'Calibration of the independent checker against retained CPU products and deliberate invalid mutations. No new game, rendered browser or phone acceptance.' };
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  const index = process.argv.indexOf('--input');
  if (process.argv.includes('--self-test')) {
    const result = await selfTestOracle();
    const output = process.argv.indexOf('--output');
    if (output >= 0) await writeFile(process.argv[output + 1], JSON.stringify(result, null, 2) + '\n');
    console.log(JSON.stringify(result, null, 2));
  } else if (index < 0) {
    console.log(JSON.stringify({ status: 'PREPARED_NOT_RUN', requires: '--input <explicit actual-browser records>' }));
  } else {
    const result = await checkRawSamplingRecords(process.argv[index + 1]);
    const output = process.argv.indexOf('--output');
    if (output >= 0) await writeFile(process.argv[output + 1], JSON.stringify(result, null, 2) + '\n');
    console.log(JSON.stringify(result, null, 2));
  }
}
