# Corrected piling capture: independent offline review

**Disposition: the complete capture remains failed.** The retained frames support the corrected carriage placement and stable capture mechanism. Three orbit views do not expose the ram, and four rejected asset responses lack sufficient provenance to identify their exact URLs.

Reviewed report: `evidence/pile-motion-corrected-01/report.json`, SHA-256 `8a12f5dc0fd699b2e10fd462ac58d60f91cf54acffcfba21ef7b49bf8451a63f`.
Frozen harness: `c36d7573ba4ea471fc6d6a949b820437bd906702c391df426c5ccd2a5883e52c`.
Piling GLB: `6a96b56031e3f8f05214940ed746de27dac9543382d51e505b543cd366daa5bd`.
Candidate: `drillity-next-pile-visual`. Reviewer: `/root/pile_motion_critic`.

No browser, GPU, server or Blender was launched for this review. No production or capture-harness edits were made. The retained report and images were not modified.

## Independent checks on actual retained evidence

`node tools/reviewpilecapture-offline.mjs` completed in under one second and writes `research/pile-corrected-capture-critic.json`. It independently reconstructs the PNG scanline filters and recounts ram ID pixels, rather than trusting the report's pixel totals. All twenty normal screenshot hashes match the recorded values. All twenty decoded mask counts and bounds match their records; the critic JSON additionally hashes each mask.

All twenty frames preserve exact before/after identity, observed frame and consumed-input frame. Requested phase/cycle/pause criteria match. The carriage position equals the actual GLB's authored rest minus the exact depth consumed by the rig, clamped to authored offset endpoints. The ram's recorded local position agrees with that frame's consumed phase/drop and the committed reveal/dismiss curves. Cap local position remains its authored GLB value. Both actual UI-pause intervals preserve ram, public simulator mirror and private simulator state. Source manifests match before/after. Browser and server cleanup succeeded.

These are useful bounded results, not twenty fully accepted captures. Orbit has three visibility failures; the two case-level errors per camera fail the whole run.

| View | Observed ID pixels | Result |
| --- | --- | --- |
| Hero, all ten samples | 315–337 | Positive depth-visible ram geometry in every sample |
| Orbit, first seven samples | 188–460 | Positive depth-visible ram geometry |
| Orbit, take-set rising | 0 | Visibility failure retained |
| Orbit, take-set falling | 0 | Visibility failure retained |
| Orbit, re-drive rest | 0 | Visibility failure retained |

The ten hero samples include the pause-sheet sample; ID rendering only measures the scene, not DOM visibility through that sheet.

## What the images establish about geometry

Viewed normal images: hero peak, bottom and take-set rising; orbit peak, take-set rising and re-drive rest. Also viewed hero peak/bottom masks and orbit take-set rising mask. In these corrected images, the hammer housing is alongside the leader below its crown. The formerly captured assembly above the leader is absent in these views. This is consistent with the independently checked parent placement; it is not a matched photographic before/after comparison.

At the same reported consumed depth 0.12039552687581494, corrected hero peak has carriage-local Y14.479604854593912, versus the earlier failed capture's Y29.113206926015618. Current hero peak and bottom have the same captured camera pose and distinguishable ram mask positions. The front-view ram is a narrow, dark detail: positive ID pixels do not by themselves establish strong normal-shading contrast or perceptually clear live motion.

The three zero-pixel orbit views look toward the rear/side of the leader and casing. The absence is genuine in the retained masks, while the ram's phase-driven transform is still recorded correctly. These artifacts do not isolate which mesh occludes it, and do not prove a mesh collision. The ordinary Site scene selects `hero` in `src/core/renderer.js:2531`; the harness explicitly selects orbit as an additional inspection scenario. Thus the rear orbit failure is not evidence that the ordinary hero gameplay camera always hides the action.

The drive cap stays at its authored local transform under the moving carriage. `blender/piling_leader.py:1158` authors the pile as a separate sibling under the leader. This capture does not record the pile's live transform or expose all contact surfaces. It cannot certify pile penetration, cap-to-pile clearance, hidden ram/casing contact, rope following or a complete piling sequence. The source-traced static-pile/rope gaps remain open; no dimensions or geometry fixes are invented here.

## Exact asset-error attribution is unavailable

There are two `Asset response has an unexpected origin` errors in each camera case. Both HTTP-failure and request-failure arrays are empty. These are classifier rejections of received asset responses, not recorded failed HTTP requests.

`classifyServedAsset` first filters for `.glb`, `.png`, `.webp`, `.woff` or `.woff2` paths, then rejects origins outside the local Vite server. At `tools/checkpilemotion-browser.mjs:172`, its catch retains only `String(error)` and discards the response URL, origin, headers and body. No HAR or network trace was retained. Consequently this evidence proves an off-origin response with one of those suffixes, but cannot identify its exact resource or host.

`index.html:9`–11 explicitly declares Google Fonts for Inter and Oswald and a `fonts.gstatic.com` preconnect. Fonts are a plausible explanation for two font-like responses per page. They are **not a proven attribution**; the matching count is not a substitute for the missing URLs. The stylesheet URL itself does not pass the classifier's filename-suffix filter.

## Concrete follow-up work

1. Preserve rejected asset URL, status, content type, request resource type and response hash before classifying it. Establish explicit provenance for actual external fonts while continuing to reject unexpected origins/resources and changed local assets. The current run must remain failed; no retroactive whitelist can prove its missing URLs.
2. Investigate the piling orbit operating view at the recorded take-set/re-drive camera poses. Identify the actual occluding meshes with a separately authorized diagnostic, then make any operating-camera policy preserve readable action without changing sourced geometry or weakening the visibility gate. Retain hero and rear/side evidence and state which modes are player-facing.
3. Separately implement and verify the pile/cap/rope action relationship across real progress and reset. This is not closed by the narrow ram driver or the corrected carriage origin. Inspect actual contact geometry only after the relevant transforms and authored semantics are recorded.

Continuous cadence, physical timing, real-phone behavior and overall game completion remain outside this capture's acceptance scope.
