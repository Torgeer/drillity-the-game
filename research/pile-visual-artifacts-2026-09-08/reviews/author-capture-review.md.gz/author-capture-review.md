# Corrected piling capture — rejected, evidence retained

One root-authorized actual browser run completed 2026-09-08T14:00:00.608Z to 2026-09-08T14:01:54.578Z. Overall result **CAPTURE_FAILED**, not clearance approval. Both browser contexts, the browser and Vite server closed. Port 5250 was independently found free and the GPU lease returned to idle at 2026-09-08T14:02:20.806Z. No second run or production/harness change followed this result.

## Reproduction and immutable inputs

Candidate: C:/Users/henri/Downloads/threads/drillity-next-pile-visual. From that directory, the command was:

`node tools/checkpilemotion-browser.mjs --out evidence/pile-motion-corrected-01`

The output must never be overwritten; a future attempt requires a new output directory and a root graphics grant. Harness SHA256 c36d7573ba4ea471fc6d6a949b820437bd906702c391df426c5ccd2a5883e52c. Report SHA256 8a12f5dc0fd699b2e10fd462ac58d60f91cf54acffcfba21ef7b49bf8451a63f. The report freezes 448 before/after source/asset/Three files and they match. The actual piling GLB remains 6a96b56031e3f8f05214940ed746de27dac9543382d51e505b543cd366daa5bd. The candidate retains the 300-file September 8 13:12 snapshot, with only the reviewed harness changed; no newer gameplay patch was overlaid.

The first preflight failed before lease acquisition or browser launch while root npm install temporarily removed KTXLoader.js. Root confirmed that cause. After installation completed, all 332 recorded Three dependency hashes, the reviewed Vite hash and all unchanged snapshot files matched. See research/pile-visual-preflight-recovery.json. This was a preflight recovery, not a discarded browser run.

## What the completed render evidence establishes

Twenty screenshots from real accepted driven-pile career scenarios, with purchased piling-leader and supported impact-hammer-9t loadout, cover pitch, drilling rising/peak/falling/bottom, real UI pause, dolly change, take-set and re-drive. The two contexts use orbit and hero cameras at 390x844 CSS pixels / DPR 2 on headed desktop Chrome. This is not physical phone certification or an FPS test. Actual unheld histories contain 1947 orbit and 2111 hero frames.

Every held capture preserves its complete before/after identity, camera, clock, latest private simulator state and exact earlier input consumed by rig.update. All 20 diagnostic renders restore their materials/render state. Both separate 45-frame UI pause intervals preserve public simulation, private simulation and ram world pose. All requested consumed phase bands match. Thus this attempt does not repeat the prior dt=0 hold drift or the wrong post-simulation phase selection.

Ram local displacement follows actual published phase: at hero phase 0.202666666666667 it is 1.6374223890014246; phase 0.510000000000001 gives 1.780526666079961; phase 0.817333333333335 gives 1.6065576587838817; phase 0.020000000000001794 gives 1.178441193532709. Rest in pitch, dolly and re-drive is 1.1000003814697266. Take-set has actual phase-driven displacement at fixed depth. These are recorded transformed-node observations, not invented timing or dimensions. Discrete images do not alone establish pleasant continuous cadence.

The corrected carriage is observed at 14.479604854593912 for actual consumed depth 0.12039552687581494, exactly authored rest 14.600000381469727 minus depth. This is the current rendered source's observation. The old failed capture used different source and invalid holds; it is not a matched before/after comparison and does not prove a causal visual improvement by itself.

## Remaining failures

| Capture | Orbit visible ram pixels | Hero visible ram pixels |
| --- | ---: | ---: |
| pitch-rest | 188 | 337 |
| rising | 385 | 315 |
| peak | 451 | 317 |
| falling | 460 | 323 |
| bottom | 314 | 332 |
| paused | 242 | 319 |
| dolly-rest | 267 | 329 |
| take-set-rising | 0 | 324 |
| take-set-falling | 0 | 325 |
| re-drive-rest | 0 | 329 |

All ten hero frames and seven orbit frames meet the existing positive-pixel requirement. Orbit take-set rising, take-set falling and re-drive have zero depth-visible ram pixels and remain failed. The normal orbit take-set image shows the camera viewing the opposite side of the mast; camera rotation is visible in the retained images. No object-isolation counterfactual was run, so the exact occluding mesh is not proved. Zero visible pixels must not be relabeled as passing merely because the ram transforms moved correctly.

Each context also reports two **Asset response has an unexpected origin** errors. There are no HTTP/request failures, and the eight retained same-origin asset records per context validate raw GLB/PNG bytes and the Vite logo import wrappers correctly. The error handler did not retain the rejected URL, so the exact offending response is unknown. Frozen index.html lines 9-11 imports external Google Fonts; that is a plausible source requiring instrumentation, not a proven attribution. The next harness change should retain rejected URL, resource type, content type and response hash, then explicitly account for legitimate frozen font dependencies while keeping rejection of unapproved origins/assets. Do not blanket-ignore origins or weaken the failing assertion.

## Normal-image review and open geometry limits

Reviewed normal orbit-peak, orbit-take-set-rising, hero-peak, hero-bottom, hero-take-set-rising and hero-re-drive-rest. The current hero image shows the hammer assembly alongside the mast, but the full machine base reaches the section boundary and the small ram/casing details do not provide a complete clearance inspection. The orbit take-set view does not expose the ram. Positive ID pixels establish visible geometry, not sufficient beauty-pass contrast, absence of cap/casing intersection or full assembly realism.

Static pile and rope alignment remain a separate unresolved scope. No geometry, physical values, shader, camera or acceptance tolerance was changed. No cap/casing clearance approval, general fleet graphics approval or performance claim follows this run.

Useful normal image paths, all beneath C:/Users/henri/Downloads/threads/drillity-next-pile-visual/evidence/pile-motion-corrected-01:

- hero-peak.png
- hero-bottom.png
- hero-take-set-rising.png
- orbit-peak.png
- orbit-take-set-rising.png
- orbit-re-drive-rest.png

The complete raw report and masks remain beside them. The earlier failed MAIN evidence/pile-motion-browser-final-01 report and images are unchanged. Independent critic review of this capture is requested; CPU preflight approval was limited to readiness to run, not visual acceptance.
