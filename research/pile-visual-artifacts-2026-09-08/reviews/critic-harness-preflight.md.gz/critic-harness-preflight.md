# Piling capture harness: independent review

Reviewer: `/root/pile_motion_critic`. Candidate: `drillity-next-pile-visual`.
Scope: CPU control flow and asset provenance before a separately authorized live capture. No browser, WebGL context, Blender process, production edit, generated asset write, commit or push was performed by this review.

**Disposition: approve the frozen harness for a controlled browser run.** All eleven independent control groups pass, including three historical failure controls. This is not rendered acceptance of the piling machine.

Reviewed browser harness SHA-256: `c36d7573ba4ea471fc6d6a949b820437bd906702c391df426c5ccd2a5883e52c`.
Critic tool SHA-256: `752a7786e7d98ceb06d7536624676c2b5abbd9aa04beef0c642f87529c121503`.
Historical harness SHA-256: `faeb1012be4d913762cdcb37b2422468c7fa57cef2c25da8296c294708203440`.
The critic report also records production source, piling GLB and Three.js module hashes. Source identity was stable through the final run.

## What the failed capture establishes

The preserved `../drillity-fps-investigation/evidence/pile-motion-browser-final-01/report.json` reports `CAPTURE_FAILED` with unchanged source and twenty captured frames. It cannot certify the corrected placement, which came later.

`src/main.js:985` runs the rig update before the simulator update; the original renderer runs afterward. The old harness selected a frame using the later published simulator state, then called every update again with zero delta while holding the screenshot. Zero delta does not prevent the rig from applying the newer input. The artifact records ram-local Y changing from 1.7736739177043335 to 1.780526666079961 in orbit peak, and from 1.7119610432261188 to 1.2272346143907702 in hero bottom. These are capture identity failures independent of whether the adapter's normal motion is correct.

The old report also maps source PNGs to `public/src/...` and compares Vite JavaScript URL export wrappers to raw PNG bytes. Each camera records three corresponding errors. Those are provenance-classification failures, not proof that the actual PNG bytes were corrupt.

Orbit has zero ram ID pixels in nine of ten captures; its take-set falling frame has 24. Hero has 188–200. Mask pixels establish depth visibility only and are insufficient to establish normal-shading legibility. No matched browser capture from before the original ram adapter exists; this review does not label any observed floating assembly as preexisting.

The earlier CPU attribution remains bounded: the ram adapter moves only `slide:hammer-ram`, whose mesh child is `hammer_ram`. Housing, jaws, ports and cap are other children under the carriage. The old generic carriage calculation placed the whole carriage at Y29.113206926015618 at the reported hero-peak depth 0.12039552687581494. The separately approved authored-offset/continuous-feed correction is already in this candidate. This harness change does not modify either geometry or that production correction.

## Independent executable checks

Run `node tools/checkpilevisual-adversarial.mjs` from the candidate. Results and exact candidate/baseline hashes are in `research/pile-visual-critic.json`; the console transcript is `research/pile-visual-critic-console.txt`.

The fixture uses real Three.js scene/matrix objects with synthetic update and renderer callbacks. It follows the actual rig-before-sim ordering. Its dimensions, timing and fake diagnostic pixel are explicitly test inputs, not measurements or physical specifications. The historical function is extracted from the immutable resume snapshot rather than rewritten as a supposed old implementation.

The eleven current groups verify:

1. Actual source PNG bytes and their URL-export wrappers receive distinct provenance records; wrapper hashes are never represented as raw image hashes.
2. Unexpected origins, queries, escaped paths, unlisted files, changed raw bytes and incorrect raw MIME types reject.
3. Executable wrapper suffixes, wrong resources/origins, wrong MIME and inconsistent source maps reject.
4. A frame that consumes phase 0.1 is selected even though the simulator publishes 0.3 afterward; both identities are retained separately.
5. Twelve held main ticks invoke no system or render callback, leave the complete recorded identity unchanged, and resume each callback once after release.
6. Fourteen deliberately corrupted capture rows reject, covering visibility, restoration, observed/consumed frames, camera, both clocks, requested phase/band/pause, method and missing input/request.
7. Shared target/non-target materials are restored exactly after the diagnostic, including cyclic metadata, property descriptors and original-material changes made by a shader hook. Discard code is retained. The diagnostic's synthetic count of two draw calls is kept separate from the completed beauty frame's synthetic count of 57.
8. A deliberate diagnostic render exception restores materials/render state before propagation, leaves held identity intact and allows a successful retry.
9. The historical harness fails selection of a frame by its consumed input.
10. The historical harness moves the ram from Y1.1 to Y1.3 during its supposed hold and invokes the rig again.
11. The final inventory includes all thirty actual linked GLBs, matching independent reads of their bytes. The real piling response matches `6a96b56031e3f8f05214940ed746de27dac9543382d51e505b543cd366daa5bd`. Deliberately wrong link targets and unapproved linked paths reject. Running the historical inventory against the same actual candidate proves it omits the piling GLB.

The diagnostic tests provide no actual raster evidence: their single magenta pixel comes from an explicit fake readback. They check restoration and adjudication, not real geometry visibility.

## Preflight finding repaired before browser execution

The candidate links `public/models` to MAIN with a Windows junction. Node's directory entry reports `isDirectory() === false`, `isFile() === false`, `isSymbolicLink() === true`. The first candidate manifest walked only directories/files and omitted every linked model; its prepare-only output counted 418 files. Consequently the strict response checker would reject the real piling GLB as absent. The final inventory validates that exact authorized path and its real target before reading it, and freezes 448 files including thirty GLBs. This failure remains documented; passing isolated asset-helper fixtures did not certify the entire preflight.

The final actual UI pause interval compares authoritative simulator state as well as the published mirror and ram. Held screenshot identity also includes both simulator records. This is a source-reviewed acceptance condition awaiting the actual browser pause; the critic's synthetic clock fixture is not substituted for that run.

## Live acceptance still required

The next root-authorized capture must retain the exact served source/model hashes and report no asset, console, HTTP or request errors. Raw GLB/texture/font bytes must match the frozen manifest; Vite wrappers must resolve to their exact separately hashed source files. Before/after source manifests must match.

Each beauty image must have a completed-frame identity tied to the exact input consumed by the rig. Requested phase/band, actual simulator identity, ram/carriage/cap transforms, camera, viewport, contract, loadout, run and attempt must remain unchanged throughout capture and diagnostic restoration. Repeated zero-time callbacks are not an acceptable substitute for a hold.

Review normal hero/orbit images and companion masks at pitch, rising, peak, falling, bottom, dolly change, take-set and re-drive. Keep zero-visible-pixel failures for exposed beauty cases. The explicitly covered pause sheet has a separate stillness requirement. Examine actual ram/casing/cap clearance, readable motion and carriage placement, and use frame history to distinguish simulation cycle progression from sampling bands. Do not infer physical cycle time from the chosen capture bands, or infer performance from diagnostic draw counts. Desktop phone-shaped capture does not establish real-phone performance or complete piling gameplay.
