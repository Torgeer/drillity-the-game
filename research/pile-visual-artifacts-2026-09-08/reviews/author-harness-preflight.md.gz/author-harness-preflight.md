# Corrected piling browser harness — preflight

Candidate `drillity-next-pile-visual` starts from detached `a47de8a` overlaid with all 300 verified files from the immutable `resume-70-baseline-2026-09-08` snapshot. Only the assigned browser harness differs from those baseline files. Generated assets are read without modification, including the explicitly authorized `public/models` junction. The manifest now freezes all 30 generated GLBs, including every shipped rig; ignoring the junction was an initial preflight defect caught independently.

## Repairs

The actual main loop updates the rig before the simulator. A rendered pose therefore consumes the previous public telemetry. The old harness selected a phase from the later state and then called every system with zero dt during the hold. A zero-dt rig update can still copy the newer depth and hammer phase, so the supposed frozen pose changed. The repaired harness records the exact input passed to the real rig update, selects against that input after its original render, and preserves the separately recorded latest private/public simulation state. It skips original update and render callbacks while holding the completed frame and restores only main-loop clock bookkeeping. It does not write simulation phase, depth, input or physical constants.

The asset validator now treats `/src/ui/assets/...png` as a source asset. The corresponding `?import` response is a Vite JavaScript URL-export module, not PNG bytes. Raw bytes must match the frozen manifest; modules must contain only the expected same-origin resource export and an optional validated source map, and their response hashes are retained. Unknown paths, queries, origins, executable wrappers and mismatched raw bytes reject. A direct-transform fixture initially supplied `?import` to Vite's internal transformRequest; inspection confirmed its real HTTP middleware strips that query before transformation. The final CPU fixture follows that actual middleware path instead of accepting the incorrect exported query.

Frame and input identities, requested phase/band, camera, private simulation, public state, and clock remain exact assertions. The visibility pixel requirement is unchanged. Actual UI pause now checks both the public mirror and private simulation state. The diagnostic restores original material metadata and renderer state. Since held frames are not redrawn, the tool reports the one completed beauty draw and separate diagnostic draw honestly; it makes no stale-counter comparison or FPS claim. Its Vite cache is private to the evidence directory, not the shared node_modules junction.

## Reproduction and status

```powershell
node tools/checkpilemotion-browser.mjs --self-test
node tools/checkpilevisual-harness.mjs --json research/pile-visual-harness-author.json
node tools/checkpilevisual-adversarial.mjs
node tools/checkpilemotion-browser.mjs --prepare-only
```

The author fixture uses the actual GLB, rig and simulator under main's update order. It captures natural drilling input, checks its actual ram position, holds 90 main-loop ticks without an original callback or identity change, and resumes each callback exactly once. Four real source/Vite asset cases pass. Its rendering, DOM and positive mask are explicitly CPU fixtures and establish no visible pixels. The independent critic separately tests malformed inputs, old-harness counterfactuals and diagnostic restoration, including exceptions.

`research/pile-visual-preflight.json` records final hashes and the baseline comparison. `drillity-coordination/pile-visual-harness-delta.patch/json` exports the narrow harness change and unique author fixture against the frozen snapshot. The previous rejected browser capture in main remains untouched.

Status: **PREPARED_NOT_RUN**. No browser/GPU acceptance is claimed. After an explicit root grant and the `pile-motion-browser` lease, the bounded command is:

```powershell
node tools/checkpilemotion-browser.mjs --out evidence/pile-motion-corrected-01
```

It owns port 5250, captures orbit and hero at 390×844 CSS pixels/DPR 2, saves real phase beauty frames and visibility masks, and closes owned resources. Zero ram pixels, identity drift, asset errors or clearance concerns remain reportable failures. Static pile geometry, ropes, cap/casing clearance, site occlusion and actual-device/FPS acceptance remain separate from this harness repair.
