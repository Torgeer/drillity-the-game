/** Read-only, CPU-only review of retained PNG/JSON evidence. No browser or renderer. */
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { inflateSync } from 'node:zlib';
import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';
import { parseGLB } from './glbinfo.mjs';
import { ease } from '../src/core/motion.js';
const root = fileURLToPath(new URL('../', import.meta.url));
const at = resolve(root, 'evidence/pile-motion-corrected-01');
const sha = b => createHash('sha256').update(b).digest('hex');
const raw = readFileSync(resolve(at, 'report.json')), report = JSON.parse(raw);
assert.equal(sha(raw), '8a12f5dc0fd699b2e10fd462ac58d60f91cf54acffcfba21ef7b49bf8451a63f');
assert.equal(report.status, 'CAPTURE_FAILED');
assert.deepEqual(report.sourceBefore, report.sourceAfter);
// PNG filters reconstructed independently of the browser's reported ID count.
function pixels(bytes) {
  assert.equal(bytes.subarray(0, 8).toString('hex'), '89504e470d0a1a0a');
  let width, height, channels, chunks = [];
  for (let p = 8; p < bytes.length;) {
    const n = bytes.readUInt32BE(p), type = bytes.toString('ascii', p + 4, p + 8), data = bytes.subarray(p + 8, p + 8 + n);
    if (type === 'IHDR') {
      width = data.readUInt32BE(0); height = data.readUInt32BE(4);
      assert.equal(data[8], 8); assert.ok([2, 6].includes(data[9]));
      channels = data[9] === 6 ? 4 : 3; assert.equal(data[12], 0);
    } else if (type === 'IDAT') chunks.push(data);
    p += n + 12;
  }
  const filtered = inflateSync(Buffer.concat(chunks)), stride = width * channels;
  assert.equal(filtered.length, height * (stride + 1));
  const data = new Uint8Array(height * stride);
  const paeth = (a, b, c) => { const p = a + b - c, pa = Math.abs(p-a), pb = Math.abs(p-b), pc = Math.abs(p-c); return pa <= pb && pa <= pc ? a : pb <= pc ? b : c; };
  for (let y = 0; y < height; y++) {
    const filter = filtered[y * (stride + 1)]; assert.ok(filter <= 4);
    for (let x = 0; x < stride; x++) {
      const i = y * stride + x, a = x >= channels ? data[i-channels] : 0;
      const b = y ? data[i-stride] : 0, c = y && x >= channels ? data[i-stride-channels] : 0;
      const prior = [0, a, b, Math.floor((a+b)/2), paeth(a,b,c)][filter];
      data[i] = filtered[y * (stride + 1) + x + 1] + prior;
    }
  }
  let count = 0, minX = width, minY = height, maxX = -1, maxY = -1;
  for (let p = 0; p < width * height; p++) {
    const i = p * channels, r = data[i], g = data[i+1], b = data[i+2];
    if (r > 16 && b > 16 && g < 5 && Math.abs(r-b) < 5) {
      count++; const x = p % width, y = Math.floor(p / width);
      minX = Math.min(minX, x); maxX = Math.max(maxX, x); minY = Math.min(minY, y); maxY = Math.max(maxY, y);
    }
  }
  return { width, height, count, bounds: count ? { minX, minY, maxX, maxY } : null };
}
const { json: glb } = parseGLB(readFileSync(resolve(root, 'public/models/piling-leader.glb')));
const node = name => glb.nodes.find(n => n.name === name);
const carriage = node('slide:carriage'), ram = node('slide:hammer-ram'), cap = node('slide:drive-cap'), pile = node('slide:pile');
const rest = carriage.translation[1], ramRest = ram.translation[1];
const range = [rest + carriage.extras.travel_lo_m, rest + carriage.extras.travel_hi_m];
const cases = report.cases.map(c => {
  assert.equal(c.pause.sameActualSimulation, true); assert.equal(c.pause.sameSimulation, true); assert.equal(c.pause.sameRam, true);
  assert.deepEqual(c.pause.before.identity.actualSimulation, c.pause.after.identity.actualSimulation);
  const rows = c.captures.map(row => {
    const a = row.before, b = row.after, d = a.identity.renderedInput.drill;
    assert.equal(a.held, true); assert.equal(b.held, true); assert.deepEqual(a.identity, b.identity);
    assert.equal(a.observedFrame, b.observedFrame); assert.equal(a.observedFrame, a.identity.renderedInput.frame);
    if (row.request.phase) assert.equal(d.phase, row.request.phase);
    if (row.request.band) assert.ok(d.hammerPhase01 >= row.request.band[0] && d.hammerPhase01 <= row.request.band[1]);
    if (row.request.paused !== undefined) assert.equal(a.paused, row.request.paused);
    const expectedCarriage = Math.max(range[0], Math.min(range[1], rest - d.depth));
    assert.ok(Math.abs(a.identity.carriage.position[1] - expectedCarriage) < 1e-9);
    assert.deepEqual(a.identity.cap.position, cap.translation);
    const active = ['drilling', 'take-set'].includes(d.phase), t = d.hammerPhase01;
    const lift = active ? (t < .5 ? ease('reveal', t*2) : 1-ease('dismiss', (t-.5)*2)) : 0;
    const expectedRam = ramRest + lift * Math.min(ram.extras.stroke_m, d.hammerDropM || 0);
    assert.ok(Math.abs(a.identity.ram.position[1] - expectedRam) < 1e-9);
    const image = readFileSync(resolve(at, row.image)), mask = readFileSync(resolve(at, row.maskImage));
    assert.equal(sha(image), row.imageSha256);
    const p = pixels(mask); assert.equal(p.count, row.visibility.visiblePixels);
    assert.deepEqual(p.bounds, row.visibility.pixelBounds); assert.equal(row.visibility.restored, true);
    return { label: row.label, phase: d.phase, consumedDepth: d.depth, consumedCycle: t,
      carriageY: expectedCarriage, ramY: expectedRam, pixels: p.count, bounds: p.bounds,
      imageSha256: sha(image), maskSha256: sha(mask), assessment: row.assessment };
  });
  return { camera: c.camera, rows, errors: c.errors, httpFailures: c.httpFailures, requestFailures: c.requestFailures };
});
const result = { status: 'CAPTURE_REMAINS_FAILED', offlineChecksPassed: true, captureReportSha256: sha(raw),
  sourceUnchanged: true, sourceHarnessSha256: report.sourceBefore['tools/checkpilemotion-browser.mjs'],
  actualGLBSha256: sha(readFileSync(resolve(root, 'public/models/piling-leader.glb'))),
  authoredNodeOrigins: { carriage: carriage.translation, cap: cap.translation, pile: pile.translation },
  cases, unrecoverableEvidence: 'Rejected asset URLs were discarded by the classifier catch. Exact remote resources cannot be identified from these artifacts.',
  limits: 'Image hashes, actual decoded ID pixels, captured identity and authored pose relation verified offline. No full motion cadence, hidden clearance, static-pile penetration or real-phone acceptance.' };
writeFileSync(resolve(root, 'research/pile-corrected-capture-critic.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ status: result.status, checks: result.offlineChecksPassed,
  cases: cases.map(c => ({ camera: c.camera, frames: c.rows.length, zeroPixelFrames: c.rows.filter(r => !r.pixels).map(r => r.label) })) }));
