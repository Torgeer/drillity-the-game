/** Browser harness integration fixture with actual GLB/rig/simulator and Vite
 * asset transforms. Renderer and DOM are CPU fixtures, not visual evidence.
 * Synthetic timestep/controls are NOT SOURCED test inputs. No HTTP listener,
 * browser, GPU, geometry measurement or simulation phase mutation. */
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import * as THREE from 'three';
import { createServer } from 'vite';
import { createGltfRigs } from '../src/core/gltfRig.js';
import { createRigSystem } from '../src/rig/rigFactory.js';
import { createDrillSim } from '../src/sim/drilling.js';
import { createBus, createGameState, EVENTS } from '../src/core/contract.js';
import { RIGS, METHODS } from '../src/game/data.js';
import { ease } from '../src/core/motion.js';
import { classifyServedAsset, assessAssetResponse, assessCapture, installHarness } from './checkpilemotion-browser.mjs';

const root = fileURLToPath(new URL('..', import.meta.url));
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const paths = ['src/main.js', 'src/core/gltfRig.js', 'src/rig/rigFactory.js', 'src/sim/drilling.js',
  'src/core/motion.js', 'public/models/piling-leader.glb', 'tools/checkpilemotion-browser.mjs',
  'tools/checkpilevisual-harness.mjs', 'node_modules/vite/dist/node/chunks/dep-BK3b2jBa.js'];
const hashes = Object.fromEntries(paths.map(p => [p, sha(readFileSync(resolve(root, p)))]));
const report = { pass: false, hashes, assetCases: [], hold: null,
  limits: 'CPU integration with actual GLB/rig/simulator; mocked rendering/DOM and visibility do not establish visible geometry or browser acceptance.' };
const main = readFileSync(resolve(root, 'src/main.js'), 'utf8');
assert(main.indexOf("await loadSystem('rig'") < main.indexOf("await loadSystem('sim'"));
const saved = { document: globalThis.document, window: globalThis.window, fetch: globalThis.fetch, info: console.info };
let loader, rig, sim, harness, server;
const materials = new Map();
try {
  server = await createServer({ root, cacheDir: resolve(root, '.pile-vite-fixture-cache'),
    optimizeDeps: { noDiscovery: true, include: [] },
    server: { middlewareMode: true, watch: null, hmr: false }, appType: 'custom' });
  // Vite's transform middleware removes ?import before transformRequest. The
  // wire URL retains it; the imported module exports the raw source asset URL.
  for (const name of ['logo-full.png', 'logo-wordmark.png']) {
    const path = `src/ui/assets/${name}`, address = `http://127.0.0.1:5250/${path}`;
    const bytes = readFileSync(resolve(root, path)), files = { [path]: sha(bytes) };
    const module = (await server.transformRequest('/' + path)).code;
    for (const [url, body, contentType] of [[address, bytes, 'image/png'], [address + '?import', module, 'text/javascript']]) {
      report.assetCases.push(assessAssetResponse({ classification: classifyServedAsset(url, 'http://127.0.0.1:5250'),
        body, contentType, manifest: files }));
    }
  }
  await server.close(); server = null;
  globalThis.document = { baseURI: 'https://pile-visual-fixture.invalid/', visibilityState: 'visible', hasFocus: () => true };
  const bytes = readFileSync(resolve(root, 'public/models/piling-leader.glb'));
  globalThis.fetch = async value => { assert.equal(new URL(value).pathname, '/models/piling-leader.glb'); return new Response(bytes); };
  console.info = () => {};
  const assets = { material(name) {
    if (!materials.has(name)) { const m = new THREE.MeshStandardMaterial(); m.name = name; materials.set(name, m); }
    return materials.get(name);
  }, stats: () => ({ sets: 1, setsReady: 1, pending: 0, failed: 0 }) };
  const state = createGameState(); state.garage.rigId = 'piling-leader'; state.garage.loadout.hammer = 'impact-hammer-9t';
  state.contract = { id: 'cpu-fixture', methodId: 'driven-pile' };
  const scene = new THREE.Scene(), sectionScene = new THREE.Scene(), tip = new THREE.Object3D(); sectionScene.add(tip);
  const camera = new THREE.PerspectiveCamera(40, 1, .1, 1000); camera.position.set(0, 4, 40); camera.updateMatrixWorld();
  const counts = { rig: 0, sim: 0, presentation: 0, render: 0 };
  const info = { render: { calls: 1, triangles: 0 } };
  const c = { THREE, assets, state, scene, sectionScene, camera, bus: createBus(), EVENTS,
    data: { RIGS }, quality: { id: 'low' }, qs: new URLSearchParams('glb=strict'),
    clock: { t: 0, dt: 0, frame: 0, fps: 60 }, viewport: { width: 390, height: 844 },
    ui: { gameplayPaused: false, currentScene: 'site' }, progression: { run: null },
    geology: { boreholeTip: tip, worldYForDepth: d => -d, holeRadiusAt: () => .15 },
  };
  c.renderer = { cameraMode: 'hero', bands: { surface: { x: 0, y: 0, w: 390, h: 300 } },
    gl: { info, domElement: { width: 390, height: 844 }, getContext: () => ({ isContextLost: () => false }) },
    render() { counts.render++; scene.updateMatrixWorld(true); camera.updateMatrixWorld(true); },
  };
  loader = createGltfRigs(c); c.gltfRigs = loader; await loader.load('piling-leader');
  rig = createRigSystem(c); c.rig = rig; rig.setMethod('driven-pile'); await rig.init();
  sim = createDrillSim(c); c.sim = sim;
  const actualRigUpdate = rig.update, actualSimUpdate = sim.update;
  rig.update = (...args) => { counts.rig++; return actualRigUpdate(...args); };
  sim.update = (...args) => { counts.sim++; return actualSimUpdate(...args); };
  c.systems = [rig, sim, { update() { counts.presentation++; } }];
  globalThis.window = { __DRILLITY: c, __PILE_SETUP: { sheet: { close() {} } } };
  sim.startHole({ methodId: 'driven-pile', method: METHODS.find(m => m.id === 'driven-pile'),
    targetDepth: 30, ground: ['clay'], seed: 4262 });
  installHarness(); harness = window.__PILE_BROWSER;
  const step = (dt = 1 / 60) => { c.clock.dt = dt; c.clock.t += dt; c.clock.frame++; state.tSec += dt;
    for (const s of c.systems) s.update(dt, state); c.renderer.render(dt);
  };
  const request = { phase: 'drilling', band: [.15, .30] }; harness.arm(request);
  let steps = 0; while (!harness.held && steps++ < 2000) step();
  assert(harness.held, 'actual simulator reaches the requested consumed-input phase');
  const before = harness.snapshot(), calls = { ...counts }, physical = structuredClone(before.identity.actualSimulation);
  const consumed = before.identity.renderedInput.drill;
  const ram = rig.group.getObjectByName('slide:hammer-ram');
  const raw = JSON.parse(bytes.subarray(20, 20 + bytes.readUInt32LE(12)));
  const authoredRam = raw.nodes.find(n => n.name === ram.name);
  const lift = consumed.hammerPhase01 < .5 ? ease('reveal', consumed.hammerPhase01 * 2)
    : 1 - ease('dismiss', (consumed.hammerPhase01 - .5) * 2);
  const expectedY = authoredRam.translation[1] + Math.min(authoredRam.extras.stroke_m, consumed.hammerDropM) * lift;
  assert(Math.abs(ram.position.y - expectedY) < 1e-9, 'actual ram matches consumed input, not next published cycle');
  for (let i = 0; i < 90; i++) step(.25);
  const after = harness.snapshot();
  assert.deepEqual(counts, calls, 'no original callbacks occur during held main ticks');
  assert.deepEqual(after.identity, before.identity, 'actual sim/pose/camera/clock remains exact');
  assert.deepEqual(after.identity.actualSimulation, physical);
  // A synthetic positive mask tests adjudication only, never rendered pixels.
  assert(assessCapture({ request, before, after, visibility: { valid: true, visiblePixels: 1, restored: true } }).valid);
  const wrong = structuredClone(before); wrong.identity.renderedInput.drill.hammerPhase01 = .8;
  assert(!assessCapture({ request, before: wrong, after: wrong, visibility: { valid: true, visiblePixels: 1, restored: true } }).valid);
  harness.release(); step();
  for (const key of Object.keys(counts)) assert.equal(counts[key], calls[key] + 1, `${key} resumes once`);
  report.hold = { stepsToCapture: steps, heldMainTicks: 90, consumed: before.identity.renderedInput,
    latestSimulation: physical, ramY: before.identity.ram.position[1], callbacksBeforeHold: calls, callbacksAfterResume: counts };
  report.pass = true;
} finally {
  harness?.cleanup(); rig?.dispose(); sim?.dispose(); loader?.dispose(); await server?.close();
  for (const material of materials.values()) material.dispose();
  globalThis.document = saved.document; globalThis.window = saved.window; globalThis.fetch = saved.fetch; console.info = saved.info;
}
for (const path of paths) assert.equal(sha(readFileSync(resolve(root, path))), hashes[path], `source changed: ${path}`);
const index = process.argv.indexOf('--json');
if (index >= 0) writeFileSync(resolve(root, process.argv[index + 1]), JSON.stringify(report, null, 2));
console.log(JSON.stringify(report));
