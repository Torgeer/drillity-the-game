/** Independent CPU review of browser-harness control logic, not pixels.
 * Synthetic scene, clock and draw records are NOT SOURCED fixtures.
 * node tools/checkpilevisual-adversarial.mjs
 * Never starts a browser, Vite server, WebGL context or Blender.
 */
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync, readdirSync, statSync, realpathSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve, relative } from 'node:path';
import { fileURLToPath } from 'node:url';
import * as THREE from 'three';

const ROOT = fileURLToPath(new URL('../', import.meta.url));
const candidatePath = resolve(ROOT, 'tools/checkpilemotion-browser.mjs');
const baselinePath = resolve(ROOT, '../drillity-coordination/resume-70-baseline-2026-09-08/tools/checkpilemotion-browser.mjs');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const candidateSource = readFileSync(candidatePath, 'utf8'), baselineSource = readFileSync(baselinePath, 'utf8');
const candidateHash = sha(readFileSync(candidatePath)), baselineHash = sha(readFileSync(baselinePath));
const candidate = await import('./checkpilemotion-browser.mjs');
const cases = [], originalGlobals = {};
for (const key of ['window', 'document', 'requestAnimationFrame', 'cancelAnimationFrame']) originalGlobals[key] = globalThis[key];
function extractFunction(source, name, bindings = {}) {
  // The reviewed files place these two functions between column-zero function
  // declarations (or at EOF). Preserve their exact bodies without executing the
  // historical CLI. This is bounded extraction, not a general JavaScript parser.
  assert.ok(['manifest', 'installHarness'].includes(name));
  const start = new RegExp(`^(?:export )?function ${name}\\(`, 'm').exec(source);
  assert.ok(start, `function ${name} exists`);
  const tail = source.slice(start.index).replace(/^export /, '');
  const next = /\r?\n(?:export )?(?:async )?function /g.exec(tail);
  const code = (next ? tail.slice(0, next.index) : tail).trim();
  assert.ok(code.endsWith('}'));
  return Function(...Object.keys(bindings), `return (${code});`)(...Object.values(bindings));
}
function fixture(install) {
  const spec = { id: 'piling-leader', source: 'glb' }, root = new THREE.Group(); root.userData.spec = spec; root.name = 'rig:piling-leader';
  const group = new THREE.Group(); group.add(root);
  const carriage = new THREE.Group(); carriage.name = 'slide:carriage'; root.add(carriage);
  const ram = new THREE.Group(); ram.name = 'slide:hammer-ram'; ram.position.y = 1.1; ram.userData.stroke_m = 1.2; carriage.add(ram);
  const cap = new THREE.Group(); cap.name = 'slide:drive-cap'; carriage.add(cap);
  const material = new THREE.MeshStandardMaterial(); material.name = 'critic-material';
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1), material); mesh.name = 'hammer_ram'; ram.add(mesh);
  const camera = new THREE.PerspectiveCamera(); camera.updateMatrixWorld();
  const scene = new THREE.Scene(); scene.add(group); scene.updateMatrixWorld(true);
  const counts = { rendererUpdate: 0, rig: 0, sim: 0, ui: 0, render: 0 };
  const state = { tSec: 0, contract: { id: 'critic-contract', methodId: 'driven-pile' }, garage: { loadout: { hammer: 'impact-hammer-9t' } },
    drill: { active: true, phase: 'drilling', programme: 'driven-pile', methodId: 'driven-pile', timeSec: 0,
      depth: 0, actionDepth: 0, phaseT: 0, phaseDur: 1, hammerPhase01: .1, hammerDropM: .6, blows: 0 } };
  const clock = { t: 0, dt: 0, fps: 60, frame: 0 };
  const glState = { target: null, viewport: new THREE.Vector4(0, 40, 390, 297),
    scissor: new THREE.Vector4(0, 40, 390, 297), scissorTest: true,
    clearColor: new THREE.Color(.2, .3, .4), clearAlpha: .7 };
  const shaderInputs = [];
  let throwDuringDiagnostic = false;
  const gl = { domElement: { width: 780, height: 1688 }, info: { render: { calls: 57, triangles: 300 }, reset() { this.render.calls = 0; } },
    getContext: () => ({ isContextLost: () => false }), getPixelRatio: () => 2,
    autoClear: false, shadowMap: { autoUpdate: true },
    getRenderTarget: () => glState.target, setRenderTarget(target) { glState.target = target; },
    getViewport: out => out.copy(glState.viewport), setViewport(value) { glState.viewport.copy(value); },
    getScissor: out => out.copy(glState.scissor), setScissor(value) { glState.scissor.copy(value); },
    getScissorTest: () => glState.scissorTest, setScissorTest(value) { glState.scissorTest = value; },
    getClearColor: out => out.copy(glState.clearColor), getClearAlpha: () => glState.clearAlpha,
    setClearColor(value, alpha) { glState.clearColor.set(value); if (alpha !== undefined) glState.clearAlpha = alpha; },
    clear() {},
    render(scene) {
      scene.traverse(node => { for (const m of [node.material].flat().filter(Boolean)) {
        const shader = { fragmentShader: 'void main() { if (false) discard; gl_FragColor = vec4(1.0); }' };
        m.onBeforeCompile(shader, gl); shaderInputs.push(shader.fragmentShader);
      } });
      gl.info.render.calls = 2;
      if (throwDuringDiagnostic) throw Error('critic diagnostic failure');
    },
    readRenderTargetPixels(target, x, y, w, h, out) { out.fill(0); out.set([255, 0, 255, 255]); },
  };
  const renderer = { gl, cameraMode: 'hero', bands: { surface: { x: 0, y: 40, w: 390, h: 297 } },
    update() { counts.rendererUpdate++; },
    render() { counts.render++; scene.updateMatrixWorld(true); gl.info.render.calls = 57; return 'original-render'; } };
  const rig = { group, getSpec: () => spec, getMethodId: () => 'driven-pile', update(dt, supplied) { counts.rig++; ram.position.y = 1 + supplied.drill.hammerPhase01; } };
  const sim = { update(dt) { counts.sim++; if (dt > 0) {
    state.drill.timeSec += dt; state.drill.depth += .01; state.drill.actionDepth = state.drill.depth;
    state.drill.hammerPhase01 = (state.drill.hammerPhase01 + .2) % 1;
  } } };
  sim.debug = { get state() { return { ...state.drill, blowPhase: state.drill.hammerPhase01 }; } };
  const ui = { currentScene: 'site', gameplayPaused: false, update() { counts.ui++; },
    sheet() { ui.gameplayPaused = true; return { close() { ui.gameplayPaused = false; } }; } };
  const c = { THREE, rig, renderer, sim, ui, camera, scene, state, clock, systems: [renderer, rig, sim, ui],
    assets: { stats: () => ({ sets: 1, setsReady: 1, pending: 0, failed: 0 }) },
    terrain: { siteModel: { requested: false } }, progression: { run: { runId: 1, attemptId: 2 } },
    viewport: { w: 390, h: 844, dpr: 2 }, quality: { id: 'high' } };
  for (const name of ['renderer', 'rig', 'sim', 'ui']) c[name].__name = name;
  globalThis.document = { visibilityState: 'visible', hasFocus: () => true,
    createElement(tag) {
      assert.equal(tag, 'canvas');
      return { width: 0, height: 0, getContext(kind) { assert.equal(kind, '2d'); return {
        createImageData(w, h) { return { data: new Uint8ClampedArray(w * h * 4) }; }, putImageData() {},
      }; }, toDataURL() { return 'data:image/png;base64,c3ludGhldGlj'; } };
    } };
  globalThis.window = { __DRILLITY: c, __PILE_SETUP: { sheet: { close() {} } } };
  globalThis.requestAnimationFrame = () => 1; globalThis.cancelAnimationFrame = () => {};
  const installed = install();
  const api = window.__PILE_BROWSER;
  function tick() {
    const dt = 1 / 60; clock.t += dt; clock.dt = dt; clock.frame++; state.tSec += dt;
    for (const system of c.systems) system.update(dt, state);
    renderer.render(dt);
  }
  return { c, counts, ram, api, installed, tick, material, mesh, glState, shaderInputs,
    failDiagnostic(value) { throwDuringDiagnostic = value; },
    cleanup() { api.cleanup(); mesh.geometry.dispose(); material.dispose(); } };
}
function run(name, fn) {
  try { const evidence = fn(); cases.push({ name, passed: true, evidence }); }
  catch (error) { cases.push({ name, passed: false, error: String(error.stack || error) }); }
}
try {
  run('Frozen inventory includes every actual linked GLB and rejects unauthorized junction targets', () => {
    const files = candidate.manifest(), modelPaths = [];
    const discover = at => { for (const name of readdirSync(at)) {
      const path = resolve(at, name);
      if (statSync(path).isDirectory()) discover(path); else if (name.endsWith('.glb')) modelPaths.push(path);
    } };
    discover(resolve(ROOT, 'public/models'));
    assert.ok(modelPaths.length >= 19, 'actual fleet files must be present');
    for (const path of modelPaths) {
      const key = relative(ROOT, path).replaceAll('\\', '/');
      assert.equal(files[key], sha(readFileSync(path)), key);
    }
    const key = 'public/models/piling-leader.glb', body = readFileSync(resolve(ROOT, key));
    const classification = candidate.classifyServedAsset('http://127.0.0.1:5250/models/piling-leader.glb', 'http://127.0.0.1:5250');
    assert.equal(candidate.assessAssetResponse({ classification, body, contentType: 'model/gltf-binary', manifest: files }).sha256, files[key]);
    const entries = name => [{ name, isSymbolicLink: () => true, isDirectory: () => false, isFile: () => false }];
    const badTarget = extractFunction(candidateSource, 'manifest', { root: ROOT, resolve, relative, sha, readFileSync,
      readdirSync: at => at === resolve(ROOT, 'public') ? entries('models') : [],
      realpathSync: path => path });
    assert.throws(() => badTarget(), /Unapproved manifest link/);
    const otherLink = extractFunction(candidateSource, 'manifest', { root: ROOT, resolve, relative, sha, readFileSync,
      readdirSync: at => at === resolve(ROOT, 'src') ? entries('unexpected') : [], realpathSync });
    assert.throws(() => otherLink(), /Unapproved manifest link/);
    const historical = extractFunction(baselineSource, 'manifest', { root: ROOT, resolve, relative, sha, readFileSync, readdirSync });
    assert.ok(!Object.hasOwn(historical(), key), 'historical inventory really omits the same linked piling asset');
    return { files: Object.keys(files).length, actualGLBFiles: modelPaths.length, pilingSha256: files[key],
      rejected: ['wrong junction target', 'unexpected linked path'], historicalControl: 'piling GLB omitted' };
  });
  run('Observed source raw image and its Vite import wrapper have distinct verifiable classifications', () => {
    const origin = 'http://127.0.0.1:5250';
    const path = 'src/ui/assets/logo-full.png', body = readFileSync(resolve(ROOT, path));
    const files = { [path]: sha(body) };
    const raw = candidate.classifyServedAsset(`${origin}/${path}`, origin);
    assert.equal(raw.kind, 'raw'); assert.equal(raw.path, path);
    const observed = candidate.assessAssetResponse({ classification: raw, body, contentType: 'image/png', manifest: files });
    assert.equal(observed.sha256, files[path]);
    const module = candidate.classifyServedAsset(`${origin}/${path}?import`, origin);
    assert.equal(module.kind, 'vite-asset-module'); assert.equal(module.path, path);
    const code = `export default "/${path}";`;
    const map = Buffer.from(JSON.stringify({ version: 3, sources: [`/${path}?import`], sourcesContent: [code], mappings: '' })).toString('base64');
    for (const body of [code, code + '\n//# sourceMappingURL=data:application/json;base64,' + map]) {
      const result = candidate.assessAssetResponse({ classification: module, body,
        contentType: 'text/javascript; charset=utf-8', manifest: files });
      assert.equal(result.exportedURL, `${origin}/${path}`);
      assert.equal(result.sourceSha256, files[path]);
      assert.notEqual(result.sha256, files[path], 'wrapper body hash is not misrepresented as the raw PNG hash');
    }
    return { rawSourcePath: raw.path, moduleSourcePath: module.path, rawSha256: observed.sha256 };
  });
  run('Asset mapping rejects unexpected origin, query, escaped paths, unknown source and changed bytes', () => {
    const origin = 'http://127.0.0.1:5250', path = 'src/ui/assets/logo-full.png';
    for (const url of [`https://example.invalid/${path}`, `${origin}/${path}?raw`, `${origin}/${path}?import&t=1`,
      `${origin}/@fs/C:/outside.png`, `${origin}/src/%2foutside.png`, `${origin}/src/%5coutside.png`, `${origin}/src/%00outside.png`]) {
      assert.throws(() => candidate.classifyServedAsset(url, origin), /origin|query|path/);
    }
    const raw = candidate.classifyServedAsset(`${origin}/${path}`, origin), body = readFileSync(resolve(ROOT, path));
    assert.throws(() => candidate.assessAssetResponse({ classification: raw, body, contentType: 'image/png', manifest: {} }), /manifest/);
    assert.throws(() => candidate.assessAssetResponse({ classification: raw, body: Buffer.from('different'), contentType: 'image/png', manifest: { [path]: sha(body) } }), /differs/);
    for (const contentType of ['text/html', 'text/javascript']) assert.throws(() => candidate.assessAssetResponse({
      classification: raw, body, contentType, manifest: { [path]: sha(body) } }), /Raw asset/);
  });
  run('Vite wrappers cannot disguise executable code, a different resource or mismatched source map', () => {
    const origin = 'http://127.0.0.1:5250', path = 'src/ui/assets/logo-full.png';
    const classification = candidate.classifyServedAsset(`${origin}/${path}?import`, origin), files = { [path]: 'source-hash-fixture' };
    for (const body of [`export default "/other.png";`, `export default "https://example.invalid/${path}";`,
      `export default "/${path}?different";`, `export default "/${path}"; alert(1);`, '<html>Not an asset module</html>']) {
      assert.throws(() => candidate.assessAssetResponse({ classification, body, contentType: 'text/javascript', manifest: files }));
    }
    assert.throws(() => candidate.assessAssetResponse({ classification, body: `export default "/${path}";`, contentType: 'image/png', manifest: files }), /content type/);
    const map = Buffer.from(JSON.stringify({ version: 3, sourcesContent: ['different code'] })).toString('base64');
    assert.throws(() => candidate.assessAssetResponse({ classification,
      body: `export default "/${path}";\n//# sourceMappingURL=data:application/json;base64,${map}`,
      contentType: 'text/javascript', manifest: files }), /sourcemap/);
  });
  run('Natural render selection follows rig-consumed input, not newer simulation state', () => {
    const f = fixture(candidate.installHarness);
    try {
      f.api.arm({ phase: 'drilling', band: [.099, .101] }); f.tick();
      assert.ok(f.api.held, 'render whose rig consumed phase .1 must be selected even though latest sim phase is .3');
      assert.ok(Math.abs(f.ram.position.y - 1.1) < 1e-9);
      assert.ok(Math.abs(f.c.state.drill.hammerPhase01 - .3) < 1e-9);
      return { renderedRamY: f.ram.position.y, latestSimPhase: f.c.state.drill.hammerPhase01, snapshot: f.api.snapshot() };
    } finally { f.cleanup(); }
  });
  run('Held frame invokes no system/render callbacks; complete captured state is stable', () => {
    const f = fixture(candidate.installHarness);
    try {
      f.api.arm({ phase: 'drilling' }); f.tick(); assert.ok(f.api.held);
      const before = f.api.snapshot(), counts = { ...f.counts }, ramY = f.ram.position.y;
      for (let i = 0; i < 12; i++) f.tick();
      assert.deepEqual(f.counts, counts, 'dt0 callbacks are not inert and must not run during hold');
      assert.equal(f.ram.position.y, ramY);
      assert.deepEqual(f.api.snapshot().identity, before.identity, 'held identity/pose/clock must remain exact');
      f.api.release(); f.tick();
      for (const key of Object.keys(counts)) assert.equal(f.counts[key], counts[key] + 1, `${key} resumes once`);
      return { countsWhileHeld: counts };
    } finally { f.cleanup(); }
  });
  run('Independent adjudication rejects mislabeled phase, frame, clock, camera and zero visibility', () => {
    const f = fixture(candidate.installHarness);
    try {
      const request = { phase: 'drilling', band: [.099, .101] };
      f.api.arm(request); f.tick(); assert.ok(f.api.held);
      const endpoint = f.api.snapshot();
      const row = { request, before: endpoint, after: structuredClone(endpoint),
        visibility: { valid: true, visiblePixels: 16, restored: true } };
      assert.ok(candidate.assessCapture(row).valid, 'valid control fixture accepted');
      const changes = [
        ['zero visibility', r => { r.visibility.visiblePixels = 0; }],
        ['unrestored shader', r => { r.visibility.restored = false; }],
        ['different observed frame', r => { r.after.observedFrame++; }],
        ['camera changes', r => { r.after.identity.camera.fov++; }],
        ['real clock changes', r => { r.after.identity.actualSimulation.timeSec++; }],
        ['main clock changes', r => { r.after.identity.clock.frame++; }],
        ['wrong consumed phase', r => { for (const s of [r.before, r.after]) s.identity.renderedInput.drill.phase = 'dolly-change'; }],
        ['wrong consumed method', r => { for (const s of [r.before, r.after]) s.identity.renderedInput.method = 'rotary-kelly'; }],
        ['different consumed frame', r => { for (const s of [r.before, r.after]) s.identity.renderedInput.frame++; }],
        ['outside requested band', r => { for (const s of [r.before, r.after]) s.identity.renderedInput.drill.hammerPhase01 = .8; }],
        ['missing consumed input', r => { for (const s of [r.before, r.after]) delete s.identity.renderedInput; }],
        ['invalid requested band', r => { r.request.band = [.9, .1]; }],
        ['wrong pause criterion', r => { r.request.paused = true; }],
        ['missing request', r => { delete r.request; }],
      ];
      for (const [name, change] of changes) { const bad = structuredClone(row); change(bad); assert.ok(!candidate.assessCapture(bad).valid, name); }
      return { rejectedMutations: changes.map(([name]) => name) };
    } finally { f.cleanup(); }
  });
  run('Diagnostic restores cyclic material metadata, shader hooks, assignments and render state', () => {
    const f = fixture(candidate.installHarness);
    try {
      const data = f.material.userData, oldShader = { original: true }; data.self = data; data.shader = oldShader;
      Object.defineProperty(data, 'hidden', { value: 'preserve descriptor', enumerable: false, writable: false, configurable: true });
      const descriptors = Object.getOwnPropertyDescriptors(data);
      f.material.onBeforeCompile = function(shader) { f.material.userData.shader = shader; f.material.userData.temporary = shader; };
      const oldHook = f.material.onBeforeCompile;
      const other = new THREE.Mesh(f.mesh.geometry, [f.material]); f.c.scene.add(other);
      const otherMaterials = other.material;
      f.api.arm({ phase: 'drilling' }); f.tick();
      const before = f.api.snapshot(), counts = { ...f.counts }, state = structuredClone(f.glState);
      const result = f.api.visibility();
      assert.ok(result.valid && result.restored, 'synthetic diagnostic control reports restoration');
      assert.equal(result.visiblePixels, 1, 'fake raster supplies exactly one ID pixel; this is not real visibility evidence');
      assert.equal(f.material.userData, data); assert.deepEqual(Object.getOwnPropertyDescriptors(data), descriptors);
      assert.equal(f.material.onBeforeCompile, oldHook); assert.equal(f.mesh.material, f.material); assert.equal(other.material, otherMaterials);
      assert.deepEqual(structuredClone(f.glState), state); assert.equal(f.c.renderer.gl.autoClear, false);
      assert.equal(f.c.renderer.gl.shadowMap.autoUpdate, true); assert.equal(f.c.scene.background, null);
      assert.equal(f.shaderInputs.length, 2);
      assert.ok(f.shaderInputs.every(s => s.includes('if (false) discard;')), 'diagnostic retains discard code');
      assert.ok(f.shaderInputs.some(s => s.includes('vec3(1.0, 0.0, 1.0)')), 'target receives ID color');
      assert.ok(f.shaderInputs.some(s => s.includes('vec3(0.0)')), 'non-target remains an occluder');
      assert.deepEqual(f.api.snapshot().identity, before.identity); assert.deepEqual(f.counts, counts);
      assert.equal(result.draw.calls, 2); assert.equal(f.api.snapshot().draw.calls, 57, 'beauty draw count remains explicitly cached, not diagnostic count');
      return { syntheticDiagnosticCalls: result.draw.calls, cachedBeautyCalls: before.draw.calls, noPixelAcceptance: true };
    } finally { f.cleanup(); }
  });
  run('Diagnostic exception restores scene and renderer before propagation and permits clean retry', () => {
    const f = fixture(candidate.installHarness);
    try {
      const data = f.material.userData; data.self = data;
      f.material.onBeforeCompile = shader => { data.temporary = shader; };
      f.api.arm({ phase: 'drilling' }); f.tick();
      const before = f.api.snapshot(), state = structuredClone(f.glState), counts = { ...f.counts };
      f.failDiagnostic(true);
      assert.throws(() => f.api.visibility(), /critic diagnostic failure/);
      assert.equal(f.mesh.material, f.material); assert.equal(f.material.userData, data); assert.ok(!Object.hasOwn(data, 'temporary'));
      assert.deepEqual(structuredClone(f.glState), state); assert.equal(f.c.renderer.gl.autoClear, false);
      assert.equal(f.c.renderer.gl.shadowMap.autoUpdate, true);
      assert.deepEqual(f.api.snapshot().identity, before.identity); assert.deepEqual(f.counts, counts);
      f.failDiagnostic(false); assert.ok(f.api.visibility().restored);
    } finally { f.cleanup(); }
  });
  run('Historical counterfactual fails rendered-input selection', () => {
    const f = fixture(extractFunction(baselineSource, 'installHarness'));
    try { f.api.arm({ phase: 'drilling', band: [.099, .101] }); f.tick(); assert.ok(!f.api.held); }
    finally { f.cleanup(); }
  });
  run('Historical counterfactual changes its held ram through zero-delta rig update', () => {
    const f = fixture(extractFunction(baselineSource, 'installHarness'));
    try {
      f.api.arm({ phase: 'drilling' }); f.tick(); assert.ok(f.api.held);
      const before = f.ram.position.y, count = f.counts.rig; f.tick();
      assert.equal(f.counts.rig, count + 1); assert.notEqual(f.ram.position.y, before);
      return { before, after: f.ram.position.y };
    } finally { f.cleanup(); }
  });
} finally { for (const [key, value] of Object.entries(originalGlobals)) globalThis[key] = value; }
assert.equal(sha(readFileSync(candidatePath)), candidateHash, 'candidate source stayed frozen');
const sourcePaths = ['src/main.js', 'src/core/gltfRig.js', 'src/rig/rigFactory.js', 'src/sim/drilling.js',
  'public/models/piling-leader.glb', 'node_modules/three/build/three.module.js'];
const report = { passed: cases.every(c => c.passed), candidateHash, baselineHash,
  criticToolHash: sha(readFileSync(fileURLToPath(import.meta.url))),
  sources: Object.fromEntries(sourcePaths.map(path => [path, sha(readFileSync(resolve(ROOT, path)))])), cases,
  limits: 'Synthetic CPU control-flow fixtures only. No actual rendering, visibility, appearance, cadence or clearance acceptance.' };
writeFileSync(resolve(ROOT, 'research/pile-visual-critic.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
process.exitCode = report.passed ? 0 : 1;
