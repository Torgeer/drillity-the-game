# Cab glass: incomplete visual evidence, no integration approval

The overall `glass-01` capture is **INVALID**. Do not integrate or approve the three-bucket production change from this run. Four completed cases provide bounded evidence; CFA fell back to a rejected QA stub and SI was never attempted. Oil and piling also lack adequate visible pane coverage from their selected diagnostic directions.

## Exact artifacts and independent verification

| Artifact | SHA-256 |
| --- | --- |
| `evidence/graphics/glass-01/report.json` | `37db70154eb7c92e76002e03580d8a06394d3015f4f1b04f03ca4f2c0ae7a8d9` |
| Captured `validateglass-source.mjs` | `a47f530ff58c4a4f032aa3a3b8eb3f4996535ffebb2979cdda64459480c07a23` |
| `research/glass-capture-independent-2026-09-08.json` | `223eb3467ada06c460d6ef3d00cb5fd37a3999ef0ae43addab35dbb05c06e2c5` |

The independent tool `tools/auditglasscapture-independent.py` checks all 16 matched PNG hashes, decodes native RGB pixels, rechecks before/after and cross-capture control identities, verifies selected responses, zero transmission and non-target dispatch equality, and reports every repeat difference. Run with a Python environment containing Pillow and NumPy. The inspected bundled command was:

```
C:/Users/henri/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe tools/auditglasscapture-independent.py
```

Result: metadata checks pass, strict overall gate exits **1**. Both the original capture failure and non-exact repeat pixels remain failures; no threshold was relaxed. No new browser, GPU capture, image modification, geometry or production edit was performed by this critic.

## What the actual native images show

All eight primary A/B images and both unpaired wide images were viewed at their native 780 by 1688 resolution.

| Case | Bounded visual finding | Pixel controls |
| --- | --- | --- |
| Longhole orbit | The pale gray pane becomes darker and a horizontal line behind it becomes visible. The surrounding frame remains discernible. This is useful qualitative evidence of the intended material response in this one view; the scene still has severe existing underground glare/darkness elsewhere. | Full-frame A/A changes 620 pixels, B/B 626. In the manually selected visible pane rectangle `[310,380,357,475]`, each repeat differs at two pixels by one green level; A/B changes all 4,465 pixels, with RGB mean absolute differences `[13.8482,14.9751,14.4717]` on the 0–255 scale. Strong local effect, but not exact full-frame repetition. |
| Oil diagnostic focus | A large opaque painted cabin wall fills the pane's projected region. The panes cannot be judged. The material dispatch proves submission, not visible pixels. Reject this view as oil-glass appearance evidence. | The projected rectangle `[273,331,514,438]` has **zero** changed pixels for A/B, A/A or B/B. Full-frame A/A has 17 one-level pixel differences; B/B is exact. |
| Piling diagnostic focus | The leader obstructs most of the cab. A narrow bright strip changes, but the image cannot establish the five-pane bucket's readability or absence of excessive darkening. Reject broad piling appearance acceptance. | A-repeat/B-repeat changes 630 pixels confined to `[431,314,465,383]`. Full-frame A/A changes 445 pixels; B/B is exact. The 33,660-pixel projected bucket rectangle is mostly an occluder, not visible glazing. |
| DTH mixed control | The whole rendered image remains unchanged, including its still-pale shared glass, steel, terrain and site props. This is an accepted unchanged control for the captured view. | All four images are pixel-identical, and their PNG bytes match. |
| CFA mixed control | No images. QA warned that it found no generated CFA contract, returned a stub, and the harness correctly rejected it. | Not tested. |
| SI lens control | The fail-fast series stopped before this case. | Not attempted. |

The unpaired oil/piling wide images explain scale and placement. They are candidate-only context and cannot establish a wide-view before/after improvement. The focused cases were explicitly disclosed as diagnostic views, not normal gameplay camera acceptance.

## Scene and runtime controls actually captured

All four completed cases have identical held camera/graph/material controls across the quartet, except the intended selected color/opacity/side. Exact raw material responses match the A or B label before and after each image. Actual imported site models were present: underground-drive for longhole, well-pad for oil and DTH, urban-plot for piling. Their graphs have respectively 4, 6, 6 and 5 material-provenance rows. All non-target object dispatch maps match exactly, including the actual site clones. The source manifests match before/after and cleanup reports restored state and closed all five opened contexts, the browser and the owned Vite server. Independent port inspection found no listener on 5231, and the coordination lease was `idle` at inspection.

| Case | Whole game dispatches A to B | Rig-owned dispatches A to B | Target object A to B |
| --- | --- | --- | --- |
| Longhole | 195 to 194 | 108 to 107 | 2 to 1 |
| Oil | 142 to 141 | 33 to 32 | 3 to 2 |
| Piling | 223 to 222 | 132 to 131 | 3 to 2 |
| DTH | 276 to 276 | 147 to 147 | no target |

These are whole-render dispatches including applicable shadow/post passes. They prove no added dispatches in these cases; they are not the standalone 70-call rig budget and do not measure FPS or phone performance.

Warnings are preserved. Completed cases are unpaid QA previews. Oil additionally reports its existing missing `FLUSH_MEDIUM` mapping and incorrect AIR plume. CFA reports a stub contract and missing flush medium. None of these captures approves gameplay, payment, ground realism or VFX.

## Concrete next work for handover

1. Keep this failed run intact and the entire production delta pending. Preserve the earlier CPU approval separately; it cannot substitute for the missing visual controls.
2. Fix **view direction**, not geometry or material scope. For oil, the committed builder puts its windows on the cabin's negative Blender-Y face and positive Blender-X face (`oil_derrick.py`, `cabin-window` and `cabin-window-s`). Derive the corresponding outward normals from the actual exported primitive/world transform and pass an explicit `dir` to the existing `focusOn` API from a windowed exterior side. Do not reuse the inherited camera-to-bucket-center direction that sees the solid rear wall.
3. For piling, use an exterior side-pane/door direction that clears the leader. `piling_leader.py` provides the cabfront, cabsideU and cabdoor face locations; the door is on the negative Blender-X side. Derive the runtime direction from the actual exported geometry and transforms. Check ray intersections against the full scene and inspect a native preview for visible panes before fixing the camera for a new quartet. Do not remove or hide the leader/site geometry to manufacture visibility.
4. Resolve the CFA contract-fixture problem through an actual generated and valid case. Keep the non-stub guard. Complete CFA and SI unchanged-control quartets after that, and retain exact image-repeat checks. A fallback to a stub is not an acceptable substitute.
5. Investigate and eliminate or explicitly isolate the observed repeat drift before claiming deterministic full-frame comparisons. The longhole pane effect is much larger than its local repeat drift, but this report does not turn that observation into a relaxed global gate. A new capture requires the root's serial GPU grant; none is authorized in this review.

The earlier accepted steel-02 scope and its Nordic orbit baseline-repeat limitation remain unchanged. No all-fleet glass, full-scene contrast, normal camera, phone or performance completion claim follows from this work.
