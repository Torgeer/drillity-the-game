# Independent glazing scope review — 8 September 2026

**Three candidate buckets have positive cab-only source evidence. CFA's
`static:glass` is rejected.** This is a scope decision before any material
implementation or GPU acceptance; it does not approve an appearance change.

Baseline is the read-only `resume-70-baseline-2026-09-08` snapshot. Its full
manifest is copied as `research/glass-baseline-manifest-2026-09-08.json`.
The independent report `glass-bindings-independent-2026-09-08.json` records
actual model bytes/hashes, material bindings, node ancestry, primitive
attributes/counts/extras, Python source hashes and every MAT_GLASS source line.
It scans all 19 fleet models, all ten site models and the separate test fixture.
Fifteen fleet rigs contain glass; none of the ten shipped site GLBs does.

## Positive candidate scope

| Rig and exact node | Source-only glass uses | Actual GLB positions / indices |
| --- | --- | ---: |
| oil-derrick / `static:glass` | Two cabin windows in `blender/oil_derrick.py:963` and `:965` | 48 / 72 |
| longhole-rig / `front:glass` | Front, rear, left and right cab panes in `blender/longhole_rig.py:901–910` | 96 / 144 |
| piling-leader / `upper_glass` | Front, roof, two upper sides and door in `blender/piling_leader.py:739–748`, merged at `:890` | 120 / 180 |

The three source files' complete MAT_GLASS uses were inspected. Oil lamps use
steel/hazard materials. Longhole's four glass boxes belong to its articulated
operator station. Piling's glass list has only the five named cab panes before
the explicit upper_glass merge. Each actual GLB has one glass primitive bucket,
with counts consistent with those authored boxes. Counts and names corroborate
this source reading; neither alone proves semantics.

## Required unchanged negatives

- **CFA / static:glass is mixed.** Five cab panes are followed by six lampglass
  boxes in `build_lights()` (`blender/cfa_rig.py:1170`). Only mastMid and mastHead
  are added to the mast group. CabL, cabR, collar and deckRear remain static.
  Nine static boxes correspond to the actual 216 positions; the two mast lamps
  correspond to 48. A cab selector must reject both buckets.
- **DTH / static:glass is mixed.** The source assigns glass to a hydraulic gauge,
  cab panes, screenface and lamp lenses. The shipped bucket has 2,160 positions.
  Tinting the whole group would also alter the control screen and lights.
- **Foundation / slew-glass is mixed.** Cab panes share the bucket with a display,
  mirror faces and same-bucket lamp lenses. A slew/cab-looking name is insufficient.
- **SI is not cab glazing.** Its source explicitly has an open operator station;
  glass is lamp lenses and two gauges. `feed-lamp:glass` and `static:glass` stay
  unchanged.
- **Other unclassified glass stays unchanged.** A default glass-kind check, a
  static-node prefix, or merely checking a rig has a cab is not acceptable.

## Runtime and visual acceptance needed next

The implementation must select the positively reviewed rig/node/bucket only,
preserve non-glass bindings and cached shared material identity, and avoid new
per-node material partitions. Transmission remains zero. The original glass
material must remain intact for lamps, screens, gauges, mirrors and unrelated
callers. Review material disposal and reuse as well as the first load. Snapshot
hashes, not dirty git status against an older parent, define the delta.

Actual site GLBs have no glass, but procedural site vehicles, windows, screens
and lamps use cloned glass materials. Full-scene captures must include those
unchanged controls. Do not repeat the earlier steel harness's assumption that
asset userData is retained by terrain clones.

Require actual targeted pane coverage, fixed scene/camera/lens/lighting/loadout,
settled maps, source hashes, an A/B/A/B repeat and unchanged negative controls.
Inspect full native frames and local cab/lamp/screen/terrain regions. Show loss
of contrast or detail, not only average brightness. A narrower or darkened pane
is not evidence of a newly visible interior: for example, the oil source has a
solid cabin shell behind its added window geometry.

Measure rig dispatch/draw scope explicitly; a stable material count is not a
measured ≤70 rig-draw certificate. No browser, Blender or GPU process was started
by this critic. The earlier accepted steel correction remains untouched, with
three exact repeat cases and the recorded supplemental Nordic-orbit limit.

Reproduce the independent read-only inventory:

```text
node tools/auditglassbindings-adversarial.mjs
```

The report's current source hashes identify this initial scope audit. Re-run
into a separately named report after implementation rather than overwriting
these baseline observations.

## CPU implementation review

**CPU approved; visual acceptance is still pending.** The implementation adds
one cached `assets.cabGlass()` and a rig/node/parent/geometry-count selector in
`gltfRig.js`. It leaves the original glass material and all other material kinds
intact. Only the two authorized production files differ from the frozen snapshot.

Reviewed byte hashes:

- `src/core/assets.js`:
  `154d5eac58bdeac6aaa0b559d2f13c43700d3aede18eb46816a738551533c605`.
- `src/core/gltfRig.js`:
  `3d5f9f56986278a5a932ef8f644b420c141b4114396ba5a3d6e240eeebc3d818`.

`node tools/checkcabglass-adversarial.mjs` passes **10 independent groups**.
The source/function checks execute the real getter and material selector with
real Three materials. They verify original material preservation, shared texture
references, caching, clone-error restoration, factory disposal, legacy adapters
and transmission rejection/fallback. Twenty-one mutated selector inputs change
names, parents, counts, material names or material array shape and are rejected.
Fixtures derived from all 19 actual GLB JSON hierarchies select exactly the three
approved buckets. These topology fixtures do not claim GLTF decoder or GPU
acceptance; the author owns a separate actual-loader check.

Review found that the first getter called `base.clone()` while its userData
still contained the live assetSet. Three clones userData through serialization.
The revised code temporarily clears userData with try/finally, restores the base,
and shallow-copies the original references onto the cached clone. A hostile
assetSet serialization trap catches the former clone behavior and passes the
corrected getter. Injected clone failure also restores the original references
and leaves the cache empty. No measured allocation-time saving is claimed.

The treatment reuses the existing procedural values (opacity 0.60, linear colour
multiplier 0.30, FrontSide, depthWrite true, transmission zero) as a candidate.
Those values are not yet a rendered verdict for these imported panes. The cached
clone is registered in the assets material map and disposed once by the existing
factory lifecycle. The original mixed/lens/site glass stays unchanged.

The eventual visual harness must account for a difference from steel: switching
DoubleSide/FrontSide changes shader defines and transparent back-face dispatches.
It must mark materials for update and warm/settle both variants. Candidate draw
dispatches may decrease; no added rig draws or unexplained non-target dispatch
change is acceptable. Restored baseline values must come from the actual original
material. Require pane coverage and full-scene negative controls rather than
assuming a distant oil orbit actually shows its windows.
