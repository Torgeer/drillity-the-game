# Cab glass capture preflight: independent critic

Scope: offline review of `tools/validateglass.mjs` and the existing renderer focus API. This review starts no browser or GPU process. It authorizes evidence collection only; no image, phone, FPS, or normal gameplay camera acceptance follows from this document.

## Frozen production

The candidate files match `drillity-coordination/cab-glass-delta.json`:

| File | SHA-256 |
| --- | --- |
| `src/core/assets.js` | `154d5eac58bdeac6aaa0b559d2f13c43700d3aede18eb46816a738551533c605` |
| `src/core/gltfRig.js` | `3d5f9f56986278a5a932ef8f644b420c141b4114396ba5a3d6e240eeebc3d818` |

Earlier independent CPU approval remains in `GLASS_BINDING_CRITIC_2026-09-08.md`. There are exactly three proven cab-only selectors: oil-derrick `static:glass`, longhole-rig `front:glass`, and piling-leader `upper_glass`. CFA, DTH and SI mixed/lens materials remain unchanged. This is not an all-fleet glazing repair, nor proof of a modeled visible cab interior.

## Camera and comparison review

- Longhole uses the existing orbit view. Oil and piling retain an unpaired, candidate-only wide context PNG, explicitly excluded from A/B metrics, before entering a diagnostic detail view.
- The public `renderer.focusOn(object, { padding: 2.2, duration: 0 })` API computes a bounding-sphere view and holds it until release or camera mode change. The harness makes no mode change after focus. Its default direction follows the current camera-to-pane-center line; it does not promise the original orbit azimuth about the rig center.
- Eight seconds of settling precede the freeze. Camera world, inverse, projection, position, FOV and aspect are captured and compared across A/B/A/B and before/after each screenshot. The requested mode remains `orbit`, but that mode label alone does not establish a normal orbit view: `row.focus.scope` explicitly identifies the diagnostic framing.
- The full actual scene remains present during the detail quartet. Projection bounds use the rendered surface band in CSS pixels, then the browser device scale for native screenshot coordinates. Those bounds only locate geometry; they do not establish visible, unobscured pixels.
- A restores the actual imported default-glass color, opacity and side on the one selected cab material. B restores the candidate treatment. Both shader-side variants are warmed before the quartet, and changing `side` marks the material for update. This is a single candidate boot with a narrow response intervention, not two independent source builds.
- Graph identities, geometry UUIDs, transforms, material identities/maps/properties, environment, fog, state, simulations, site identity and site material provenance remain controls. The selected material's three response fields are the only intended differences. Source manifests include the actual public assets and are compared before/after the run; served source identity is separately checked at each case.
- DTH, CFA and SI each require zero selected cab buckets and get their own unchanged-control quartets. All scene materials, including procedural site derivatives, are inventoried and must retain zero transmission. The earlier fleet audit found no imported site glass in the ten current site GLBs; this does not eliminate the procedural site controls.

## Draw counts and cleanup

The wrapper records actual `renderBufferDirect` calls for a whole game render, partitions rig-owned and target objects, and compares every non-target object's dispatch count exactly. Candidate rig and total scene dispatches may not exceed baseline. These include applicable shadow/post passes and cannot be reported as the standalone rig's 70-call budget or an FPS result.

Per-case restoration and context closure, followed by browser and Vite closure, are in `finally` paths. The server uses only strict port 5231 and requires the named GPU lease; a capture cannot overwrite an existing report. Focus has no separate release call because its entire private browser context is closed. No user-owned browser or service is targeted.

## Corrected preflight checks and recommendation

First inspected harness SHA-256: `9c695982002b7b7ca3470109ca872408f260aef13f1303d626411ec4654e95ce`.

Two narrow evidence-gate requests were sent to the author:

1. Assert that each labeled capture's selected color/opacity/side equals its expected baseline or candidate response, rather than only deleting these values before comparing the remaining identity. Require a positive target to appear in the recorded dispatches. Native imagery must still establish visibility.
2. Invalidate the report when restoration, browser closure or server closure fails. The inspected version records these failures but can retain `valid: true`.

Both requests are resolved in the final reviewed harness, SHA-256 **`a47f530ff58c4a4f032aa3a3b8eb3f4996535ffebb2979cdda64459480c07a23`**. Each before/after snapshot verifies the exact labeled response, expected selected-material count, target-object dispatch and selected cab-material dispatch. Metadata is saved before assertions, retaining rejected evidence. Restoration attempts both graphics and simulation functions; restoration, context, browser and server cleanup errors invalidate the run.

Recommendation: **approve this exact harness for the root-coordinated serial capture only**. No remaining offline capture blocker was found. `node --check tools/validateglass.mjs` and the early-exit `--preflight` passed for this final hash. Preflight confirms source inventory and exits before acquiring a GPU lease or starting Vite/browser; it is not a rendered test. Production source remains at the two frozen hashes above.

## Required image review after capture

Inspect all actual native PNGs, not just averages or projected rectangles. Verify A/A and B/B repetition and unchanged-control A/B pixels, retaining any drift rather than silently relaxing a gate. Confirm that the selected panes are visible and readable, and that reducing the pale/glare response does not merely replace it with black, opaque-looking patches. Examine nearby frames, steel, paint, terrain and site glass, including localized dark-pixel changes.

The unpaired wide context images can explain placement and scale but cannot establish a wide-view before/after improvement. Focused oil/piling results may support only those disclosed diagnostic views. Console warnings remain recorded; unpaid QA contracts or existing VFX defects are outside visual material acceptance. Prior accepted steel-02 limitations, including its Nordic orbit baseline repeat drift, remain unchanged.
