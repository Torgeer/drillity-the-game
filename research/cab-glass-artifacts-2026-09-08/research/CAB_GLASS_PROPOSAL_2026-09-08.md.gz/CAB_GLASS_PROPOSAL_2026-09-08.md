# Cab-only imported glazing candidate — 8 September 2026

CPU-reviewed candidate; **the first capture run is INVALID and there is no
overall visual approval**. Four quartets were recorded before the CFA control
returned a QA stub and stopped the run; SI was not attempted. Oil's panes are
occluded in the chosen detail view. Completed cases require their separate
visibility and repeat-noise review. Browser/server cleanup succeeded, port 5231
was verified closed, and the GPU lease was released. No repeat is authorized
this cycle. Raw evidence is preserved under `evidence/graphics/glass-01`.

The following proposal and CPU evidence preceded that capture. The frozen source baseline is
`drillity-coordination/resume-70-baseline-2026-09-08`, with its complete manifest
copied to `glass-baseline-manifest-2026-09-08.json`. The historical directory
name is unchanged by the owner's later usage cutoff extension.

## Demonstrated mismatch and narrow change

The imported loader previously mapped every `glass` primitive to the pale,
fully opaque, double-sided default material. The existing procedural
`rigFactory.cabGlass` instead uses opacity 0.60, a linear colour multiplier of
0.30, FrontSide and depthWrite true, with transmission zero. This candidate
uses those existing authored finish values for three independently verified
cab-only imported buckets. They are presentation values, not new measured
physical properties. No historical procedural-glass visual experiment was
repeated or adopted as acceptance evidence for this change.

| Imported rig / restored node | Direct runtime parent | Positions / indices |
| --- | --- | ---: |
| oil-derrick / static:glass | rig:oil-derrick | 48 / 72 |
| longhole-rig / front:glass | pivot:articulation | 96 / 144 |
| piling-leader / upper_glass | pivot:slew | 120 / 180 |

The selection also requires one imported glass material. Source reading and
the actual binary inventory establish the pane semantics; names and counts
only guard that already-reviewed scope. Authoring changes require a new audit.
No model bytes, dimensions, geometry, mesh partitions or material groups change.

`assets.cabGlass()` caches one finish, shares all original glass textures and
the live assetSet reference, and uses the assets system's disposal lifecycle.
Cloning temporarily clears userData and restores it with try/finally to avoid
serializing live canvas textures. The shared default material remains intact.
`gltfRig` chooses that finish only for the proven buckets. Older material
adapters without the optional cabGlass getter retain their existing fallback.

## Deliberately excluded surfaces

Only three of the nineteen fleet rigs change. Fifteen rigs contain some glass;
twelve of those remain unchanged. CFA's static bucket includes five cab panes
and four lamp lenses. DTH includes cab panes, gauges, a screen and lamp lenses;
foundation includes cab panes, a display, mirrors and lenses. SI has no cab:
its glass belongs to lenses and gauges. Other unclassified buckets are excluded.
Their cab appearance needs authoring separation and a further source-backed
review, not a global tint. No shipped site GLB has glass; procedural site
glass derivatives also retain their existing materials and overrides.

The independent source/binary reasoning and every glass callsite are recorded
in `GLASS_BINDING_CRITIC_2026-09-08.md` and its JSON. In particular, the oil rig
has a solid cabin shell behind its windows; blending does not establish a
newly visible modeled interior.

## CPU evidence and remaining acceptance

```text
node tools/auditglassbindings-adversarial.mjs
node tools/checkcabglass-adversarial.mjs
node tools/checkcabglass.mjs
node tools/validateglass.mjs --preflight
```

Independent review passes ten groups, including 21 hostile selector variants,
clone serialization/failure controls, cache/disposal and actual-fleet topology
fixtures. The author check then loads all nineteen real GLBs through the actual
GLTFLoader and verifies exactly three selections, unchanged geometry values
and primitive counts, shared material identity across instances, a settled
real glass bake, 100 cached requests and one disposal of the new material.
The initial author check wrongly expected geometry identity across instances;
its failure is retained separately. Production intentionally clones geometry
for independent disposal, so the corrected check compares values and verifies
distinct geometry objects. No production fix was made to satisfy that test.

The capture harness is prepared for longhole, oil and piling plus unchanged
DTH, CFA and SI controls. It creates actual generated QA-preview contracts with
supported default loadouts, uses the frozen source root, fixes cameras and
dt=0 after settling, and records A/B/A/B. Oil and piling first retain an unpaired
wide candidate context PNG, then use the existing public `renderer.focusOn`
API on the proven pane bucket (padding 2.2, held focus) for the detail quartet.
Those detail views are diagnostic framing, not a normal-gameplay camera claim.
Longhole retains orbit framing. Baseline restores actual default-glass
colour/opacity/side on the selected material only. Both side variants compile
before the quartet. Source, full material/texture/geometry identities, simulation,
site, camera, fog and exposure are guarded. It records projected pane extents
for native-image inspection, all object dispatches, and rejects increased
rig/scene dispatches or changes to non-target dispatches. Projected extents do
not prove visibility through occluders; actual panes must be checked in images.

The executed command was `node tools/validateglass.mjs --out evidence/graphics/glass-01`,
following the root's explicit `glass-visual-acceptance` grant on port 5231. The script
owns/cleans that server and browser, and preserves failures. Review actual pane,
paint, lamp/display and site ROIs with A/A and B/B repeat noise. No capture,
appearance improvement, rig draw budget, FPS or phone acceptance is claimed
by the CPU results, and the invalid first capture does not establish overall approval.
