"""Package this candidate as evidence only, preserving originals and PNG bytes.

Run once after the independent visual review is complete. No git operations.
Text is deterministic lossless gzip; the manifest records raw and stored hashes.
"""
from pathlib import Path
import gzip
import hashlib
import json
import shutil

root = Path(__file__).resolve().parent.parent
main = root.parent / 'drillity-fps-investigation'
dest = main / 'research' / 'cab-glass-artifacts-2026-09-08'
assert dest.resolve().parent == (main / 'research').resolve()
assert not dest.exists(), 'Refusing to overwrite an evidence package'
assert (root / 'research/GLASS_VISUAL_CRITIC_2026-09-08.md').exists(), 'Independent visual review required'
report = json.loads((root / 'evidence/graphics/glass-01/report.json').read_text())
assert report['valid'] is False and report['sourceUnchanged'] is True
assert report['cleanup']['browserClosed'] and report['cleanup']['serverClosed']
assert (root.parent / 'drillity-coordination/gpu-owner.txt').read_text(encoding='utf-8-sig').strip() != 'glass-visual-acceptance'

sources = []
for folder in ['research', 'tools']:
    for path in sorted((root / folder).iterdir()):
        if path.is_file() and 'glass' in path.name.lower():
            sources.append((path, f'{folder}/{path.name}'))
for path in sorted((root / 'evidence/graphics/glass-01').iterdir()):
    if path.is_file():
        sources.append((path, 'capture/' + path.name))
for rel in ['src/core/assets.js', 'src/core/gltfRig.js']:
    sources.append((root / rel, 'candidate-source/' + rel))
    sources.append((root.parent / 'drillity-coordination/resume-70-baseline-2026-09-08' / rel, 'baseline-source/' + rel))
for name in ['cab-glass-delta.patch', 'cab-glass-delta.json']:
    sources.append((root.parent / 'drillity-coordination' / name, name))

digest = lambda b: hashlib.sha256(b).hexdigest()
dest.mkdir()
rows = []
for path, relative in sources:
    raw = path.read_bytes()
    png = path.suffix.lower() == '.png'
    stored = raw if png else gzip.compress(raw, compresslevel=9, mtime=0)
    target = dest / (relative if png else relative + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(stored)
    recovered = target.read_bytes() if png else gzip.decompress(target.read_bytes())
    assert recovered == raw, relative
    rows.append({'path': target.relative_to(dest).as_posix(), 'encoding': 'unchanged PNG' if png else 'gzip',
                 'originalPath': str(path), 'originalBytes': len(raw), 'originalSha256': digest(raw),
                 'storedBytes': len(stored), 'storedSha256': digest(stored)})

manifest = {'status': 'INVALID capture; CPU candidate only; no overall approval or production integration',
            'originalsPreserved': True, 'files': rows,
            'pngCount': sum(r['encoding'] == 'unchanged PNG' for r in rows),
            'storedBytes': sum(r['storedBytes'] for r in rows)}
(dest / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
shutil.copyfile(root / 'research/CAB_GLASS_PACKAGE_README_2026-09-08.md', dest / 'README.md')
print(json.dumps({'package': str(dest), 'files': len(rows), 'pngCount': manifest['pngCount'],
                  'storedBytes': manifest['storedBytes'], 'manifestSha256': digest((dest / 'manifest.json').read_bytes())}))
