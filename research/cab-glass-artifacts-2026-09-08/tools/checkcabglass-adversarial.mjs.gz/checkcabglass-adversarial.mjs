/** Independent CPU critique: actual getter/selector functions, real Three
 * material cloning, hostile aliases and actual shipped GLB topology/counts.
 * No browser, canvas generation, GLTF decoding or GPU. Topology fixtures read
 * real GLB JSON; they do not stand in for rendered or loader acceptance.
 * node tools/checkcabglass-adversarial.mjs [--report path]
 */
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import * as THREE from 'three';
import { createAssets } from '../src/core/assets.js';
import { RIGS } from '../src/game/data.js';
const root = fileURLToPath(new URL('../', import.meta.url));
const baselineDir = resolve(root, '../drillity-coordination/resume-70-baseline-2026-09-08');
const aText = readFileSync(join(root, 'src/core/assets.js'), 'utf8').replace(/\r\n/g, '\n');
const gText = readFileSync(join(root, 'src/core/gltfRig.js'), 'utf8').replace(/\r\n/g, '\n');
const digest = b => createHash('sha256').update(b).digest('hex');
const extract = (text, signature, indent) => {
  const start = text.indexOf(signature), end = text.indexOf('\n' + ' '.repeat(indent) + '}', start) + indent + 2;
  assert(start >= 0 && end > start); return text.slice(start, end);
};
const getterText = extract(aText, 'function cabGlass() {', 4);
const swapText = extract(gText, 'function swapMaterials(root, id) {', 2);
const liveText = extract(gText, 'function liveMaterial(kind, id, cabOnly = false) {', 2);
const bucketText = gText.match(/const CAB_GLASS_BUCKETS = (\{[\s\S]*?\n\});/)[1];
const buckets = new Function(`return (${bucketText});`)();
const checks = [], failures = [], observations = {};
const test = (name, fn) => { try { fn(); checks.push(name); } catch (e) { failures.push({ name, error: e.stack }); } };
const owner = createAssets({ quality: { id: 'low' } });
const spec = owner._kinds.glass;
const baseMaterial = () => {
  const m = spec.base(spec.defaults({})); m.name = 'drillity:glass';
  m.map = new THREE.Texture(); m.normalMap = new THREE.Texture(); m.roughnessMap = new THREE.Texture();
  m.userData = { assetKind: 'glass', assetSet: { map: m.map, normal: m.normalMap, orm: m.roughnessMap,
    toJSON() { throw Error('live assetSet was serialized'); } } };
  return m;
};
const makeGetter = (base, map = new Map()) => ({ map, get: new Function('THREE', 'allMaterials', 'material', `return (${getterText});`)(THREE, map, kind => { assert.equal(kind, 'glass'); return base; }) });
const materialState = m => ({ roughness: m.roughness, metalness: m.metalness, opacity: m.opacity, transparent: m.transparent,
  color: m.color.toArray(), side: m.side, transmission: m.transmission, clearcoat: m.clearcoat,
  clearcoatRoughness: m.clearcoatRoughness, envMapIntensity: m.envMapIntensity, depthWrite: m.depthWrite });

test('delta changes only the two authorized production files against the frozen snapshot', () => {
  const manifest = JSON.parse(readFileSync(join(baselineDir, 'manifest.json'), 'utf8'));
  const changed = manifest.files.filter(f => f.path.startsWith('src/') && digest(readFileSync(join(root, f.path))) !== f.sha256).map(f => f.path).sort();
  assert.deepEqual(changed, ['src/core/assets.js', 'src/core/gltfRig.js']);
  assert.equal(typeof owner.cabGlass, 'function', 'public getter not exposed'); observations.changedSources = changed;
});
test('cab getter avoids serialization, shares every texture and preserves the original glass', () => {
  const base = baseMaterial(), before = materialState(base), data = base.userData;
  const { get, map } = makeGetter(base), cab = get();
  assert.notEqual(cab, base); assert.notEqual(cab.userData, data); assert.equal(base.userData, data);
  assert.equal(cab.userData.assetSet, data.assetSet); assert.equal(cab.userData.assetKind, 'glass');
  for (const key of ['map', 'normalMap', 'roughnessMap', 'metalnessMap', 'aoMap']) assert.equal(cab[key], base[key]);
  assert.deepEqual(materialState(base), before); assert.equal(cab.transmission, 0);
  assert.equal(cab.opacity, .60); assert.equal(cab.side, THREE.FrontSide); assert.equal(cab.depthWrite, true);
  assert.deepEqual(cab.color.toArray(), before.color.map(v => v * .30));
  for (let i = 0; i < 20; i++) assert.equal(get(), cab);
  assert.equal(map.size, 1); observations.cabMaterial = materialState(cab);
  cab.dispose(); base.dispose();
});
test('clone failure restores the original base and does not cache a broken result', () => {
  const base = baseMaterial(), data = base.userData;
  base.clone = () => { assert.deepEqual(base.userData, {}); throw Error('injected clone failure'); };
  const { get, map } = makeGetter(base);
  assert.throws(get, /injected clone failure/); assert.equal(base.userData, data); assert.equal(map.size, 0); base.dispose();
});
test('legacy clone negative control is caught by the serialization trap', () => {
  const base = baseMaterial(); assert.throws(() => base.clone(), /live assetSet was serialized/); base.dispose();
});
test('factory ownership disposes the cached cab once, without disposing shared textures through the cab', () => {
  const base = baseMaterial(), materials = new Map([['base', base]]), { get } = makeGetter(base, materials), cab = get();
  let baseCount = 0, cabCount = 0, textureCount = 0;
  base.addEventListener('dispose', () => baseCount++); cab.addEventListener('dispose', () => cabCount++);
  base.map.addEventListener('dispose', () => textureCount++);
  const disposeText = extract(aText, 'function dispose() {', 4);
  const dispose = new Function('allMaterials', `let destroyed=false,running=0; const tasks=[],allTextures=new Set(),setCache=new Map(),familyIndex=new Map(),decalCache=new Map(),dataTexCache=new Map(),stratumCache=new Map(),animated=new Set(),wetGroup=new Set(),ledger={},pools={},scratch={}; return (${disposeText});`)(materials);
  dispose(); dispose(); assert.equal(baseCount, 1); assert.equal(cabCount, 1); assert.equal(textureCount, 0); assert.equal(materials.size, 0);
});
function makeSwap({ legacy = false, brokenCab = false } = {}) {
  const normal = new THREE.MeshPhysicalMaterial(), cab = new THREE.MeshPhysicalMaterial();
  normal.name = 'control-glass'; cab.name = 'cab-glass'; if (brokenCab) cab.transmission = .5;
  const calls = [], assets = { _kinds: { glass: {}, paintedSteel: {} }, material(kind, params) { calls.push({ kind, params }); return normal; } };
  if (!legacy) assets.cabGlass = () => cab;
  const live = new Function('ctx', 'say', `return (${liveText});`)({ assets }, () => {});
  const swap = new Function('CAB_GLASS_BUCKETS', 'liveMaterial', 'say', `return (${swapText});`)(buckets, live, () => {});
  return { swap, normal, cab, calls };
}
function fixture(id, change = () => {}) {
  const b = buckets[id], parent = new THREE.Group(), scene = new THREE.Group(); parent.name = b.parent; scene.add(parent);
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(b.positions * 3), 3));
  g.setIndex(new THREE.BufferAttribute(new Uint16Array(b.indices), 1));
  const m = new THREE.MeshBasicMaterial(); m.name = 'glass';
  const mesh = new THREE.Mesh(g, m); mesh.name = b.name; parent.add(mesh); change({ scene, parent, mesh, g, m });
  return { scene, parent, mesh, g, m };
}
test('selector accepts exactly the three reviewed buckets and keeps ambiguous aliases out', () => {
  assert.deepEqual(Object.keys(buckets).sort(), ['longhole-rig', 'oil-derrick', 'piling-leader']);
  for (const id of Object.keys(buckets)) {
    const { scene, mesh } = fixture(id), { swap, cab } = makeSwap(); const kinds = swap(scene, id);
    assert.equal(mesh.material, cab); assert.deepEqual(kinds, ['glass']);
  }
  for (const wrongId of ['cfa-rig', 'dth-crawler', 'foundation-bg', 'si-rig', 'unknown']) {
    const { scene, mesh } = fixture('oil-derrick'), { swap, normal } = makeSwap(); swap(scene, wrongId); assert.equal(mesh.material, normal);
  }
});
test('name, parent, position/index counts and single-material guards reject changed buckets', () => {
  const changes = [({ mesh }) => mesh.name += '-other', ({ parent }) => parent.name = 'other-parent',
    ({ g }) => g.attributes.position.count++, ({ g }) => g.index.count++,
    ({ g }) => g.setIndex(null), ({ mesh, m }) => mesh.material = [m, m],
    ({ m }) => m.name = 'paintedSteel'];
  for (const id of Object.keys(buckets)) for (const change of changes) {
    const { scene, mesh } = fixture(id, change), { swap, normal } = makeSwap(); swap(scene, id);
    for (const m of Array.isArray(mesh.material) ? mesh.material : [mesh.material]) assert.equal(m, normal);
  }
  observations.hostileSelectorVariants = changes.length * Object.keys(buckets).length;
});
test('cab and mixed glass remain separate if a known rig acquires another glass bucket', () => {
  const { scene, parent, mesh, m } = fixture('oil-derrick');
  const lamp = new THREE.Mesh(mesh.geometry, m); lamp.name = 'lamp'; parent.add(lamp);
  const { swap, cab, normal } = makeSwap(); assert.deepEqual(swap(scene, 'oil-derrick'), ['glass']);
  assert.equal(mesh.material, cab); assert.equal(lamp.material, normal);
});
test('legacy adapters remain compatible and transmissive cab adapters cannot bypass the existing ceiling', () => {
  for (const options of [{ legacy: true }, { brokenCab: true }]) {
    const { scene, mesh } = fixture('oil-derrick'), { swap, normal, calls } = makeSwap(options); swap(scene, 'oil-derrick');
    assert.equal(mesh.material, normal); assert.equal(mesh.material.transmission, 0);
    if (options.brokenCab) assert(calls.some(c => c.params?.transmission === 0));
  }
});
test('actual 19-GLB topology/count fixtures select only the three approved primitive buckets', () => {
  const selected = [], allHashes = {};
  for (const { id } of RIGS) {
    const path = resolve(root, '../drillity-fps-investigation/public/models', id + '.glb'), bytes = readFileSync(path);
    allHashes[id] = digest(bytes); const doc = JSON.parse(bytes.subarray(20, 20 + bytes.readUInt32LE(12)).toString('utf8'));
    const top = new THREE.Group(); top.name = 'rig:' + id;
    const nodes = doc.nodes.map(n => { const o = new THREE.Group(); o.name = n.name || ''; return o; });
    const targets = [];
    doc.nodes.forEach((n, i) => {
      for (const child of n.children || []) nodes[i].add(nodes[child]);
      if (n.mesh === undefined) return;
      const primitives = doc.meshes[n.mesh].primitives;
      if (primitives.length !== 1) { assert(primitives.every(p => doc.materials[p.material]?.name !== 'glass'), 'multi-primitive glass needs loader-specific fixture'); return; }
      const p = primitives[0]; if (doc.materials[p.material]?.name !== 'glass') return;
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(doc.accessors[p.attributes.POSITION].count * 3), 3));
      g.setIndex(new THREE.BufferAttribute(new Uint32Array(doc.accessors[p.indices].count), 1));
      nodes[i].isMesh = true; nodes[i].geometry = g; nodes[i].material = new THREE.MeshBasicMaterial(); nodes[i].material.name = 'glass'; targets.push(nodes[i]);
    });
    for (const i of doc.scenes[doc.scene ?? 0].nodes) top.add(nodes[i]);
    const { swap, cab, normal } = makeSwap(); swap(top, id);
    for (const node of targets) { if (node.material === cab) selected.push([id, node.name]); else assert.equal(node.material, normal); }
  }
  assert.deepEqual(selected, [['oil-derrick', 'static:glass'], ['longhole-rig', 'front:glass'], ['piling-leader', 'upper_glass']]);
  observations.selectedShippedBuckets = selected; observations.glbHashes = allHashes;
});
owner.dispose();
const report = { assetsSha256: digest(readFileSync(join(root, 'src/core/assets.js'))), gltfRigSha256: digest(readFileSync(join(root, 'src/core/gltfRig.js'))),
  checks, failures, observations, limits: 'CPU source/function/material/topology evidence only. Actual loader, full-scene appearance, repeat controls and draw submissions still require serialized acceptance.' };
const at = process.argv.indexOf('--report'); writeFileSync(resolve(root, at < 0 ? 'research/cab-glass-independent-2026-09-08.json' : process.argv[at + 1]), JSON.stringify(report, null, 2) + '\n');
console.log(`cab glass independent: ${checks.length} passed, ${failures.length} failed`);
for (const f of failures) console.error(f.name + ': ' + f.error);
if (failures.length) process.exitCode = 1;
