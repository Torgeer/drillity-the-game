/** Independent read-only inventory of real fleet/site glass bindings.
 * node tools/auditglassbindings-adversarial.mjs [--models path] [--report path]
 * No Blender, canvas, browser or GPU. Does not infer pane semantics from names.
 */
import assert from 'node:assert/strict';
import { readFileSync, readdirSync, writeFileSync, existsSync } from 'node:fs';
import { resolve, relative, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { RIGS } from '../src/game/data.js';
const root = fileURLToPath(new URL('../', import.meta.url));
const args = process.argv.slice(2), opt = (name, fallback) => args.includes(name) ? args[args.indexOf(name) + 1] : fallback;
const models = resolve(root, opt('--models', '../drillity-fps-investigation/public/models'));
const digest = bytes => createHash('sha256').update(bytes).digest('hex');
const expected = new Set(RIGS.map(r => r.id));
const paths = [];
function walk(dir) { for (const entry of readdirSync(dir, { withFileTypes: true })) { const p = join(dir, entry.name); if (entry.isDirectory()) walk(p); else if (p.endsWith('.glb')) paths.push(p); } }
walk(models);
const rows = [];
for (const path of paths.sort()) {
  const bytes = readFileSync(path);
  assert.equal(bytes.readUInt32LE(0), 0x46546c67); assert.equal(bytes.readUInt32LE(4), 2);
  assert.equal(bytes.readUInt32LE(8), bytes.length); assert.equal(bytes.readUInt32LE(16), 0x4e4f534a);
  const doc = JSON.parse(bytes.subarray(20, 20 + bytes.readUInt32LE(12)).toString('utf8'));
  const file = relative(models, path).replaceAll('\\', '/');
  const id = file.slice(0, -4), category = expected.has(id) ? 'fleet' : file.startsWith('sites/') ? 'site' : 'fixture';
  const parents = new Map();
  for (let i = 0; i < (doc.nodes || []).length; i++) for (const child of doc.nodes[i].children || []) { assert(!parents.has(child)); parents.set(child, i); }
  const ancestry = i => { const names = [], seen = new Set(); while (i !== undefined) { assert(!seen.has(i)); seen.add(i); names.unshift(doc.nodes[i].name || `node-${i}`); i = parents.get(i); } return names; };
  const bindings = [];
  for (let ni = 0; ni < (doc.nodes || []).length; ni++) {
    const node = doc.nodes[ni]; if (node.mesh === undefined) continue;
    const mesh = doc.meshes[node.mesh];
    for (let pi = 0; pi < mesh.primitives.length; pi++) {
      const p = mesh.primitives[pi]; if (doc.materials?.[p.material]?.name !== 'glass') continue;
      assert.equal(p.mode ?? 4, 4, 'glass is not triangle geometry');
      const position = doc.accessors[p.attributes.POSITION];
      const indices = p.indices === undefined ? null : doc.accessors[p.indices];
      bindings.push({ nodeIndex: ni, node: node.name, ancestry: ancestry(ni), mesh: mesh.name, primitiveIndex: pi,
        positionCount: position.count, indexCount: indices?.count || null,
        triangles: (indices?.count || position.count) / 3,
        attributes: Object.keys(p.attributes).sort(), nodeExtras: node.extras || null,
        primitiveExtras: p.extras || null, materialExtras: doc.materials[p.material].extras || null });
    }
  }
  rows.push({ file, id, category, bytes: bytes.length, sha256: digest(bytes), materialNames: (doc.materials || []).map(m => m.name), bindings });
}
assert.equal(rows.filter(r => r.category === 'fleet').length, expected.size);
for (const id of expected) assert(rows.some(r => r.id === id && r.category === 'fleet'));
const row = id => rows.find(r => r.id === id);
const pureCabCandidates = [
  ['oil-derrick', 'static:glass', 48, 72, 'blender/oil_derrick.py', ['cabin-window', 'cabin-window-s']],
  ['longhole-rig', 'front:glass', 96, 144, 'blender/longhole_rig.py', ['cab-glass-front', 'cab-glass-rear', 'cab-glass-%s']],
  ['piling-leader', 'upper_glass', 120, 180, 'blender/piling_leader.py', ['cabfront', 'cabroof', 'cabsideU', 'cabdoor']],
];
const evidence = [];
for (const [id, name, count, indices, python, labels] of pureCabCandidates) {
  const record = row(id); assert.equal(record.bindings.length, 1, `${id} now has another glass bucket`);
  const b = record.bindings[0]; assert.equal(b.node, name); assert.equal(b.positionCount, count); assert.equal(b.indexCount, indices);
  const text = readFileSync(join(root, python), 'utf8');
  for (const label of labels) assert(text.includes(`'${label}'`), `${python}: source label missing`);
  evidence.push({ id, node: name, positionCount: count, indexCount: indices, python,
    pythonSha256: digest(readFileSync(join(root, python))), sourceLabels: labels,
    determination: 'Source-reviewed cab-only bucket; binary counts corroborate the authored boxes, but counts alone are not semantic proof.' });
}
// Explicit hostile controls: a matching static name does NOT imply cab-only.
assert.deepEqual(row('cfa-rig').bindings.map(b => [b.node, b.positionCount]), [['mast:glass', 48], ['static:glass', 216]]);
assert.equal(row('dth-crawler').bindings[0].positionCount, 2160);
assert.equal(row('foundation-bg').bindings[0].node, 'slew-glass');
assert(row('si-rig').bindings.some(b => b.node === 'feed-lamp:glass'));
const sourceAliases = [];
for (const r of rows.filter(r => r.category === 'fleet')) {
  const path = `blender/${r.id.replaceAll('-', '_')}.py`;
  if (!existsSync(join(root, path))) continue;
  const bytes = readFileSync(join(root, path)), lines = bytes.toString('utf8').split(/\r?\n/);
  sourceAliases.push({ rig: r.id, path, sha256: digest(bytes), mentions: lines.flatMap((text, i) => /MAT_GLASS/.test(text) ? [{ line: i + 1, text: text.trim() }] : []) });
}
const bindingSources = Object.fromEntries(['src/core/assets.js', 'src/core/gltfRig.js', 'src/rig/rigFactory.js', 'src/world/terrain.js'].map(p => [p, digest(readFileSync(join(root, p)))]));
const report = { models, counts: { fleet: expected.size, fleetWithGlass: rows.filter(r => r.category === 'fleet' && r.bindings.length).length,
  sites: rows.filter(r => r.category === 'site').length, sitesWithGlass: rows.filter(r => r.category === 'site' && r.bindings.length).length },
  bindingSources, pureCabCandidates: evidence, rejectedCandidate: { id: 'cfa-rig', node: 'static:glass', reason: 'Five cab panes plus four static lamp lenses. build_lights creates six glass lamps; two enter the mast and four remain static. 9 boxes corroborated by 216 positions.' },
  rows, sourceAliases, limits: ['No visual verdict, asset regeneration or draw-call measurement.', 'GLB primitive/node names and vertex counts do not recover pre-merge semantics.', 'Shipped site GLBs have no glass, but procedural site glass clones must remain negative controls.', 'Only the three positively reviewed buckets may receive a cab treatment; mixed and unclassified glass remains unchanged.'] };
writeFileSync(resolve(root, opt('--report', 'research/glass-bindings-independent-2026-09-08.json')), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ counts: report.counts, cabCandidates: evidence.map(r => r.id), rejected: report.rejectedCandidate.id, gpuUsed: false }));
