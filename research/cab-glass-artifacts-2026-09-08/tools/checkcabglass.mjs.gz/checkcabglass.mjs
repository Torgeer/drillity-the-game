/** Actual-fleet CPU selector/material check. No browser or GPU.
 * node tools/checkcabglass.mjs [--report research/cab-glass-cpu.json]
 */
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve } from 'node:path';
import * as THREE from 'three';
import { createAssets } from '../src/core/assets.js';
import { createGltfRigs } from '../src/core/gltfRig.js';
import { createBus } from '../src/core/contract.js';
import { RIGS } from '../src/game/data.js';
class MemoryCanvas {
  constructor(w, h) { this.width = w; this.height = h; this.data = new Uint8ClampedArray(w * h * 4); }
  getContext() {
    const cv = this;
    return {
      fillStyle: '#000000', imageSmoothingEnabled: true,
      createImageData: (w, h) => ({ width: w, height: h, data: new Uint8ClampedArray(w * h * 4) }),
      fillRect() {
        const rgb = this.fillStyle.match(/^#([0-9a-f]{6})$/i); assert(rgb, `unsupported test fill ${this.fillStyle}`);
        const hex = parseInt(rgb[1], 16), c = [(hex >>> 16) & 255, (hex >>> 8) & 255, hex & 255, 255];
        for (let i = 0; i < cv.data.length; i += 4) cv.data.set(c, i);
      },
      putImageData(img, x, y) {
        if (cv.failWrites) throw new Error('injected canvas write failure');
        assert.equal(x, 0); assert.equal(y, 0); assert.equal(img.data.length, cv.data.length);
        cv.data.set(img.data);
      },
      drawImage(other, x, y, w, h) {
        assert.equal(x, 0); assert.equal(y, 0); assert.equal(w, cv.width); assert.equal(h, cv.height);
        for (let yy = 0; yy < h; yy++) for (let xx = 0; xx < w; xx++) {
          const from = (Math.floor(yy * other.height / h) * other.width + Math.floor(xx * other.width / w)) * 4;
          cv.data.set(other.data.subarray(from, from + 4), (yy * w + xx) * 4);
        }
      },
    };
  }
}
globalThis.OffscreenCanvas = MemoryCanvas;
// Avoid keeping Node alive with production MessageChannel; production gate and
// asynchronous task queue are otherwise unmodified.
globalThis.scheduler = { yield: () => new Promise(r => setImmediate(r)) };

const args=process.argv.slice(2), at=args.indexOf('--report');
const path=at<0?'research/cab-glass-cpu-2026-09-08.json':args[at+1];
const sha=p=>createHash('sha256').update(readFileSync(p)).digest('hex');
const report={valid:false,source:{assets:sha('src/core/assets.js'),loader:sha('src/core/gltfRig.js'),tool:sha('tools/checkcabglass.mjs')}, rows:[], errors:[]};
const original={document:globalThis.document,fetch:globalThis.fetch,info:console.info};
const real=createAssets({quality:{id:'low'}}), mats=new Map();
let loader;
try{
 const glass=real.material('glass'), before=real.stats(), cab=real.cabGlass();
 const scalarFields=['roughness','metalness','transmission','clearcoat','clearcoatRoughness','envMapIntensity','depthWrite','transparent'];
 for(const k of scalarFields)assert.equal(cab[k],glass[k],k);
 assert.equal(cab.opacity,.60); assert.equal(cab.side,THREE.FrontSide);
 for(let i=0;i<3;i++)assert.equal(cab.color.toArray()[i],glass.color.toArray()[i]*.30);
 for(const k of ['map','normalMap','roughnessMap','metalnessMap','aoMap'])assert.equal(cab[k],glass[k],k);
 assert.equal(cab.userData.assetSet,glass.userData.assetSet);
 for(let i=0;i<100;i++)assert.equal(real.cabGlass(),cab);
 assert.equal(real.stats().materials,before.materials+1);assert.equal(real.stats().textures,before.textures);assert.equal(real.stats().sets,before.sets);
 const assets={cabGlass:()=>real.cabGlass(),material(kind){if(kind==='glass')return glass;if(!mats.has(kind)){const spec=real._kinds[kind];assert(spec,kind);const m=spec.base(spec.defaults({}));m.name='drillity:'+kind;m.userData.assetKind=kind;mats.set(kind,m);}return mats.get(kind);}};
 globalThis.document={baseURI:'https://cab-check.invalid/'};
 globalThis.fetch=async value=>{const u=new URL(value);assert.equal(u.origin,'https://cab-check.invalid');assert(/^\/models\/[^/]+\.glb$/.test(u.pathname));return new Response(readFileSync(resolve('public'+u.pathname)));};
 console.info=()=>{};
 loader=createGltfRigs({THREE,assets,data:{RIGS},bus:createBus(),qs:new URLSearchParams('glb=strict')});
 const positive={'oil-derrick':'static:glass','longhole-rig':'front:glass','piling-leader':'upper_glass'};
 for(const rig of RIGS){
  await loader.load(rig.id);const build=loader.builder(rig.id), instance=build(), second=build();
  const bindings=[], geom=[], materials=[];
  instance.root.traverse(o=>{if(!o.isMesh)return;geom.push(o.geometry);materials.push(o.material);const m=o.material;if(m===cab||m===glass)bindings.push({node:o.name,parent:o.parent?.name,cab:m===cab,positions:o.geometry.attributes.position.count,indices:o.geometry.index.count});});
  const nextGeom=[], nextMat=[];second.root.traverse(o=>{if(o.isMesh){nextGeom.push(o.geometry);nextMat.push(o.material);}});
  assert.equal(nextGeom.length,geom.length);geom.forEach((v,i)=>{ assert.notEqual(nextGeom[i],v); for(const k of Object.keys(v.attributes))assert.deepEqual(nextGeom[i].attributes[k].array,v.attributes[k].array); assert.deepEqual(nextGeom[i].index?.array,v.index?.array); });materials.forEach((v,i)=>assert.equal(nextMat[i],v));
  assert.deepEqual(bindings.filter(b=>b.cab).map(b=>b.node),positive[rig.id]?[positive[rig.id]]:[],rig.id);
  assert(!materials.some(m=>m.transmission>0));
  const bytes=readFileSync('public/models/'+rig.id+'.glb');const doc=JSON.parse(bytes.subarray(20,20+bytes.readUInt32LE(12)));
  const rawPrims=doc.nodes.filter(n=>n.mesh!==undefined).reduce((sum,n)=>sum+doc.meshes[n.mesh].primitives.length,0);
  assert.equal(loader.info(rig.id).prims,rawPrims,rig.id+' primitive count');
  report.rows.push({id:rig.id,glbSha256:sha('public/models/'+rig.id+'.glb'),primitives:rawPrims,bindings});
 }
 assert.equal(loader.problems().length,0);
 const deadline=Date.now()+30000;while(real.stats().pending){assert(Date.now()<deadline);await new Promise(r=>setTimeout(r,5));}
 assert.equal(real.stats().failed,0);assert.equal(real.stats().setsReady,real.stats().sets);
 assert.equal(cab.map,glass.map);assert.equal(cab.roughnessMap,glass.roughnessMap);
 let disposed=0;cab.addEventListener('dispose',()=>disposed++);real.dispose();assert.equal(disposed,1);
 report.stats={fleet:RIGS.length,cabBuckets:report.rows.flatMap(r=>r.bindings).filter(b=>b.cab).length,baseUnchanged:glass.opacity===1&&glass.side===THREE.DoubleSide,cachedRequests:100,settledGlassBake:true,disposedOnce:disposed===1};
 report.valid=true;
}catch(e){report.errors.push(String(e.stack||e));process.exitCode=1;}
finally{loader?.dispose();for(const m of mats.values())m.dispose();if(!report.valid)real.dispose();globalThis.document=original.document;globalThis.fetch=original.fetch;console.info=original.info;writeFileSync(path,JSON.stringify(report,null,2)+'\n');}
console.log(JSON.stringify({valid:report.valid,stats:report.stats,errors:report.errors}));

process.exit(process.exitCode || 0);
