"""Offline native-pixel/metadata audit. Does not start a browser or alter images."""
import copy
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / 'evidence/graphics/glass-01'
OUT = ROOT / 'research/glass-capture-independent-2026-09-08.json'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

raw = json.loads((EVIDENCE / 'report.json').read_text(encoding='utf-8'))
result = {
    'reportSha256': sha(EVIDENCE / 'report.json'),
    'harnessSha256': sha(EVIDENCE / 'validateglass-source.mjs'),
    'toolSha256': sha(Path(__file__)),
    'captureValid': raw['valid'],
    'sourceUnchanged': raw['sourceUnchanged'],
    'cleanup': raw['cleanup'],
    'cases': [], 'failures': [],
    'scope': 'Offline report consistency and native RGB pixel equality; no visibility, GPU, phone or FPS acceptance.'
}

def check(condition, label):
    if not condition:
        result['failures'].append(label)

def strip(identity):
    value = copy.deepcopy(identity)
    for material in value['materials']:
        if material['intervened']:
            for prop in ('color', 'opacity', 'side'):
                del material[prop]
    return value

def pixels(a, b, rect=None):
    if rect:
        x0, y0, x1, y1 = rect
        a, b = a[y0:y1, x0:x1], b[y0:y1, x0:x1]
    d = np.abs(a.astype(np.int16) - b.astype(np.int16))
    changed = np.any(d != 0, axis=2)
    yy, xx = np.nonzero(changed)
    return {
        'pixels': int(changed.size), 'changedPixels': int(changed.sum()),
        'exact': bool(not changed.any()), 'rgbMeanAbsoluteDifference255': d.mean(axis=(0, 1)).tolist(),
        'maxChannelDifference255': int(d.max()),
        'changedBounds': [int(xx.min()), int(yy.min()), int(xx.max()) + 1, int(yy.max()) + 1] if len(xx) else None,
        'rect': rect,
    }

for case in raw['cases']:
    cid = case['config']['id']
    row = {'id': cid, 'reportedValid': case.get('valid'), 'captures': len(case['captures']),
           'failure': case.get('failure'), 'cleanup': case.get('cleanup'), 'contextClosed': case.get('contextClosed')}
    result['cases'].append(row)
    check(case.get('cleanup', {}).get('restored') is True and case.get('contextClosed') is True, cid + ': cleanup')
    if not case['captures']:
        continue
    ref = case['captures'][0]['before']
    images = {}
    row['site'] = ref['identity']['site']
    row['siteProvenanceRows'] = sum(bool(x[-1]) for x in ref['identity']['graph'])
    row['draws'] = []
    bounds = case['freeze']['cabNodes']
    rect = None
    if bounds:
        x0, y0, x1, y1 = bounds[0]['projectedVertexBoundsScreenshot']
        rect = [int(np.floor(x0)), int(np.floor(y0)), int(np.ceil(x1)), int(np.ceil(y1))]
        row['projectedBoundsOnly'] = rect
    for cap in case['captures']:
        label = cap['label']
        path = EVIDENCE / cap['path']
        check(sha(path) == cap['sha256'], cid + '/' + label + ': PNG hash')
        images[label] = np.array(Image.open(path).convert('RGB'))
        check(cap['before']['identity'] == cap['after']['identity'], cid + '/' + label + ': within-capture identity')
        for when in ('before', 'after'):
            s = cap[when]
            check(strip(s['identity']) == strip(ref['identity']), cid + '/' + label + '/' + when + ': control identity')
            check(s['dispatches']['nonTargetObjects'] == ref['dispatches']['nonTargetObjects'], cid + '/' + label + '/' + when + ': non-target dispatches')
            check(s['dispatches']['all'] <= ref['dispatches']['all'] and s['dispatches']['rig'] <= ref['dispatches']['rig'], cid + '/' + label + '/' + when + ': added dispatches')
            selected = [m for m in s['identity']['materials'] if m['intervened']]
            check(len(selected) == int(case['config']['expectedCab'] > 0), cid + '/' + label + ': selected count')
            expected = case['freeze']['baseline' if cap['overrides'].get('glass') == 'baseline' else 'candidate']
            for mat in selected:
                check({p: mat[p] for p in ('color', 'opacity', 'side')} == expected, cid + '/' + label + ': response')
            check(all((m.get('transmission') or 0) == 0 for m in s['identity']['materials']), cid + '/' + label + ': transmission')
        row['draws'].append({'label': label, 'all': cap['before']['dispatches']['all'], 'rig': cap['before']['dispatches']['rig'], 'target': cap['before']['dispatches']['targetObjects']})
    a, b, ar, br = [images[x] for x in ['baseline-response', 'candidate-source', 'baseline-repeat', 'candidate-repeat']]
    row['size'] = [int(a.shape[1]), int(a.shape[0])]
    row['pairs'] = {}
    for label, left, right in [('AA', a, ar), ('BB', b, br), ('AB', a, b), ('ArBr', ar, br)]:
        row['pairs'][label] = {'full': pixels(left, right), 'projectedGeometryRect': pixels(left, right, rect) if rect else None}
    if cid == 'longhole-cab':
        # Manually selected after native view; inside the visible pane, includes the line behind it.
        pane = [310, 380, 357, 475]
        row['visiblePaneRect'] = pane
        row['visiblePanePairs'] = {label: pixels(left, right, pane) for label, left, right in [('AA', a, ar), ('BB', b, br), ('AB', a, b)]}
    if case['config']['expectedCab'] == 0:
        check(all(row['pairs'][p]['full']['exact'] for p in row['pairs']), cid + ': unchanged pixels')

result['metadataChecksPassed'] = not result['failures']
result['completedCasesHaveExactRepeats'] = all(c['pairs']['AA']['full']['exact'] and c['pairs']['BB']['full']['exact'] for c in result['cases'] if c['captures'])
check(result['sourceUnchanged'] and raw['sourceBefore'] == raw['sourceAfter'], 'source manifest equality')
check(raw['cleanup'].get('browserClosed') is True and raw['cleanup'].get('serverClosed') is True, 'browser/server cleanup')
result['metadataChecksPassed'] = not result['failures']
OUT.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'out': str(OUT), 'sha256': sha(OUT), 'metadataChecksPassed': result['metadataChecksPassed'],
                  'exactRepeats': result['completedCasesHaveExactRepeats'], 'captureValid': result['captureValid'],
                  'cases': [{ 'id': c['id'], 'captures': c['captures'], 'pairs': c.get('pairs') } for c in result['cases']]}, indent=2))
sys.exit(0 if result['metadataChecksPassed'] and result['completedCasesHaveExactRepeats'] and raw['valid'] else 1)
