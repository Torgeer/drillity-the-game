/** Matched still-image diagnostics; never a phone/FPS acceptance result.
 * Run: node tools/validateglass.mjs --out evidence/graphics/glass-01
 * Requires glass-visual-acceptance GPU lease. Uses only its own Vite port 5231.
 */
import { chromium } from 'playwright';
import { createServer } from 'vite';
import { readFileSync, writeFileSync, mkdirSync, readdirSync, existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve, relative } from 'node:path';
import { fileURLToPath } from 'node:url';
import assert from 'node:assert/strict';
import { SOURCE_IDENTITY_PATH, sourceIdentity } from './servedSourceIdentity.mjs';

const root = fileURLToPath(new URL('../', import.meta.url));
const arg = process.argv.indexOf('--out');
const out = resolve(root, arg < 0 ? 'evidence/graphics/glass-01' : process.argv[arg + 1]);
if (process.argv.includes('--preflight')) { console.log(JSON.stringify({ root, source: sourceIdentity(root), cases: 'oil-derrick, longhole-rig, piling-leader; DTH/CFA/SI unchanged controls', intervention: 'existing procedural cab finish on three proven buckets only', gpuStarted: false }, null, 2)); process.exit(0); }
assert.equal(readFileSync(resolve(root, '../drillity-coordination/gpu-owner.txt'), 'utf8').trim(), 'glass-visual-acceptance');
assert(!existsSync(resolve(out, 'report.json')), 'Refusing to overwrite evidence');
mkdirSync(out, { recursive: true });
writeFileSync(resolve(out, 'validateglass-source.mjs'), readFileSync(fileURLToPath(import.meta.url)));
const sha = p => createHash('sha256').update(readFileSync(p)).digest('hex');
function manifest() {
  const files = [];
  const walk = p => { for (const e of readdirSync(p, { withFileTypes: true })) {
    const q = resolve(p, e.name); if (e.isDirectory() || e.isSymbolicLink()) walk(q); else if (e.isFile()) files.push(q);
  } };
  for (const p of ['src', 'public', 'node_modules/three/examples/jsm']) walk(resolve(root, p));
  for (const p of ['index.html', 'vite.config.js', 'package.json', 'package-lock.json', 'tools/validateglass.mjs', 'tools/servedSourceIdentity.mjs', 'node_modules/three/build/three.module.js']) files.push(resolve(root, p));
  return Object.fromEntries(files.sort().map(p => [relative(root, p).replaceAll('\\', '/'), sha(p)]));
}
const report = { started: new Date().toISOString(), semantics: {
  factors: 'Single candidate source boot; exact cab-only material response restored to default glass for A, authored procedural cab finish for B. Source, geometry, maps, paint, steel, exposure and all mixed/site glass remain unchanged. A/B/A/B. Not a separate baseline source boot.',
  draws: 'Counts renderBufferDirect dispatches during one whole game render, with rig-owned objects separated. Includes shadow/post passes where applicable; not a stand-alone unshadowed rig budget or FPS/phone acceptance.',
  freeze: 'All system updates and render use dt=0 after settling, clock t/tSec restored each frame. No sim.debug.state writes. QA bridge creates a real generated contract then public debug.setDepth establishes the review depth. Stills do not measure FPS or certify a phone.'
}, sourceBefore: manifest(), cases: [], errors: [], cleanup: {} };
const save = () => writeFileSync(resolve(out, 'report.json'), JSON.stringify(report, null, 2));
let server, browser;
try {
  server = await createServer({ root, server: { host: '127.0.0.1', port: 5231, strictPort: true, hmr: false } });
  await server.listen();
  browser = await chromium.launch({ channel: 'chrome', headless: false, args: ['--disable-background-timer-throttling', '--disable-renderer-backgrounding', '--disable-backgrounding-occluded-windows', '--window-size=600,1000'] });
  const cases = [
    { id: 'longhole-cab', rig: 'longhole-rig', method: 'longhole', region: 'andes', camera: 'orbit', expectedCab: 1 },
    { id: 'oil-cab-focus', rig: 'oil-derrick', method: 'oil-rotary', region: 'sahara', camera: 'orbit', expectedCab: 1, focusCab: true },
    { id: 'piling-cab-focus', rig: 'piling-leader', method: 'driven-pile', region: 'nordic', camera: 'orbit', expectedCab: 1, focusCab: true },
    { id: 'dth-mixed-control', rig: 'dth-crawler', method: 'dth', region: 'nordic', camera: 'hero', seed: 3, archetype: 'well-pad', expectedCab: 0 },
    { id: 'cfa-mixed-control', rig: 'cfa-rig', method: 'cfa', region: 'nordic', camera: 'orbit', expectedCab: 0 },
    { id: 'si-lens-control', rig: 'si-rig', method: 'site-investigation', region: 'nordic', camera: 'orbit', expectedCab: 0 },
  ];
  for (const config of cases) {
    console.log(`Capture ${config.id}`);
    const row = { config, errors: [], requestFailures: [], httpFailures: [], warnings: [], captures: [] };
    report.cases.push(row); save();
    const context = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
    let page;
    try {
      page = await context.newPage();
      page.on('pageerror', e => row.errors.push(String(e)));
      page.on('requestfailed', r => row.requestFailures.push({ url: r.url(), error: r.failure()?.errorText }));
      page.on('response', r => { if (r.status() >= 400) row.httpFailures.push({ url: r.url(), status: r.status() }); });
      page.on('console', m => { if (['error', 'warning'].includes(m.type())) row.warnings.push({ type: m.type(), text: m.text() }); });
      await page.goto('http://127.0.0.1:5231/?quality=high&glb=strict&shot&sound=0', { waitUntil: 'domcontentloaded' });
      row.servedSource = await page.evaluate(async path => {
        const r = await fetch(path, { cache: 'no-store' }); if (!r.ok) throw Error(`Source identity HTTP ${r.status}`); return r.json();
      }, SOURCE_IDENTITY_PATH);
      assert.deepEqual(row.servedSource, sourceIdentity(root), 'Wrong or changed served source');
      await page.bringToFront();
      await page.waitForFunction(() => window.__DRILLITY?.__qa?.startDemoContract, null, { timeout: 180000 });
      // releaseBoot schedules the menu after exposing QA. Wait for that actual
      // handoff before asking for SITE, otherwise it can overwrite our request.
      await page.waitForFunction(() => window.__DRILLITY.ui.currentScene === 'menu', null, { timeout: 180000 });
      await page.waitForTimeout(350);
      row.setup = await page.evaluate(async config => {
        const c = window.__DRILLITY;
        const { makeRandom } = await import('/src/core/contract.js');
        const { defaultLoadoutFor, getItem, getRig, getMethod, MAX_LEVEL } = await import('/src/game/data.js');
        const loadout = defaultLoadoutFor(config.method, MAX_LEVEL);
        const method = getMethod(config.method);
        if (!getRig(config.rig).methods.includes(config.method)) throw Error('Incompatible rig/method');
        for (const slot of method.toolSlots) {
          const item = getItem(loadout[slot]);
          if (!item || item.slot !== slot || item.methods.length && !item.methods.includes(config.method)) throw Error(`Invalid loadout ${slot}`);
        }
        c.state.player.level = MAX_LEVEL;
        c.state.garage.owned = [...new Set([...c.state.garage.owned, ...Object.values(loadout)])];
        c.state.garage.loadout = { ...loadout };
        for (const id of Object.values(loadout)) c.state.garage.condition[id] = 1;
        c.state.garage.rigId = config.rig;
        c.rand = makeRandom(config.seed ?? 20260908);
        await c.gltfRigs.load(config.rig);
        const contract = await c.__qa.startDemoContract({ method: config.method, region: config.region, depth: 6 });
        if (contract.__stub) throw Error('QA bridge used a stub');
        if (config.archetype && contract.archetype !== config.archetype) throw Error(`Expected ${config.archetype}, got ${contract.archetype}`);
        c.state.garage.rigId = config.rig;
        if (!c.rig.setRig(config.rig)) throw Error('Rig refused');
        c.rig.setMethod(config.method); c.ui.show('site'); c.renderer.setCameraMode(config.camera);
        c.env.setWeather('clear'); c.env.setTimeOfDay(.34);
        c.sim.debug.setDepth(6); c.geology.setDepth?.(6);
        if (loadout.bit && c.sim.debug.state.bit?.id !== loadout.bit) throw Error(`Sim did not consume fitted bit ${loadout.bit}`);
        const simUpdate = c.sim.update;
        c.sim.update = function (_dt, ...rest) { return simUpdate.call(this, 0, ...rest); };
        window.__restoreSim = () => { c.sim.update = simUpdate; };
        const gl = c.renderer.gl.getContext(), ext = gl.getExtension('WEBGL_debug_renderer_info');
        return { contract, loadout, actualBit: c.sim.debug.state.bit?.id || null, gpu: ext ? gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) : null, browser: navigator.userAgent };
      }, config);
      await page.waitForFunction(() => { const c = window.__DRILLITY, a = c.assets.stats(); if (a.failed) throw Error('Texture failure'); return a.sets > 0 && a.setsReady === a.sets && a.pending === 0 && (!c.terrain.siteModel.requested || c.terrain.siteModel.model); }, null, { timeout: 180000 });
      row.warm = await page.evaluate(() => window.__DRILLITY.renderer.warmShaders());
      assert.equal(row.warm.ready, true, 'Warm shaders not ready');
      await page.waitForTimeout(1500);
      await page.evaluate(mode => { const c = window.__DRILLITY; if (c.ui.currentScene !== 'site') throw Error('SITE handoff lost'); c.renderer.setCameraMode(mode); }, config.camera);
      await page.waitForTimeout(8000);
      if (config.focusCab) {
        const path = `${config.id}-wide-context.png`;
        await page.screenshot({ path: resolve(out, path) });
        row.wideContext = { path, sha256: sha(resolve(out, path)),
          scope: 'Unpaired candidate context before diagnostic cab focus; excluded from A/B metrics.' };
        row.focus = await page.evaluate(() => {
          const c = window.__DRILLITY, cab = c.assets.cabGlass(), matches = [];
          c.rig.group.traverse(o => { if (o.isMesh && o.material === cab) matches.push(o); });
          if (matches.length !== 1) throw Error('Cab focus requires exactly one proven bucket');
          const opts = { padding: 2.2, duration: 0 };
          c.renderer.focusOn(matches[0], opts);
          return { api: 'renderer.focusOn', node: matches[0].name, uuid: matches[0].uuid, opts,
            scope: 'Diagnostic detail view of existing geometry; not normal gameplay camera acceptance.' };
        });
        await page.waitForTimeout(8000);
      }
      row.freeze = await page.evaluate(installFrozen, config);
      await page.evaluate(() => window.__GRAPHICS.frames(24));
      // Compile and exercise both side variants before the evidence quartet.
      await page.evaluate(() => window.__GRAPHICS.set({ glass: 'baseline' }));
      await page.evaluate(() => window.__GRAPHICS.frames(24));
      await page.evaluate(() => window.__GRAPHICS.set({}));
      await page.evaluate(() => window.__GRAPHICS.frames(24));
      const capture = async (label, overrides = {}) => {
        await page.evaluate(overrides => window.__GRAPHICS.set(overrides), overrides);
        await page.evaluate(() => window.__GRAPHICS.frames(12));
        const before = await page.evaluate(() => window.__GRAPHICS.snapshot());
        const path = `${config.id}-${label}.png`;
        await page.screenshot({ path: resolve(out, path) });
        const after = await page.evaluate(() => window.__GRAPHICS.snapshot());
        row.captures.push({ label, path, sha256: sha(resolve(out, path)), overrides, before, after }); save();
        assert.deepEqual(after.identity, before.identity, `${config.id}/${label}: identity drift`);
        for (const s of [before, after]) {
          assert.equal(s.visible, 'visible'); assert.equal(s.focused, true); assert.equal(s.contextLost, false);
          assert(s.assets.sets > 0 && s.assets.setsReady === s.assets.sets && s.assets.pending === 0 && s.assets.failed === 0, 'Assets not ready');
          const changed = s.identity.materials.filter(m => m.intervened);
          assert.equal(changed.length, config.expectedCab ? 1 : 0, 'Unexpected intervened material count');
          const expected = overrides.glass === 'baseline' ? row.freeze.baseline : row.freeze.candidate;
          for (const m of changed) {
            assert.deepEqual({ color: m.color, opacity: m.opacity, side: m.side }, expected,
              `${config.id}/${label}: labeled glass response was not applied`);
            assert((s.dispatches.rigMaterialNames[m.name] || 0) > 0, 'Selected cab finish had no rig material dispatch');
          }
          for (const target of row.freeze.cabNodes) {
            assert((s.dispatches.targetObjects[`${target.uuid}/${target.name}`] || 0) > 0,
              `${config.id}/${label}: selected cab object had no dispatch`);
          }
        }
        assert.equal(before.identity.rig.id, config.rig); assert.equal(before.identity.rig.source, 'glb');
        assert.equal(before.identity.cameraMode, config.camera, 'Requested camera mode not active');
        assert.equal(before.identity.screen, 'site', 'Requested SITE screen not active');
      };
      await capture('baseline-response', { glass: 'baseline' });
      await capture('candidate-source', {});
      await capture('baseline-repeat', { glass: 'baseline' });
      await capture('candidate-repeat', {});
      const reference = row.captures[0].before.identity;
      for (const capture of row.captures) {
        const strip = x => { const v = structuredClone(x); for (const m of v.materials) { if (m.intervened) { delete m.color; delete m.opacity; delete m.side; } } return v; };
        assert.deepEqual(strip(capture.before.identity), strip(reference), 'Non-intervention identity changed between captures');
        assert(capture.before.dispatches.rig <= row.captures[0].before.dispatches.rig, 'Cab response increased rig dispatches');
        assert(capture.before.dispatches.all <= row.captures[0].before.dispatches.all, 'Cab response increased scene dispatches');
        assert.deepEqual(capture.before.dispatches.nonTargetObjects, row.captures[0].before.dispatches.nonTargetObjects, 'Non-cab object dispatches changed');
      }
      const servedAfter = await page.evaluate(async path => (await fetch(path, { cache: 'no-store' })).json(), SOURCE_IDENTITY_PATH);
      assert.deepEqual(servedAfter, row.servedSource, 'Served source changed during capture');
      assert.equal(row.errors.length, 0, 'Page errors');
      assert.equal(row.httpFailures.length, 0, 'HTTP failures');
      assert.equal(row.requestFailures.length, 0, 'Request failures');
      row.valid = true;
    } catch (error) {
      row.failure = String(error.stack || error); throw error;
    } finally {
      if (page) try {
        row.cleanup = await page.evaluate(required => {
          const errors = [];
          for (const [name, fn, needed] of [['graphics', window.__GRAPHICS?.cleanup, required.graphics], ['sim', window.__restoreSim, required.sim]]) {
            try { if (typeof fn === 'function') fn(); else if (needed) throw Error('restore function missing'); }
            catch (e) { errors.push(`${name}: ${String(e)}`); }
          }
          return { restored: errors.length === 0, errors };
        }, { graphics: !!row.freeze, sim: !!row.setup });
      } catch (e) { row.cleanup = { restored: false, errors: [String(e)] }; }
      try { await context.close(); row.contextClosed = true; }
      catch (e) { row.contextCloseError = String(e); }
      if (row.cleanup?.restored === false || row.contextCloseError) {
        row.valid = false; save();
        throw Error(`${config.id}: owned cleanup failed: ${JSON.stringify({ restore: row.cleanup, context: row.contextCloseError })}`);
      }
      save();
    }
  }
  report.valid = true;
} catch (e) { report.valid = false; report.errors.push(String(e.stack || e)); process.exitCode = 1; }
finally {
  if (browser) try { await browser.close(); report.cleanup.browserClosed = true; } catch (e) { report.cleanup.browserError = String(e); }
  if (server) try { await server.close(); report.cleanup.serverClosed = true; } catch (e) { report.cleanup.serverError = String(e); }
  if (report.cleanup.browserError || report.cleanup.serverError) {
    report.valid = false; process.exitCode = 1;
    report.errors.push(`Owned cleanup failed: ${JSON.stringify(report.cleanup)}`);
  }
  report.sourceAfter = manifest(); report.sourceUnchanged = JSON.stringify(report.sourceBefore) === JSON.stringify(report.sourceAfter);
  if (!report.sourceUnchanged) { report.valid = false; process.exitCode = 1; }
  report.finished = new Date().toISOString(); save();
  console.log(JSON.stringify({ valid: report.valid, cases: report.cases.map(r => ({ id: r.config.id, valid: r.valid, failure: r.failure })), cleanup: report.cleanup }));
}

function installFrozen(config) {
  const c = window.__DRILLITY, restores = [];
  const clock = { t: c.clock.t, fps: c.clock.fps, tSec: c.state.tSec };
  let first = true;
  for (const s of c.systems) {
    if (typeof s.update !== 'function') continue;
    const old = s.update, ownsClock = first; first = false;
    s.update = function (_dt, ...rest) {
      if (ownsClock) { c.clock.t = clock.t; c.clock.dt = 0; c.clock.fps = clock.fps; c.state.tSec = clock.tSec; }
      return old.call(this, 0, ...rest);
    };
    restores.push(() => { s.update = old; });
  }
  const base = c.assets.material('glass'), cab = c.assets.cabGlass();
  const response = m => ({ color: m.color.toArray(), opacity: m.opacity, side: m.side });
  const baseline = response(base), candidate = response(cab);
  const cabNodes = [], targets = new Set(), rigObjects = new Set(), allMaterials = [], seen = new Set();
  c.rig.group.traverse(o => {
    rigObjects.add(o);
    if (o.material === cab) {
      targets.add(o);
      const band = c.renderer.bands.surface, points = [], v = new c.THREE.Vector3();
      for (let i = 0; i < o.geometry.attributes.position.count; i++) {
        v.fromBufferAttribute(o.geometry.attributes.position, i).applyMatrix4(o.matrixWorld).project(c.camera);
        points.push([band.x + (v.x + 1) * band.w / 2, band.y + (1 - v.y) * band.h / 2, v.z]);
      }
      const cssBounds = [Math.min(...points.map(p => p[0])), Math.min(...points.map(p => p[1])),
        Math.max(...points.map(p => p[0])), Math.max(...points.map(p => p[1]))];
      cabNodes.push({ name: o.name, parent: o.parent?.name, uuid: o.uuid,
        positions: o.geometry.attributes.position.count, indices: o.geometry.index.count,
        matrix: o.matrixWorld.toArray(), projectedVertexBoundsCss: cssBounds,
        projectedVertexBoundsScreenshot: cssBounds.map(n => n * window.devicePixelRatio),
        projectedDepthRange: [Math.min(...points.map(p => p[2])), Math.max(...points.map(p => p[2]))],
        coverageLimit: 'Projected geometry extent; occlusion, alpha and pane readability require native-image inspection.' });
    }
  });
  if (cabNodes.length !== config.expectedCab) throw Error(`Expected ${config.expectedCab} proven cab buckets, got ${cabNodes.length}`);
  for (const scene of [c.scene, c.sectionScene]) scene.traverse(o => {
    for (const m of o.material ? (Array.isArray(o.material) ? o.material : [o.material]) : []) {
      if (seen.has(m)) continue; seen.add(m); allMaterials.push(m);
      if (m.transmission > 0) throw Error(`Transmissive scene material ${m.name}`);
    }
  });
  const emptyDispatches = () => ({ all: 0, rig: 0, rigMaterialNames: {}, nonTargetObjects: {}, targetObjects: {} });
  let current = {}, dispatches = emptyDispatches();
  const oldDirect = c.renderer.gl.renderBufferDirect;
  c.renderer.gl.renderBufferDirect = function (...args) {
    dispatches.all++;
    const object = args[4];
    const objectKey = `${object?.uuid || 'none'}/${object?.name || 'unnamed'}`;
    const counts = targets.has(object) ? dispatches.targetObjects : dispatches.nonTargetObjects;
    counts[objectKey] = (counts[objectKey] || 0) + 1;
    if (rigObjects.has(args[4])) {
      dispatches.rig++;
      const name = args[3]?.name || args[3]?.type || 'unknown';
      dispatches.rigMaterialNames[name] = (dispatches.rigMaterialNames[name] || 0) + 1;
    }
    return oldDirect.apply(this, args);
  };
  restores.push(() => { c.renderer.gl.renderBufferDirect = oldDirect; });
  const apply = values => {
    cab.color.fromArray(values.color); cab.opacity = values.opacity;
    if (cab.side !== values.side) { cab.side = values.side; cab.needsUpdate = true; }
  };
  const oldRender = c.renderer.render;
  c.renderer.render = function () {
    dispatches = emptyDispatches();
    apply(current.glass === 'baseline' ? baseline : candidate);
    return oldRender.call(this, 0);
  };
  restores.push(() => { c.renderer.render = oldRender; });
  const clone = v => v === undefined ? null : JSON.parse(JSON.stringify(v));
  const matrix = cam => ({ position: cam.position.toArray(), world: cam.matrixWorld.toArray(), inverse: cam.matrixWorldInverse.toArray(), projection: cam.projectionMatrix.toArray(), fov: cam.fov, aspect: cam.aspect });
  const graph = () => {
    const rows = [];
    for (const scene of [c.scene, c.sectionScene]) scene.traverse(o => rows.push([o.uuid, o.name, o.visible, o.position.toArray(), o.quaternion.toArray(), o.scale.toArray(), o.geometry?.uuid || null, o.userData?.siteKinds || null]));
    return rows;
  };
  window.__GRAPHICS = {
    set(overrides) { current = overrides; },
    frames(n) { return new Promise((done, reject) => {
      let left = n, handle;
      const timeout = setTimeout(() => { cancelAnimationFrame(handle); reject(Error('RAF timeout')); }, 30000);
      function tick() { if (--left === 0) { clearTimeout(timeout); done(); } else handle = requestAnimationFrame(tick); }
      handle = requestAnimationFrame(tick);
    }); },
    snapshot() {
      const gl = c.renderer.gl.getContext();
      return { identity: {
        simulation: clone(c.sim.debug.state), state: clone(c.state), rig: clone(c.rig.getSpec()),
        cameraMode: c.renderer.cameraMode, camera: matrix(c.camera), sectionCamera: matrix(c.sectionCamera),
        graph: graph(), clock, quality: clone(c.quality), viewport: clone(c.viewport),
        buffer: [gl.drawingBufferWidth, gl.drawingBufferHeight], dpr: c.renderer.gl.getPixelRatio(),
        screen: c.ui.currentScene, site: clone(c.terrain.siteModel), archetype: c.terrain.archetype,
        env: { region: c.env.regionId, weather: c.env.weather, timeOfDay: c.env.timeOfDay,
          underground: c.env.undergroundId, exposure: c.renderer.exposure, sun: c.env.sun.intensity, hemi: c.env.hemi.intensity },
        fog: c.scene.fog ? { density: c.scene.fog.density, color: c.scene.fog.color.toArray() } : null,
        materials: allMaterials.map(m => ({ name: m.name, uuid: m.uuid, assetKind: m.userData?.assetKind || null,
          intervened: m === cab, roughness: m.roughness, metalness: m.metalness, color: m.color?.toArray(),
          envMapIntensity: m.envMapIntensity, transparent: m.transparent, opacity: m.opacity, side: m.side,
          depthWrite: m.depthWrite, clearcoat: m.clearcoat, clearcoatRoughness: m.clearcoatRoughness,
          transmission: m.transmission, maps: ['map', 'normalMap', 'roughnessMap', 'metalnessMap', 'aoMap', 'alphaMap'].map(key => [key, m[key]?.uuid || null]) })),
      }, assets: clone(c.assets.stats()), draw: clone(c.renderer.gl.info.render), dispatches: clone(dispatches),
      programs: c.renderer.gl.info.programs.length, visible: document.visibilityState,
      focused: document.hasFocus(), contextLost: gl.isContextLost() };
    },
    cleanup() { current = {}; apply(candidate); for (const restore of restores.reverse()) restore(); },
  };
  return { clock, cabNodes, materialCount: allMaterials.length, baseline, candidate,
    limits: 'Only three verified cab-only buckets; mixed rig and site derivatives unchanged. Blending does not establish visible modeled interiors. Full-render dispatch counts include shadows/post passes.' };
}
