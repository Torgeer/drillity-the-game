/** Matched still-image diagnostics; never a phone/FPS acceptance result.
 * Run: node tools/validategraphics.mjs --out evidence/graphics/contrast-01
 * Requires graphics-contrast GPU lease. Uses only its own Vite port 5232.
 */
import { chromium } from 'playwright';
import { createServer } from 'vite';
import { readFileSync, writeFileSync, mkdirSync, readdirSync, existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve, relative } from 'node:path';
import { fileURLToPath } from 'node:url';
import assert from 'node:assert/strict';

const ownRoot = fileURLToPath(new URL('../', import.meta.url));
const root = resolve(ownRoot, '../drillity-graphics-validation');
const beforeEnv = resolve(ownRoot, 'evidence/regional-fog/env-before.js');
const afterEnv = resolve(ownRoot, 'src/core/env.js');
const terrainFile = resolve(ownRoot, '../drillity-terrain-graphics/src/world/terrain.js');
let activeEnv = beforeEnv;
const arg = process.argv.indexOf('--out');
const out = resolve(ownRoot, arg < 0 ? 'evidence/regional-fog/captures-01' : process.argv[arg + 1]);
assert.equal(readFileSync(resolve(root, '../drillity-coordination/gpu-owner.txt'), 'utf8').trim(), 'regional-fog');
assert(!existsSync(resolve(out, 'report.json')), 'Refusing to overwrite evidence');
mkdirSync(out, { recursive: true });
const sha = p => createHash('sha256').update(readFileSync(p)).digest('hex');
function manifest() {
  const files = [];
  const walk = p => { for (const e of readdirSync(p, { withFileTypes: true })) {
    const q = resolve(p, e.name); if (e.isDirectory()) walk(q); else if (e.isFile()) files.push(q);
  } };
  for (const p of ['src', 'public', 'node_modules/three/examples/jsm']) walk(resolve(root, p));
  for (const p of ['index.html', 'vite.config.js', 'package.json', 'package-lock.json', 'node_modules/three/build/three.module.js']) files.push(resolve(root, p));
  return Object.fromEntries(files.sort().map(p => [relative(root, p).replaceAll('\\', '/'), sha(p)]));
}
const report = { started: new Date().toISOString(), semantics: {
  factors: 'Separate fresh contexts serve baseline and candidate environment sources. Same seed, contract method/region/site, public depth and time controls; camera, rig, quality, site, lights and glass controls are compared. Wind, film grain and asynchronous loading clocks are not asserted pixel-identical across source contexts.',
  orbit: 'Both source variants retain the reviewed bounds-fit camera and far-field AO exclusion. Orbit is a near-rig glass control, not a camera intervention.',
  freeze: 'All system updates and render use dt=0 after settling, clock t/tSec restored each frame. No sim.debug.state writes. QA bridge creates a real generated contract then public debug.setDepth establishes the review depth. Stills do not measure FPS or certify a phone.'
}, sourceBefore: manifest(), inputHashes: {before:sha(beforeEnv),after:sha(afterEnv),terrain:sha(terrainFile),harness:sha(fileURLToPath(import.meta.url))}, cases: [], errors: [], cleanup: {} };
const save = () => writeFileSync(resolve(out, 'report.json'), JSON.stringify(report, null, 2));
let server, browser;
try {
  server = await createServer({ root, plugins:[{name:'regional-fog-source-pair',enforce:'pre',load(id){const path=resolve(id.split('?')[0]);if(path===resolve(root,'src/core/env.js'))return readFileSync(activeEnv,'utf8');if(path===resolve(root,'src/world/terrain.js'))return readFileSync(terrainFile,'utf8');}}], server: { host: '127.0.0.1', port: 5232, strictPort: true, hmr: false } });
  await server.listen();
  browser = await chromium.launch({ channel: 'chrome', headless: false, args: ['--disable-background-timer-throttling', '--disable-renderer-backgrounding', '--disable-backgrounding-occluded-windows', '--window-size=600,1000'] });
  const sceneCases = [
    ...[.34,.5,.7].map(tod=>({pair:'nordic-hero-'+tod,rig:'dth-crawler',method:'dth',region:'nordic',camera:'hero',seed:3,archetype:'well-pad',tod})),
    {pair:'nordic-glass-orbit',rig:'dth-crawler',method:'dth',region:'nordic',camera:'orbit',seed:3,archetype:'well-pad',tod:.34},
    {pair:'sahara-control',rig:'oil-derrick',method:'oil-rotary',region:'sahara',camera:'hero',tod:.34},
  ];
  const cases=sceneCases.flatMap(c=>['baseline','candidate'].map(variant=>({...c,variant,id:c.pair+'-'+variant})));
  for (const config of cases) {
    activeEnv=config.variant==='baseline'?beforeEnv:afterEnv; server.moduleGraph.invalidateAll(); console.log(`Capture ${config.id}`);
    const row = { config, servedEnvSha256:sha(activeEnv), errors: [], requestFailures: [], httpFailures: [], warnings: [], captures: [] };
    report.cases.push(row); save();
    const context = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
    let page;
    try {
      page = await context.newPage();
      page.on('pageerror', e => row.errors.push(String(e)));
      page.on('requestfailed', r => row.requestFailures.push({ url: r.url(), error: r.failure()?.errorText }));
      page.on('response', r => { if (r.status() >= 400) row.httpFailures.push({ url: r.url(), status: r.status() }); });
      page.on('console', m => { if (['error', 'warning'].includes(m.type())) row.warnings.push({ type: m.type(), text: m.text() }); });
      await page.goto('http://127.0.0.1:5232/?quality=high&glb=strict&shot&sound=0', { waitUntil: 'domcontentloaded' });
      await page.bringToFront();
      await page.waitForFunction(() => window.__DRILLITY?.__qa?.startDemoContract, null, { timeout: 180000 });
      // releaseBoot schedules the menu after exposing QA. Wait for that actual
      // handoff before asking for SITE, otherwise it can overwrite our request.
      await page.waitForFunction(() => window.__DRILLITY.ui.currentScene === 'menu', null, { timeout: 180000 });
      await page.waitForTimeout(350);
      row.setup = await page.evaluate(async config => {
        const c = window.__DRILLITY;
        const { makeRandom } = await import('/src/core/contract.js');
        c.rand = makeRandom(config.seed ?? 20260908);
        await c.gltfRigs.load(config.rig);
        const contract = await c.__qa.startDemoContract({ method: config.method, region: config.region, depth: 6 });
        if (contract.__stub) throw Error('QA bridge used a stub');
        if (config.archetype && contract.archetype !== config.archetype) throw Error(`Expected ${config.archetype}, got ${contract.archetype}`);
        c.state.garage.rigId = config.rig;
        if (!c.rig.setRig(config.rig)) throw Error('Rig refused');
        c.rig.setMethod(config.method); c.ui.show('site'); c.renderer.setCameraMode(config.camera);
        c.env.setWeather('clear'); c.env.setTimeOfDay(config.tod);
        c.sim.debug.setDepth(6); c.geology.setDepth?.(6);
        const simUpdate = c.sim.update;
        c.sim.update = function (_dt, ...rest) { return simUpdate.call(this, 0, ...rest); };
        window.__restoreSim = () => { c.sim.update = simUpdate; };
        const gl = c.renderer.gl.getContext(), ext = gl.getExtension('WEBGL_debug_renderer_info');
        return { contract, gpu: ext ? gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) : null, browser: navigator.userAgent };
      }, config);
      await page.waitForFunction(() => { const c = window.__DRILLITY, a = c.assets.stats(); if (a.failed) throw Error('Texture failure'); return a.sets > 0 && a.setsReady === a.sets && a.pending === 0 && (!c.terrain.siteModel.requested || c.terrain.siteModel.model); }, null, { timeout: 180000 });
      row.warm = await page.evaluate(() => window.__DRILLITY.renderer.warmShaders());
      assert.equal(row.warm.ready, true, 'Warm shaders not ready');
      await page.waitForTimeout(1500);
      await page.evaluate(mode => { const c = window.__DRILLITY; if (c.ui.currentScene !== 'site') throw Error('SITE handoff lost'); c.renderer.setCameraMode(mode); }, config.camera);
      await page.waitForTimeout(8000);
      row.freeze = await page.evaluate(installFrozen);
      await page.evaluate(() => window.__GRAPHICS.frames(24));
      const capture = async (label, overrides = {}) => {
        await page.evaluate(overrides => window.__GRAPHICS.set(overrides), overrides);
        await page.evaluate(() => window.__GRAPHICS.frames(12));
        const before = await page.evaluate(() => window.__GRAPHICS.snapshot());
        const path = `${config.id}-${label}.png`;
        await page.screenshot({ path: resolve(out, path) });
        const after = await page.evaluate(() => window.__GRAPHICS.snapshot());
        assert.deepEqual(after.identity, before.identity, `${config.id}/${label}: identity drift`);
        for (const s of [before, after]) {
          assert.equal(s.visible, 'visible'); assert.equal(s.focused, true); assert.equal(s.contextLost, false);
          assert(s.assets.sets > 0 && s.assets.setsReady === s.assets.sets && s.assets.pending === 0 && s.assets.failed === 0, 'Assets not ready');
        }
        assert.equal(before.identity.rig.id, config.rig); assert.equal(before.identity.rig.source, 'glb');
        assert.equal(before.identity.cameraMode, config.camera, 'Requested camera mode not active');
        assert.equal(before.identity.screen, 'site', 'Requested SITE screen not active');
        row.captures.push({ label, path, sha256: sha(resolve(out, path)), overrides, before, after }); save();
      };
      const expected=JSON.parse(readFileSync(resolve(ownRoot,'evidence/regional-fog/'+config.variant+'.json'),'utf8')).cases.find(x=>x.region===config.region&&x.weather==='clear'&&Math.abs(x.tod-config.tod)<1e-8);
      assert(expected,'Missing real CPU solver expectation');
      row.actualFog=await page.evaluate(()=>{const c=window.__DRILLITY;return {color:c.scene.fog.color.toArray(),density:c.scene.fog.density,noAO:c.terrain.root.getObjectByName('far-field').userData.noAO,region:c.terrain.regionId};});
      assert.deepEqual(row.actualFog.color,expected.fog.linear,'Wrong served fog source');assert.equal(row.actualFog.density,expected.fog.density);assert.equal(row.actualFog.noAO,true);assert.equal(row.actualFog.region,config.region);
      await capture('source',{});
      row.glass=await page.evaluate(async()=>{const c=window.__DRILLITY,T=await import('/node_modules/three/build/three.module.js'),rows=[];c.rig.group.traverse(o=>{if(!o.isMesh)return;const ms=(Array.isArray(o.material)?o.material:[o.material]);if(!ms.some(m=>m.name.toLowerCase().includes('glass')))return;const box=new T.Box3().setFromObject(o),pos=box.getCenter(new T.Vector3());rows.push({name:o.name,distance:pos.distanceTo(c.camera.position),ndc:pos.project(c.camera).toArray(),material:ms.map(m=>({name:m.name,color:m.color.toArray(),roughness:m.roughness,metalness:m.metalness,transmission:m.transmission||0}))});});return rows;});
      assert.equal(row.errors.length, 0, 'Page errors');
      assert.equal(row.httpFailures.length, 0, 'HTTP failures');
      assert.equal(row.requestFailures.length, 0, 'Request failures');
      row.valid = true;
    } catch (error) {
      row.failure = String(error.stack || error); throw error;
    } finally {
      if (page) try { row.cleanup = await page.evaluate(() => { window.__GRAPHICS?.cleanup(); window.__restoreSim?.(); return { restored: true }; }); } catch (e) { row.cleanup = { error: String(e) }; }
      await context.close(); row.contextClosed = true; save();
    }
  }
  report.pairs=[];
  for(const config of sceneCases){const a=report.cases.find(x=>x.config.pair===config.pair&&x.config.variant==='baseline'),b=report.cases.find(x=>x.config.pair===config.pair&&x.config.variant==='candidate');const ai=a.captures[0].before.identity,bi=b.captures[0].before.identity;
    const cameraError=Math.max(...ai.camera.world.map((v,i)=>Math.abs(v-bi.camera.world[i])),...ai.camera.projection.map((v,i)=>Math.abs(v-bi.camera.projection[i])));
    assert(cameraError<1e-7,'Source-pair camera drift');
    for(const key of ['rig','cameraMode','quality','viewport','buffer','dpr','screen','site','archetype','env'])assert.deepEqual(ai[key],bi[key],'Source-pair '+key+' drift');
    assert.deepEqual(a.glass,b.glass,'Glass material/geometry/camera drift');
    report.pairs.push({pair:config.pair,cameraError,glassSurfaces:a.glass.length});
  }
  report.valid = true;
} catch (e) { report.valid = false; report.errors.push(String(e.stack || e)); process.exitCode = 1; }
finally {
  if (browser) try { await browser.close(); report.cleanup.browserClosed = true; } catch (e) { report.cleanup.browserError = String(e); }
  if (server) try { await server.close(); report.cleanup.serverClosed = true; } catch (e) { report.cleanup.serverError = String(e); }
  report.inputsAfter={before:sha(beforeEnv),after:sha(afterEnv),terrain:sha(terrainFile),harness:sha(fileURLToPath(import.meta.url))}; report.inputsUnchanged=JSON.stringify(report.inputHashes)===JSON.stringify(report.inputsAfter); if(!report.inputsUnchanged){report.valid=false;report.errors.push('Frozen inputs changed');process.exitCode=1;} report.sourceAfter = manifest(); report.sourceUnchanged = JSON.stringify(report.sourceBefore) === JSON.stringify(report.sourceAfter);
  if (!report.sourceUnchanged) { report.valid = false; process.exitCode = 1; }
  report.finished = new Date().toISOString(); save();
  console.log(JSON.stringify({ valid: report.valid, cases: report.cases.map(r => ({ id: r.config.id, valid: r.valid, failure: r.failure })), cleanup: report.cleanup }));
}

function installFrozen() {
  const c = window.__DRILLITY, restores = [];
  const clock = { t: c.clock.t, fps: c.clock.fps, tSec: c.state.tSec };
  let first = true;
  for (const s of c.systems) {
    if (typeof s.update !== 'function') continue;
    const old = s.update, ownsClock = first; first = false;
    s.update = function (_dt, ...rest) { if (ownsClock) { c.clock.t = clock.t; c.clock.dt = 0; c.clock.fps = clock.fps; c.state.tSec = clock.tSec; } return old.call(this, 0, ...rest); };
    restores.push(() => { s.update = old; });
  }
  const paint = [], seen = new Set();
  for (const scene of [c.scene, c.sectionScene]) scene.traverse(o => {
    for (const m of o.material ? (Array.isArray(o.material) ? o.material : [o.material]) : []) {
      if (seen.has(m)) continue; seen.add(m);
      if (['drillity:paintedSteel', 'drillity:paintedDark'].includes(m.name) && m.roughness === 1 && m.metalness === 1) paint.push({ material: m, roughness: m.roughness, metalness: m.metalness });
    }
  });
  if (!paint.length) throw Error('No neutral-factor candidate paint found');
  const candidateFog = c.scene.fog?.density;
  const fogScale = c.env.regionId === 'sahara' && c.env.weather === 'clear' && !c.env.undergroundId ? .0062 / .0032 : 1;
  const fit = c.rig.getSpec().glb.feedFraming || c.rig.getSpec().glb.framing;
  const cx = (fit.min[0] + fit.max[0]) / 2, cz = (fit.min[2] + fit.max[2]) / 2;
  const angle = Math.atan2(c.camera.position.x - cx, c.camera.position.z - cz);
  let current = {};
  const originalMatrix = c.camera.updateMatrixWorld;
  c.camera.updateMatrixWorld = function (...args) {
    if (current.camera === 'legacy') {
      this.position.set(Math.sin(angle) * 13, 2.7, Math.cos(angle) * 13);
      // Avoid lookAt's recursive updateWorldMatrix: build the rotation directly.
      const matrix = this.matrix.clone(); matrix.lookAt(this.position, { x: 0, y: 3.05, z: 0 }, this.up);
      this.quaternion.setFromRotationMatrix(matrix);
    }
    return originalMatrix.apply(this, args);
  };
  restores.push(() => { c.camera.updateMatrixWorld = originalMatrix; });
  const oldRender = c.renderer.render;
  c.renderer.render = function () {
    if (c.scene.fog && candidateFog !== undefined) c.scene.fog.density = current.fog === 'legacy' ? candidateFog * fogScale : candidateFog;
    for (const p of paint) { p.material.roughness = current.paint === 'legacy' ? .34 : p.roughness; p.material.metalness = current.paint === 'legacy' ? .04 : p.metalness; }
    return oldRender.call(this, 0);
  };
  restores.push(() => { c.renderer.render = oldRender; });
  const clone = v => v === undefined ? null : JSON.parse(JSON.stringify(v));
  const matrix = cam => ({ position: cam.position.toArray(), world: cam.matrixWorld.toArray(), inverse: cam.matrixWorldInverse.toArray(), projection: cam.projectionMatrix.toArray(), fov: cam.fov, aspect: cam.aspect });
  const graph = () => { const rows = []; for (const scene of [c.scene, c.sectionScene]) scene.traverse(o => rows.push([o.uuid, o.visible, o.position.toArray(), o.quaternion.toArray(), o.scale.toArray(), o.geometry?.uuid || null])); return rows; };
  const rigGraph = () => { const rows = []; c.rig.group.traverse(o => rows.push([o.uuid, o.visible, o.position.toArray(), o.quaternion.toArray(), o.scale.toArray(), o.geometry?.uuid || null])); return rows; };
  window.__GRAPHICS = {
    set(overrides) { current = overrides; },
    frames(n) { return new Promise((done, reject) => { let left = n, handle; const timeout = setTimeout(() => { cancelAnimationFrame(handle); reject(Error('RAF timeout')); }, 30000); function tick() { if (--left === 0) { clearTimeout(timeout); done(); } else handle = requestAnimationFrame(tick); } handle = requestAnimationFrame(tick); }); },
    snapshot() {
      const gl = c.renderer.gl.getContext();
      return { identity: { simulation: clone(c.sim.debug.state), state: clone(c.state), rig: clone(c.rig.getSpec()), cameraMode: c.renderer.cameraMode, camera: matrix(c.camera), sectionCamera: matrix(c.sectionCamera), graph: graph(), rigGraph: rigGraph(), clock, quality: clone(c.quality), viewport: clone(c.viewport), buffer: [gl.drawingBufferWidth, gl.drawingBufferHeight], dpr: c.renderer.gl.getPixelRatio(), screen: c.ui.currentScene, site: clone(c.terrain.siteModel), archetype: c.terrain.archetype, env: { region: c.env.regionId, weather: c.env.weather, timeOfDay: c.env.timeOfDay, underground: c.env.undergroundId, exposure: c.renderer.exposure, sun: c.env.sun.intensity, hemi: c.env.hemi.intensity }, fog: c.scene.fog ? { density: c.scene.fog.density, color: c.scene.fog.color.toArray() } : null, materials: paint.map(p => ({ name: p.material.name, uuid: p.material.uuid, roughness: p.material.roughness, metalness: p.material.metalness, color: p.material.color.toArray() })) }, assets: clone(c.assets.stats()), draw: clone(c.renderer.gl.info.render), programs: c.renderer.gl.info.programs.length, visible: document.visibilityState, focused: document.hasFocus(), contextLost: gl.isContextLost() };
    },
    cleanup() { current = {}; if (c.scene.fog && candidateFog !== undefined) c.scene.fog.density = candidateFog; for (const p of paint) { p.material.roughness = p.roughness; p.material.metalness = p.metalness; } for (const restore of restores.reverse()) restore(); },
  };
  return { clock, paintMaterials: paint.length, candidateFog, fogScale, legacyCameraAngle: angle };
}
