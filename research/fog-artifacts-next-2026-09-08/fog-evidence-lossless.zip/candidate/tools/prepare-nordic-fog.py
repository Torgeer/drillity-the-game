"""Restore the reviewed narrow fog candidate on the immutable resume-70 source."""
from pathlib import Path
import hashlib, json, difflib
root=Path(__file__).resolve().parent.parent
old=root.parent/'drillity-regional-fog'
out=root/'evidence/nordic-fog'
baseline=root.parent/'drillity-coordination/resume-70-baseline-2026-09-08/src/core/env.js'
before=baseline.read_bytes()
assert hashlib.sha256(before).hexdigest()=='af2afb3afbae2b49965e0673fa42f46d4fbf6b3de9e7e15d3e8ad2b4caca8511'
candidate=(old/'src/core/env.js').read_bytes()
assert hashlib.sha256(candidate).hexdigest()=='3d218dd6d95fa79c1aad2b4872e910f577d214b0531ab8d2095f796f0bd6bcea'
out.mkdir(parents=True,exist_ok=True)
(out/'env-before.js').write_bytes(before)
(root/'src/core/env.js').write_bytes(candidate)
(out/'nordic-fog-delta.patch').write_text(''.join(difflib.unified_diff(before.decode().splitlines(True),candidate.decode().splitlines(True),fromfile='a/src/core/env.js',tofile='b/src/core/env.js')),encoding='utf-8')
for source,dest in [('checkregionalfog.mjs','checknordicfog.mjs'),('measureregionalfog.mjs','measurenordicfog.mjs')]:
    text=(old/'tools'/source).read_text(encoding='utf-8').replace('regional-fog','nordic-fog')
    (root/'tools'/dest).write_text(text,encoding='utf-8')
print(json.dumps({'baseline':hashlib.sha256(before).hexdigest(),'candidate':hashlib.sha256(candidate).hexdigest()}))
