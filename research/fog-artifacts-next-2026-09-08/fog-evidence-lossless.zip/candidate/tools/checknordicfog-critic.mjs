/** Independent controls for the Nordic fog stills. No browser/GPU.
 * node tools/checknordicfog-critic.mjs --self-test
 * node tools/checknordicfog-critic.mjs --report evidence/nordic-fog/captures-02 --preflight
 */
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';
import * as THREE from 'three';
import { createHash } from 'node:crypto';

const root = fileURLToPath(new URL('../', import.meta.url));
export const CAMERA_EPSILON = 1e-7; // Retain the old declared limit; never widen it.
const clone = x => structuredClone(x);

export function assertRecordedEqual(a, b, label = 'record', epsilon = 0) {
  assert.equal(typeof a, typeof b, `${label}: type`);
  if (typeof a === 'number') {
    assert(Number.isFinite(a) && Number.isFinite(b), `${label}: non-finite value`);
    assert(Math.abs(a - b) <= epsilon, `${label}: ${a} != ${b}`); return;
  }
  if (a === null || b === null || typeof a !== 'object') {
    assert.equal(a, b, label); return;
  }
  assert.equal(Array.isArray(a), Array.isArray(b), `${label}: array type`);
  assert.deepEqual(Object.keys(a), Object.keys(b), `${label}: fields`);
  for (const k of Object.keys(a)) assertRecordedEqual(a[k], b[k], `${label}.${k}`, epsilon);
}

export function assertCompleteCamera(c, label = 'camera') {
  for (const [name, length] of Object.entries({position:3, quaternion:4, scale:3, up:3,
    matrix:16, world:16, inverse:16, projection:16, projectionInverse:16})) {
    assert(Array.isArray(c[name]) && c[name].length === length, `${label}.${name}: missing/wrong length`);
    assert(c[name].every(Number.isFinite), `${label}.${name}: non-finite`);
  }
  for (const k of ['near', 'far', 'zoom']) assert(Number.isFinite(c[k]), `${label}.${k}: missing/non-finite`);
  assert(c.near >= 0 && c.far > c.near && c.zoom > 0, `${label}: invalid lens range`);
  if (c.type === 'PerspectiveCamera') {
    for (const k of ['fov','aspect','focus','filmGauge','filmOffset']) assert(Number.isFinite(c[k]), `${label}.${k}: missing/non-finite`);
  } else {
    assert.equal(c.type, 'OrthographicCamera', `${label}: missing camera type`);
    for (const k of ['left','right','top','bottom']) assert(Number.isFinite(c[k]), `${label}.${k}: missing/non-finite`);
  }
  assert(Object.hasOwn(c, 'view'), `${label}.view: missing`);
  if (c.view !== null) {
    assert.equal(typeof c.view.enabled, 'boolean', `${label}.view.enabled`);
    for (const k of ['fullWidth','fullHeight','offsetX','offsetY','width','height']) assert(Number.isFinite(c.view[k]), `${label}.view.${k}`);
  }
  for (const [matrix, inverse] of [['world','inverse'], ['projection','projectionInverse']]) {
    const product = new THREE.Matrix4().fromArray(c[matrix]).multiply(new THREE.Matrix4().fromArray(c[inverse]));
    const expected = new THREE.Matrix4().elements;
    product.elements.forEach((v, i) => assert(Math.abs(v - expected[i]) <= CAMERA_EPSILON, `${label}: inconsistent ${matrix}/${inverse}`));
  }
}

export function assertCompleteCameraPair(a, b, label = 'camera') {
  assertCompleteCamera(a, label + '.before'); assertCompleteCamera(b, label + '.after');
  assertRecordedEqual(a, b, label, CAMERA_EPSILON);
}

/** Mutates only a cloned comparison record; raw evidence is never rewritten. */
export function normalizeComparableSnapshot(s, region) {
  const loadingNumber=(obj,key,integer=false)=>{
    assert(Number.isFinite(obj?.[key])&&obj[key]>=0,'Invalid measured loading telemetry '+key);
    if(integer)assert(Number.isInteger(obj[key]),'Noninteger loading counter '+key);
    obj[key]=0;
  };
  for(const key of ['count','maxMs','avgMs','overFrameBudget']) loadingNumber(s.assets.slices,key,['count','overFrameBudget'].includes(key));
  for(const key of ['fetchMs','parseMs'])loadingNumber(s.rig.glb,key);
  for(const object of s.scene.objects)if(object.userData?.spec?.source==='glb'){
    for(const key of ['fetchMs','parseMs'])loadingNumber(object.userData.spec.glb,key);
  }
  for(const row of s.scene.uuidBookkeeping){assert.equal(typeof row.uuid,'string');row.uuid='explicit-UUID-bookkeeping';}
  const surface=s.scene.objects.filter(o=>o.path==='surface');assert.equal(surface.length,1);
  assert.equal(surface[0].scene.fog.type,'FogExp2');
  assert.deepEqual(surface[0].scene.fog.color,s.fog.color);
  assert.equal(surface[0].scene.fog.density,s.fog.density);
  for(const name of ['vfx:surfaceSoft','vfx:surfaceAdd']){
    const owners=s.scene.objects.filter(o=>o.name===name);assert.equal(owners.length,1);
    const owner=owners[0];assert(owner.path.startsWith('surface/'));assert.equal(owner.materials.length,1);
    const u=s.scene.materials[owner.materials[0]].uniforms;
    assert.equal(u.uFogMode,2);assert.equal(u.uFogDensity,s.fog.density);
    assert.deepEqual(u.uFogTarget,{type:'Color',value:name==='vfx:surfaceSoft'?s.fog.color:[0,0,0]});
    if(region==='nordic'){
      u.uFogDensity=0;
      if(name==='vfx:surfaceSoft')u.uFogTarget.value=[0,0,0];
    }
  }
  if(region!=='nordic')return;
  surface[0].scene.fog.color=[0,0,0];surface[0].scene.fog.density=0;
  const far=s.scene.objects.filter(o=>o.name==='far-field');assert.equal(far.length,1);
  assert.equal(far[0].userData.noAO,true,'Far-field AO exclusion changed');
  s.scene.geometries[far[0].geometry].attributes.color.array.sha256='intentional-far-field-baked-fog-color';
  const clouds=s.scene.materials.filter(m=>m.uniforms.uHorizonCol);assert.equal(clouds.length,1);
  assert.deepEqual(clouds[0].uniforms.uHorizonCol,{type:'Color',value:s.fog.color});
  clouds[0].uniforms.uHorizonCol.value=[0,0,0];s.fog={color:[0,0,0],density:0};
}

function selfTest() {
  const previous = JSON.parse(readFileSync(resolve(root,
    '../drillity-regional-fog/evidence/regional-fog/captures-01/report.json'), 'utf8'));
  assert.equal(previous.valid, false, 'Historical rejected capture must remain rejected');
  const results = [], run = (name, fn) => { fn(); results.push(name); };
  const failures = [];
  for (let i = 0; i < previous.cases.length; i += 2) {
    const a = previous.cases[i], b = previous.cases[i + 1];
    const ca = a.captures[0].before.identity.camera, cb = b.captures[0].before.identity.camera;
    run('Reject the real old camera pair: ' + a.config.pair, () => {
      assertRecordedEqual(ca, clone(ca), 'self control', CAMERA_EPSILON);
      assert.throws(() => assertRecordedEqual(ca, cb, a.config.pair, CAMERA_EPSILON));
    });
    failures.push({pair:a.config.pair,
      worldMaxError:Math.max(...ca.world.map((x,j)=>Math.abs(x-cb.world[j]))),
      projectionMaxError:Math.max(...ca.projection.map((x,j)=>Math.abs(x-cb.projection[j])))});
  }
  const camera = new THREE.PerspectiveCamera(40, .9, .1, 2000);
  camera.position.set(5,4,20); camera.lookAt(0,3,0); camera.updateMatrixWorld();
  const complete = {type:camera.type,position:camera.position.toArray(),quaternion:camera.quaternion.toArray(),
    scale:camera.scale.toArray(),up:camera.up.toArray(),matrix:camera.matrix.toArray(),world:camera.matrixWorld.toArray(),
    inverse:camera.matrixWorldInverse.toArray(),projection:camera.projectionMatrix.toArray(),projectionInverse:camera.projectionMatrixInverse.toArray(),
    near:camera.near,far:camera.far,zoom:camera.zoom,fov:camera.fov,aspect:camera.aspect,focus:camera.focus,
    filmGauge:camera.filmGauge,filmOffset:camera.filmOffset,view:camera.view};
  run('Complete real Three camera and unchanged controls pass', () => assertCompleteCameraPair(complete, clone(complete)));
  for (const key of ['position','quaternion','scale','up','matrix','world','inverse','projection','projectionInverse']) {
    run('Reject altered ' + key, () => { const c = clone(complete); c[key][0] += .00014; assert.throws(() => assertCompleteCameraPair(complete,c)); });
    run('Reject omitted ' + key, () => { const c = clone(complete); delete c[key]; assert.throws(() => assertCompleteCameraPair(complete,c)); });
  }
  for (const key of ['near','far','zoom','fov','aspect','focus','filmGauge','filmOffset']) {
    run('Reject altered lens ' + key, () => { const c = clone(complete); c[key] += .00014; assert.throws(() => assertCompleteCameraPair(complete,c)); });
  }
  run('Reject mismatched view offset', () => {
    const c = clone(complete); c.view = {enabled:true,fullWidth:390,fullHeight:844,offsetX:1,offsetY:0,width:390,height:844};
    assert.throws(() => assertCompleteCameraPair(complete,c));
  });
  run('Reject NaN even on both sides', () => { const c = clone(complete); c.world[0] = NaN; assert.throws(() => assertCompleteCameraPair(c,clone(c))); });
  run('Reject old evidence missing complete camera metadata', () => assert.throws(() => assertCompleteCamera(previous.cases[0].captures[0].before.identity.camera)));

  // Exercise whole records rather than a hand-picked subset that could hide
  // material sharing, geometry, viewport or gameplay changes.
  const controls = {viewport:{css:[390,844],buffer:[780,1688],dpr:2,bands:[0,80,390,320]},
    state:{tSec:20,contract:'actual-job',loadout:{bit:'actual-bit'}},simulation:{depth:6,phase:'drilling'},
    graph:[{path:'surface/rig/glass',position:[0,0,0],geometry:{position:'hashP',normal:'hashN',index:'hashI'},material:0},
      {path:'surface/rig/lens',position:[0,0,0],geometry:{position:'hashQ'},material:0},
      {path:'section/geology',position:[0,0,0],geometry:{position:'hashG',color:'hashC'},material:1}],
    materials:[{color:[.1,.2,.3],transmission:0,map:'hashM'},{color:[.3,.2,.1],transmission:0,map:'hashN'}]};
  const mutations = [
    c=>c.viewport.dpr=1, c=>c.viewport.bands[1]++, c=>c.state.loadout.bit='different-bit',
    c=>c.simulation.depth=7, c=>c.graph[0].position[0]=1, c=>c.graph[0].geometry.position='changed',
    c=>c.graph[1].material=1, c=>c.graph[2].geometry.color='overridden-geology',
    c=>c.materials[0].transmission=.1, c=>c.materials[0].color[0]=.4, c=>c.materials[0].map='changed-image',
  ];
  mutations.forEach((mutate, i) => run('Reject changed whole-scene control ' + i, () => {
    const altered = clone(controls); mutate(altered); assert.throws(() => assertRecordedEqual(controls,altered));
  }));
  const rejectedVfx=JSON.parse(readFileSync(resolve(root,'evidence/nordic-fog/captures-02/report.json'),'utf8'));
  assert.equal(rejectedVfx.valid,false);
  const [vfxA,vfxB]=rejectedVfx.cases.map(c=>clone(c.before));
  normalizeComparableSnapshot(vfxA,'nordic');normalizeComparableSnapshot(vfxB,'nordic');
  run('Real captures-02 still rejected after exact fog and timing bookkeeping normalization',()=>assert.throws(()=>assertRecordedEqual(vfxA,vfxB)));
  run('Unchanged normalized real capture passes',()=>assertRecordedEqual(vfxA,clone(vfxA)));
  const sourceRow=rejectedVfx.cases[0].before;
  const rejects=[
    s=>s.scene.geometries[106].attributes.iPos.array.sha256='changed',
    s=>s.scene.materials[42].uniforms.uWind.value[0]+=.01,
    s=>s.rig.glb.prims++,
    s=>s.state.tSec++,
    s=>s.scene.materials[43].uniforms.uFogTarget.value[0]=.01,
    s=>s.scene.materials[42].uniforms.uFogDensity=.1,
    s=>s.assets.slices.count='missing',
    s=>s.rig.glb.fetchMs=-1,
    s=>s.assets.slices.overFrameBudget=.5,
    s=>s.scene.objects.push(clone(s.scene.objects.find(o=>o.name==='vfx:surfaceSoft'))),
  ];
  rejects.forEach((mutate,i)=>run('Reject altered real capture after source-owned normalization '+i,()=>{
    const changed=clone(sourceRow);mutate(changed);
    assert.throws(()=>{normalizeComparableSnapshot(changed,'nordic');assertRecordedEqual(vfxA,changed);});
  }));
  const report = {passed:results.length,groups:results,oldRejectedPairs:failures,
    limits:'CPU gate self-tests and real historical rejected matrices only; no new candidate visual acceptance.'};
  const out = resolve(root,'evidence/nordic-fog-critic'); mkdirSync(out,{recursive:true});
  writeFileSync(resolve(out,'negative-controls.json'),JSON.stringify(report,null,2));
  console.log(JSON.stringify(report,null,2));
}

function validateCapture(directory, preflight = false) {
  const dir = resolve(root, directory);
  const raw = p => readFileSync(resolve(root, p));
  const hash = p => createHash('sha256').update(raw(p)).digest('hex');
  const read = p => JSON.parse(raw(p).toString());
  const report = read(resolve(dir, 'report.json'));
  assert.equal(report.valid, true, 'Capture is rejected or unfinished');
  assert.deepEqual(report.errors, []); assert.equal(report.sourceUnchanged, true);
  assert.equal(report.inputsUnchanged, true);
  assert.deepEqual(report.sourceBefore, report.sourceAfter); assert.deepEqual(report.inputHashes, report.inputsAfter);
  assert.deepEqual(report.cleanup, {browserClosed:true,serverClosed:true});
  for (const [p, expected] of Object.entries(report.sourceBefore)) assert.equal(hash(p), expected, p + ': served source changed');
  for (const [field, p] of Object.entries({baseline:'evidence/nordic-fog/env-before.js',candidate:'src/core/env.js',
    main:'src/main.js',transformedMain:resolve(dir,'served-main.js'),harness:resolve(dir,'capture-source.mjs'),controls:resolve(dir,'controls-source.mjs'),pair:resolve(dir,'pair-source.mjs')})) {
    assert.equal(hash(p), report.inputHashes[field], field + ': input hash mismatch');
  }
  const old = raw('evidence/nordic-fog/env-before.js').toString().replaceAll('\r\n','\n');
  const candidate = raw('src/core/env.js').toString().replaceAll('\r\n','\n');
  const insertions = [
    '    // Clear-air authoring: mix the existing Nordic sky tint into the ambient\n' +
    '    // haze. Keep the shared low-sun warming and all weather recipes below.\n' +
    '    clearFogSkyMix: 0.70, clearFogDensity: 0.0034,\n',
    "    if (weatherName === 'clear' && recipe.clearFogSkyMix != null) {\n" +
    '      fogColor.lerp(_scratchColor.set(recipe.skyTint), recipe.clearFogSkyMix);\n' +
    '    }\n',
  ];
  let reverted = candidate;
  for (const s of insertions) { assert.equal(reverted.split(s).length,2); reverted=reverted.replace(s,''); }
  assert.equal(reverted, old, 'Candidate contains a change beyond Nordic clear fog');
  const snapshot = read('../drillity-coordination/resume-70-baseline-2026-09-08/manifest.json');
  for (const row of snapshot.files) if (row.path.startsWith('src/') && row.path !== 'src/core/env.js') {
    assert.equal(hash(row.path), row.sha256, row.path + ': non-fog production change');
  }
  const canonicalCamera = c => ({...c,...c.lens});
  const seenPairs = [...new Set(report.cases.map(c=>c.config.pair))];
  const expected = preflight ? ['nordic-hero-0.34'] : ['nordic-hero-0.34','nordic-hero-0.5','nordic-hero-0.7','nordic-glass-orbit','sahara-control'];
  assert.deepEqual(seenPairs, expected, 'Case coverage mismatch');
  assert.deepEqual(report.requestedPairs, expected, 'Declared case coverage mismatch');
  assert.equal(report.completeFivePairSeries, !preflight);
  assert.equal(report.cases.length, expected.length*2);
  for (const row of report.cases) {
    assert.equal(row.valid,true); assert.equal(row.contextClosed,true); assert.equal(row.controlsRestored,true);
    for (const key of ['errors','requestFailures','httpFailures']) assert.deepEqual(row[key],[]);
    assert.equal(row.servedEnvSha256, report.inputHashes[row.variant==='baseline'?'baseline':'candidate']);
    assert.equal(hash(resolve(dir,row.png)),row.pngSha256);
    assertRecordedEqual(row.before,row.after,row.id + ': within-capture identity');
    const solver=read('evidence/nordic-fog/'+row.variant+'.json');
    assert.equal(solver.envSha256,row.servedEnvSha256);
    const probe=solver.cases.find(c=>c.region===row.config.region&&c.weather==='clear'&&c.tod===row.config.tod);
    assert(probe,'Missing source-matched actual solver expectation');
    assert.deepEqual(row.before.fog,{color:probe.fog.linear,density:probe.fog.density});
    assert.equal(row.setup.simMethod,row.config.method); assert.equal(row.setup.simBit,row.setup.loadout.bit);
    assert.deepEqual(row.setup.randomControls,{visualSeed:20260908,contractSeed:row.config.seed,
      retainedObjectUnchanged:true,contextStreamDistinct:true,methodsReseeded:true,
      methodNames:['f','range','int','pick','bool','gauss']});
    assert.deepEqual(row.setup.frameAccumulatorReset.after,{fpsAccum:0,fpsFrames:0});
    assert(Number.isFinite(row.setup.frameAccumulatorReset.before.fpsAccum));
    assert(Number.isInteger(row.setup.frameAccumulatorReset.before.fpsFrames));
    for (const frame of [row.before,row.after]) {
      assert.equal(frame.screen,'site'); assert.equal(frame.cameraMode,row.config.camera);
      assert.equal(frame.rig.id,row.config.rig); assert.equal(frame.rig.source,'glb');
      assert.equal(frame.visible,'visible'); assert.equal(frame.focused,true); assert.equal(frame.contextLost,false);
      assert(frame.assets.sets>0); assert.equal(frame.assets.setsReady,frame.assets.sets);
      assert.equal(frame.assets.pending,0); assert.equal(frame.assets.failed,0);
      assert.equal(frame.dpr,2); assert.deepEqual(frame.buffer,[780,1688]);
      assert(frame.vfx?.stats&&Array.isArray(frame.vfx.wind),'Missing actual VFX controls');
      assert.deepEqual(frame.vfx.wind,[frame.vfx.stats.wind.x,frame.vfx.stats.wind.y,frame.vfx.stats.wind.z]);
      for (const field of ['viewport','bands','bandsRect','chrome','state','simulation','scene']) assert(frame[field]&&typeof frame[field]==='object', 'Missing '+field);
      for (const band of ['surface','section']) {
        assertCompleteCameraPair(canonicalCamera(frame.cameras[band]),canonicalCamera(row.controls.fixed[band]),row.id+':'+band);
        const observations=frame.observations.filter(o=>o.band===band); assert(observations.length>0);
        assert(observations.some(o=>o.overrideMaterial===null),band+': color pass not observed');
        assert(observations.some(o=>o.overrideMaterial==='MeshNormalMaterial'),band+': AO normal pass not observed');
        for (const o of observations) assertRecordedEqual(o.camera,row.controls.fixed[band],row.id+': actual '+band+' render camera');
      }
      const section=frame.scene.objects.find(o=>o.path==='section');
      assert(section?.scene,'Section scene properties not recorded'); assert.equal(section.scene.fog,null);
      assert.equal(section.scene.overrideMaterial,null);
      assert(frame.scene.textures.every(t=>t.content!==undefined),'Missing texture evidence descriptor');
      for (const m of frame.scene.materials) if (typeof m.props.transmission==='number') assert.equal(m.props.transmission,0);
    }
  }
  const comparisons=[];
  for (const pair of expected) {
    const a=report.cases.find(c=>c.config.pair===pair&&c.variant==='baseline');
    const b=report.cases.find(c=>c.config.pair===pair&&c.variant==='candidate');
    assert(a&&b); const aa=clone(a.before),bb=clone(b.before);
    assertRecordedEqual(a.controls.fixed,b.controls.fixed,pair+': same canonical camera');
    for (const band of ['surface','section']) assertCompleteCameraPair(canonicalCamera(aa.cameras[band]),canonicalCamera(bb.cameras[band]),pair+':'+band);
    if (a.config.region==='nordic') assert.notDeepEqual(aa.fog,bb.fog,'Stale source could falsely pass');
    else assert.deepEqual(aa.fog,bb.fog,'Control-region fog changed');
    normalizeComparableSnapshot(aa,a.config.region);normalizeComparableSnapshot(bb,b.config.region);
    assertRecordedEqual(aa,bb,pair+': all unaltered scene/state controls');
    comparisons.push({pair,completeCameraMatch:true,allUnalteredStateAndSceneMatch:true,
      glass:a.before.glass,renderTargetLimit:a.before.scene.scope?.gpuTextureContent});
  }
  const result={acceptedControls:true,visualReviewStillRequired:true,pairs:comparisons,
    preflightOnly:preflight,limits:'Recorded GPU render-target descriptors have no texel readback. Controlled stills do not measure FPS or certify phones.'};
  mkdirSync(resolve(root,'evidence/nordic-fog-critic'),{recursive:true});
  writeFileSync(resolve(root,'evidence/nordic-fog-critic/capture-validation.json'),JSON.stringify(result,null,2));
  console.log(JSON.stringify(result,null,2));
}

if (process.argv.includes('--self-test')) selfTest();
else if (process.argv.includes('--report')) validateCapture(process.argv[process.argv.indexOf('--report')+1],process.argv.includes('--preflight'));
else if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  throw Error('Use --self-test or --report <capture-directory> [--preflight].');
}
