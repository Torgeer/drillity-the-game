/** Exact CPU differential of public env APIs against the reviewed source snapshot.
 * No browser/GPU or claim about the rendered sky. This is a candidate review gate.
 */
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { createBus } from '../src/core/contract.js';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const envURL=new URL('../src/core/env.js',import.meta.url);
const before=readFileSync(new URL('../evidence/nordic-fog/env-before.js',import.meta.url),'utf8');
const after=readFileSync(envURL,'utf8');
const sha=s=>createHash('sha256').update(s).digest('hex');
assert.equal(sha(before),'af2afb3afbae2b49965e0673fa42f46d4fbf6b3de9e7e15d3e8ad2b4caca8511','Baseline changed');
async function load(source){const text=source.replace(/from (['"])([^'"]+)\1/g,(_m,q,p)=>`from ${q}${p.startsWith('.')?new URL(p,envURL).href:import.meta.resolve(p)}${q}`);return import('data:text/javascript;base64,'+Buffer.from(text).toString('base64'));}
const factories=await Promise.all([load(before),load(after)]);
function table(name){const m=before.match(new RegExp(`const ${name} = (\\{[\\s\\S]*?\\n\\});`));assert(m,'Missing '+name);return Function('return '+m[1])();}
const regions=Object.keys(table('REGIONS')),weather=Object.keys(table('WEATHER'));
assert.equal(regions.length,8);assert.equal(weather.length,5);
const contexts=[];
for(const {createEnvironment} of factories){const ctx={scene:new THREE.Scene(),sectionScene:new THREE.Scene(),bus:createBus(),quality:{id:'low',shadowMap:512},state:{world:{regionId:'nordic',timeOfDay:.34},settings:{}}};ctx.env=createEnvironment(ctx);await ctx.env.init();contexts.push(ctx);}
function lights(scene){const a=[];scene.traverse(o=>{if(o.isLight)a.push({name:o.name,type:o.type,color:o.color.toArray(),intensity:o.intensity,position:o.position.toArray(),target:o.target?.position.toArray(),visible:o.visible});});return a;}
function snapshot(c){return {region:c.env.regionId,tod:c.env.timeOfDay,dayFactor:c.env.dayFactor,underground:c.env.undergroundId,fog:{color:c.scene.fog.color.toArray(),density:c.scene.fog.density},surface:lights(c.scene),section:lights(c.sectionScene),sunDirection:c.env.sunDirection.toArray()};}
const report={before:sha(before),after:sha(after),surfaceCases:0,unchangedSurfaceCases:0,changedNordicClearCases:0,undergroundCases:0};
try {
  for(const region of regions)for(const name of weather)for(const tod of [0,.34,.5,.7,.74,.8]){
    for(const c of contexts){c.env.setRegion(region);c.env.setWeather(name);c.env.setTimeOfDay(tod);}
    const [a,b]=contexts.map(snapshot);report.surfaceCases++;
    if(region==='nordic'&&name==='clear'){
      assert.notDeepEqual(b.fog,a.fog,'Candidate should affect Nordic clear fog');
      delete a.fog;delete b.fog;assert.deepEqual(b,a,'Fog authoring changed lights/sun/section');report.changedNordicClearCases++;
    }else {assert.deepEqual(b,a,`${region}/${name}/${tod} changed outside scope`);report.unchangedSurfaceCases++;}
  }
  for(const method of ['tunnel-jumbo','longhole','rockbolt','raise-boring'])for(const region of ['nordic','sahara'])for(const name of weather)for(const tod of [.34,.5,.7]){
    for(const c of contexts){c.env.setRegion(region);c.env.setWeather(name);c.env.setTimeOfDay(tod);c.env.setUnderground(method);}
    assert.deepEqual(snapshot(contexts[1]),snapshot(contexts[0]),`${method}/${region}/${name}/${tod} underground changed`);report.undergroundCases++;
  }
}finally {for(const c of contexts)c.env.dispose();}
writeFileSync(new URL('../evidence/nordic-fog/cpu-differential.json',import.meta.url),JSON.stringify(report,null,2));
console.log(JSON.stringify({passed:true,...report}));
