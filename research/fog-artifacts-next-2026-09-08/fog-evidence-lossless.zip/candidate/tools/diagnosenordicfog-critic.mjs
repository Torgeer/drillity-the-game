/** Read-only diagnosis of the rejected captures-02 pair; no visual acceptance. */
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { makeRandom } from '../src/core/contract.js';
import { assertCompleteCamera, assertRecordedEqual } from './checknordicfog-critic.mjs';

const root = fileURLToPath(new URL('../', import.meta.url));
const file = resolve(root, 'evidence/nordic-fog/captures-02/report.json');
const bytes = readFileSync(file), report = JSON.parse(bytes);
const sha = x => createHash('sha256').update(x).digest('hex');
assert.equal(report.valid, false);
assert.equal(report.cases.length, 2);
assert.equal(report.pairs.length, 1);
assert.equal(report.pairs[0].unexpected.length, 52);
assert.equal(report.sourceUnchanged, true);
assert.equal(report.inputsUnchanged, true);
assert.equal(report.cleanup.browserClosed, true);
assert.equal(report.cleanup.serverClosed, true);
const [a,b] = report.cases;
for (const row of [a,b]) {
  assert.equal(row.valid, true);
  assertRecordedEqual(row.before, row.after, 'within-capture record');
  assert.equal(sha(readFileSync(resolve(file, '..', row.png))), row.pngSha256);
  for (const band of ['surface','section']) {
    const camera = row.before.cameras[band];
    assertCompleteCamera({...camera,...camera.lens}, band);
    for (const observation of row.before.observations.filter(o=>o.band===band)) {
      assertRecordedEqual(observation.camera, camera, 'actual render camera');
    }
  }
}
for (const field of ['cameras','state','simulation','glass','clock','viewport','bands','bandsRect','chrome','quality','dpr','buffer']) {
  assertRecordedEqual(a.before[field], b.before[field], 'paired '+field);
}
const unexpected = report.pairs[0].unexpected;
const geometry = unexpected.filter(d=>/^\/scene\/geometries\/\d+\/attributes\/[^/]+\/array\/sha256$/.test(d.path));
const wind = unexpected.filter(d=>/^\/scene\/materials\/\d+\/uniforms\/uWind\/value\/\d$/.test(d.path));
const particleFog = unexpected.filter(d=>/^\/scene\/materials\/\d+\/uniforms\/uFog(Density|Target\/value\/\d)$/.test(d.path));
const timing = unexpected.filter(d=>/^\/assets\/slices\/(avgMs|count|maxMs)$/.test(d.path)
  || /^\/rig\/glb\/(fetchMs|parseMs)$/.test(d.path)
  || /^\/scene\/objects\/\d+\/userData\/spec\/glb\/(fetchMs|parseMs)$/.test(d.path));
assert.equal(geometry.length,32); assert.equal(wind.length,6);
assert.equal(particleFog.length,5); assert.equal(timing.length,9);
assert.equal(geometry.length+wind.length+particleFog.length+timing.length, unexpected.length);
const geometryIds = [...new Set(geometry.map(d=>Number(d.path.split('/')[3])))];
const owners = a.before.scene.objects.filter(o=>geometryIds.includes(o.geometry));
assert.deepEqual(owners.map(o=>o.name).sort(), ['vfx:sectionAdd','vfx:sectionSoft','vfx:surfaceAdd','vfx:surfaceSoft']);

// Exercise the actual public PRNG implementation and the retained-object
// semantics seen in createVFX. This proves the reset mechanism, not that a
// rendered retry has succeeded or every earlier consumer is identified.
const original = makeRandom(123), retained = original;
for(let i=0;i<97;i++) retained.f();
const reassigned = makeRandom(20260908);
assert.notDeepEqual(Array.from({length:6},()=>retained.f()), Array.from({length:6},()=>reassigned.f()));
Object.assign(original, makeRandom(20260908));
assert.equal(original,retained);
const expected = makeRandom(20260908);
const methods = [r=>r.f(),r=>r.range(-4,7),r=>r.int(3,20),r=>r.pick(['a','b','c']),r=>r.bool(.3),r=>r.gauss()];
for(const invoke of methods) assert.equal(invoke(retained),invoke(expected));
const qa = makeRandom(3), qaControl = makeRandom(3);
for(let i=0;i<53;i++) retained.f();
assert.equal(qa.f(),qaControl.f(),'separate QA stream survives VFX consumption');

const result = {
  reportSha256:sha(bytes), accepted:false, completeCameraAndPublicControlsExact:true,
  actualCameraErrors:report.pairs[0].cameraErrors,
  unexpectedCounts:{geometry:geometry.length,wind:wind.length,particleFog:particleFog.length,timing:timing.length},
  geometryOwners:owners.map(o=>({path:o.path,name:o.name,geometry:o.geometry})),
  retainedPrngMechanismTestPassed:true,
  diagnosis:'createVFX retains the original ctx.rand object. Replacing ctx.rand does not reseed it. Reseeding all six methods on the retained object preserves identity and can remain separate from QA contract randomness. A rendered retry must still prove geometry and wind equal.',
  limits:'The five particle-fog fields mirror actual surface FogExp2; any future allowance requires exact source-owned layer and solver checks. Nine timing fields are bookkeeping. Neither category licenses excluding geometry, wind, assets, or whole materials. No GPU process or visual acceptance.'
};
const out=resolve(root,'evidence/nordic-fog-critic');mkdirSync(out,{recursive:true});
writeFileSync(resolve(out,'captures-02-diagnosis.json'),JSON.stringify(result,null,2));
console.log(JSON.stringify(result,null,2));
