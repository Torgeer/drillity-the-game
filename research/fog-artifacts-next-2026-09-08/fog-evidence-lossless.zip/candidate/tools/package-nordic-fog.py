"""Lossless wind-down evidence package. Does not run tests or touch production."""
from pathlib import Path
import hashlib, json, shutil, zipfile

root=Path(__file__).resolve().parent.parent
threads=root.parent
baseline=threads/'drillity-coordination/resume-70-baseline-2026-09-08'
legacy=threads/'drillity-regional-fog/evidence/regional-fog/captures-01'
destination=threads/'drillity-fps-investigation/research/fog-artifacts-next-2026-09-08'
assert destination.resolve().is_relative_to((threads/'drillity-fps-investigation/research').resolve())
assert not destination.exists(), 'Refuse to replace an existing evidence package'
sha=lambda b:hashlib.sha256(b).hexdigest()
frozen={
    'tools/capture-nordic-fog.mjs':'01260a551670da8a094f6d1d1aa9b871005c19db43d89abcda8cf2e261e345da',
    'tools/nordic-fog-controls.mjs':'83250843f3ce04c400337139661d660be9c865c15c29bfea5133d771d610f4d3',
    'tools/nordic-fog-pair.mjs':'b1209b1f6d8b8210cfda46abc572b230b21e5a4494cde3ebedd0d96b38c99e46',
    'src/core/env.js':'3d218dd6d95fa79c1aad2b4872e910f577d214b0531ab8d2095f796f0bd6bcea',
}
for path,digest in frozen.items():assert sha((root/path).read_bytes())==digest,path
manifest=json.loads((baseline/'manifest.json').read_text(encoding='utf-8'))
entries={}
def add(path,source):
    assert path not in entries,path
    data=source.read_bytes();entries[path]={'source':str(source),'bytes':len(data),'sha256':sha(data),'data':data}
for entry in manifest['files']:
    path=baseline/entry['path'];assert path.resolve().is_relative_to(baseline.resolve())
    assert sha(path.read_bytes())==entry['sha256'],entry['path']
    add('baseline/'+entry['path'],path)
add('baseline/manifest.json',baseline/'manifest.json')
for directory in ['evidence/nordic-fog','evidence/nordic-fog-critic']:
    for path in sorted((root/directory).rglob('*')):
        if path.is_file():add('candidate/'+path.relative_to(root).as_posix(),path)
toolnames=['capture-nordic-fog.mjs','nordic-fog-controls.mjs','nordic-fog-pair.mjs','checknordicfog.mjs','measurenordicfog.mjs','checknordicfog-capture-controls.mjs','checknordicfog-pair.mjs','checknordicfog-critic.mjs','diagnosenordicfog-critic.mjs','prepare-nordic-fog.py','package-nordic-fog.py']
for name in toolnames:add('candidate/tools/'+name,root/'tools'/name)
for name in ['NORDIC_FOG_2026-09-08.md','NORDIC_FOG_CRITIC.md']:add('candidate/research/'+name,root/'research'/name)
add('candidate/src/core/env.js',root/'src/core/env.js')
for path in sorted(legacy.rglob('*')):
    if path.is_file():add('legacy-regional-fog/captures-01/'+path.relative_to(legacy).as_posix(),path)
destination.mkdir(parents=True)
archive=destination/'fog-evidence-lossless.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as bundle:
    for path,item in sorted(entries.items()):bundle.writestr(path,item['data'])
# Re-open and compare every decoded member byte-for-byte to its original.
with zipfile.ZipFile(archive) as bundle:
    assert set(bundle.namelist())==set(entries)
    for path,item in entries.items():assert bundle.read(path)==item['data'],path
for path in frozen:
    if path.startswith('tools/'):
        out=destination/'frozen'/Path(path).name;out.parent.mkdir(exist_ok=True);shutil.copyfile(root/path,out)
shutil.copyfile(root/'evidence/nordic-fog/nordic-fog-delta.patch',destination/'nordic-fog-delta.patch')
shutil.copyfile(root/'research/NORDIC_FOG_CRITIC.md',destination/'NORDIC_FOG_CRITIC.md')
shutil.copyfile(root/'evidence/nordic-fog-critic/negative-controls.json',destination/'critic-58-negative-controls.json')
shutil.copyfile(root/'research/NORDIC_FOG_2026-09-08.md',destination/'NORDIC_FOG_2026-09-08.md')
shutil.copyfile(root/'evidence/nordic-fog/ARCHIVE_README.md',destination/'README.md')
record={'status':'UNACCEPTED — no accepted matched source pair','baselineParent':manifest['parentCommit'],'baselineFiles':len(manifest['files']),'candidateProductionDelta':'Six additions to src/core/env.js only','frozenSha256':frozen,'archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'members':len(entries),'decodedBytes':sum(i['bytes'] for i in entries.values()),'everyMemberVerifiedByteForByte':True},'files':[{k:v for k,v in dict(path=path,**item).items() if k!='data'} for path,item in sorted(entries.items())]}
(destination/'archive-manifest.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps({'destination':str(destination),**record['archive']}))
