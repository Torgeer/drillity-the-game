/** Classify preserved failures without changing their rejected status. CPU only. */
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {classifyPair} from './nordic-fog-pair.mjs';
import {makeRandom} from '../src/core/contract.js';
const root=new URL('../',import.meta.url),raw=readFileSync(new URL('evidence/nordic-fog/captures-02/report.json',root)),source=JSON.parse(raw);
assert.equal(source.valid,false);const [a,b]=source.cases.map(r=>r.before),diagnosis=classifyPair(a,b,'nordic');
assert.equal(diagnosis.valid,false);assert.equal(diagnosis.unexpected.length,38);
const geometry=diagnosis.unexpected.filter(d=>/^\/scene\/geometries\/\d+\/attributes\/i/.test(d.path));const wind=diagnosis.unexpected.filter(d=>/\/uniforms\/uWind\//.test(d.path));assert.equal(geometry.length,32);assert.equal(wind.length,6);
const telemetry=diagnosis.allowed.filter(d=>d.reason.includes('telemetry'));assert.equal(telemetry.length,9);
const retained=makeRandom(11),capturedReference=retained;retained.f();retained.gauss();Object.assign(retained,makeRandom(20260908));assert.equal(retained,capturedReference);
const reference=makeRandom(20260908),contract=makeRandom(3),contractReference=makeRandom(3);
for(const [method,args] of [['f',[]],['range',[-3,4]],['int',[1,8]],['pick',[[1,4,7]]],['bool',[.3]],['gauss',[]]])assert.deepEqual(capturedReference[method](...args),reference[method](...args));
assert.equal(contract.f(),contractReference.f());capturedReference.f();capturedReference.gauss();assert.equal(contract.f(),contractReference.f());
const same=structuredClone(a);assert.equal(classifyPair(a,same,'nordic').unexpected.length,0);
const mutations=[s=>s.scene.materials[42].uniforms.uWind.value[0]+=.1,s=>s.scene.geometries[106].attributes.iPos.array.sha256='changed',s=>s.rig.glb.prims++,s=>s.state.tSec++,s=>s.scene.materials[42].props.transparent=!s.scene.materials[42].props.transparent];let rejected=0;
for(const mutate of mutations){const changed=structuredClone(a);mutate(changed);assert(classifyPair(a,changed,'nordic').unexpected.length>0);rejected++;}
for(const mutate of [s=>s.scene.materials[43].uniforms.uFogTarget.value[0]=.01,s=>s.scene.materials[42].uniforms.uFogDensity=.1]){const changed=structuredClone(a);mutate(changed);assert.throws(()=>classifyPair(a,changed,'nordic'));rejected++;}
for(const invalid of [undefined,'10',NaN,-1,.5]){const changed=structuredClone(a);changed.assets.slices.count=invalid;assert.throws(()=>classifyPair(a,changed,'nordic'));rejected++;}
{const changed=structuredClone(a);changed.scene.objects.push(structuredClone(changed.scene.objects.find(o=>o.name==='vfx:surfaceSoft')));assert.throws(()=>classifyPair(a,changed,'nordic'));rejected++;}
const report={passed:true,preservedReportSha256:createHash('sha256').update(raw).digest('hex'),preservedReportStillRejected:source.valid===false,classification:{geometry:geometry.length,wind:wind.length,explicitTelemetry:telemetry.length,fogDrivenUniforms:source.pairs[0].unexpected.filter(d=>/\/uniforms\/uFog/.test(d.path)).length},unexpected:diagnosis.unexpected,declaredTelemetryPaths:diagnosis.declaredTelemetryPaths,randomStreams:{retainedObject:true,allSixMethodsReset:true,contractStreamIndependent:true},negativeControls:rejected};writeFileSync(new URL('evidence/nordic-fog/captures-02-classification.json',root),JSON.stringify(report,null,2));console.log(JSON.stringify({...report,unexpected:undefined}));
