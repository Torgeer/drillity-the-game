/** CPU probe of the real environment solver. No sky render or visual claim. */
import * as THREE from 'three';
import { createBus } from '../src/core/contract.js';
import { readFileSync, mkdirSync, writeFileSync, existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve } from 'node:path';
const out = resolve(process.argv[2] || 'evidence/nordic-fog/baseline.json');
if (existsSync(out)) throw Error('Refusing to overwrite '+out);
const envURL=new URL('../src/core/env.js',import.meta.url);
const source=readFileSync(process.argv.includes('--baseline')?new URL('../evidence/nordic-fog/env-before.js',import.meta.url):envURL);
const text=source.toString().replace(/from (['"])([^'"]+)\1/g,(_m,q,p)=>`from ${q}${p.startsWith('.')?new URL(p,envURL).href:import.meta.resolve(p)}${q}`);
const {createEnvironment}=await import('data:text/javascript;base64,'+Buffer.from(text).toString('base64'));
const sha=b=>createHash('sha256').update(b).digest('hex');
const report={envSha256:sha(source),semantics:'Actual public environment solver with no WebGL renderer. FogExp2 attenuation is computed from its published density; this cannot predict the complete graded framebuffer.',cases:[]};
const ctx={scene:new THREE.Scene(),sectionScene:new THREE.Scene(),bus:createBus(),
  quality:{id:'low',shadowMap:512}, state:{world:{regionId:'nordic',timeOfDay:.34},settings:{}}};
const env=createEnvironment(ctx);
const times=[['morning',.34],['noon',.5],['dusk',.70],['late-dusk',.74],['night',.8]];
try {
  await env.init();
  for(const region of ['nordic','sahara'])for(const weather of ['clear','overcast','rain','snow','fog'])for(const [label,tod] of times){
    env.setRegion(region);env.setWeather(weather);env.setTimeOfDay(tod);
    const density=ctx.scene.fog.density;
    const elevation=Math.asin(env.sunDirection.y)*180/Math.PI;
    const t=Math.max(0,Math.min(1,(elevation-3)/(22-3))),golden=1-t*t*(3-2*t);
    report.cases.push({region,weather,label,tod,elevation,dayFactor:env.dayFactor,golden,
      fog:{linear:env.fogColor.toArray(),srgb:'#'+env.fogColor.getHexString(),density},
      sun:{linear:env.sunColor.toArray(),intensity:env.sun.intensity},
      atDistance:[25,100,187.03,250,328.36,351.95,450].map(m=>({m,fogFraction:1-Math.exp(-((density*m)**2))}))});
  }
} finally { env.dispose(); }
mkdirSync(resolve(out,'..'),{recursive:true});writeFileSync(out,JSON.stringify(report,null,2));
console.log(JSON.stringify({out,envSha256:report.envSha256,cases:report.cases.filter(c=>c.weather==='clear')}));
