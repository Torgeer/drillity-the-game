# Independent core tender compatibility review — 2026-09-08

Approved for the bounded core nominal-size/accepted-job change on the exact source hashes below. This is not full game, browser/mobile, or sonic physical-fit approval.

Candidate: `C:/Users/henri/Downloads/threads/drillity-next-sampling-fit`.
Read-only comparator: `C:/Users/henri/Downloads/threads/drillity-coordination/resume-70-baseline-2026-09-08`.
Reviewer: `/root/save_field_critic`, independent of the production author. Reviewer changed only this test/evidence; no production, MAIN, GPU, commits or asset writes.

## Verified behavior

- Twenty-one new independent adversarial groups pass. The generated sequence comparison covers 110 core offers and 754 non-core offers. Every non-core offer is identical to the frozen comparator and both RNG streams remain aligned. Core workload, difficulty, geology, identity, deadlines and reputation reward remain identical; the nominal diameter and its existing formula-derived payout/bonuses/description may change intentionally.
- Genuine level 18/core and level 42/sonic fixtures gain levels through public XP and buy rigs, tools and certificates through the public APIs, then fit, preview, accept and start an unedited generated offer. Funding is explicit fixture cash; this does not prove an unaided career can afford the unlock. Tested core offer: 68.2 m target, 75.7 mm nominal bore. Tested sonic offer: 12.7 m target, 147 mm existing tender label; its successful role-based start is **not dimensional certification**.
- The public contract board/cache route also accepts core at level 18. Later mutable card changes and refreshes cannot change the accepted snapshot. Same-ID copied proposals may invoke the existing restart behavior, but only on the exact private accepted terms; this is not a no-restart guarantee.
- Wrong/missing/non-finite/string/rounded core diameters refuse before accounting, events or attempt allocation. Method-string, method-row, rig, site and unlocked fallback startup routes receive the same resolved-method guard. A core-diameter value and a nominal bore are not interchangeable.
- Legacy fixtures are produced by the frozen baseline's actual progression acceptance and save APIs. Their mismatched accepted diameter, prices, bonus, workload and other contract fields remain unchanged on load and repeated save/load. Restarts issue fresh attempt identities without a second mobilisation charge.
- Separately labelled synthetic v4/v5 migration fixtures follow the committed historical schema: accepted contract/run existed before run IDs. Both preserve one previously completed hole, accumulated revenue/costs and mobilisation, receive fresh identities, survive a second modern save/load, and finish the one remaining hole through real drilling. These are not captured historical player files. Missing/empty old accumulators do not gain this exception.
- Actual public drilling completes a legacy two-hole boundary job with authentic sample products; completion replay does not pay again, and the old exception ends on settlement/abandonment. Modern and legacy New Career actions clear the private accepted terms before save/reload. The short boundary job is not a realistic generated tender or economy balance sample.
- Legacy protection never blesses a mismatched component family or incompatible mid-hole bit. Public flags, unrelated proposals, missing prior accepted identities, and modern saves without a valid persisted legacy exception cannot request an exemption. These are local API/state integrity checks, not cryptographic protection against hand-edited save files.

## Problems found and repaired

1. The first implementation trusted the mutable public `run.contract` reference. Replacing it and `state.contract` with a same-ID, same-gauge contract could alter workload/payout. Production now keeps a private accepted core reference and makes the public run's contract reference non-writable. Start/attempt allocation reject replaced presentation state.
2. After that fix, `serialise()` still persisted the replaceable `state.contract`; save/reload could turn altered terms into a newly authoritative accepted snapshot. Production now serialises the private accepted core snapshot. The independent reproduction passes after the repair.
3. The author's final review raised the historical v4/v5 format. Independent reproduction confirmed that requiring prior run identity stranded those valid pre-identity accepted jobs. Production now captures original save version internally before migration and recognises only the documented v4/v5 accumulator shape. Modern missing identities remain refused. `migration-before-fix.log` retains the failed reproduction.

The author also closed the resolved-method startup fallback and reset cleanup gaps; independent cases verify both. Earlier broad gameplay run passed all 20 behavior cases but exited 1 because production changed during it (`sourceStable:false`). It is retained as `gameplay-regression.log`, not cited as a pass. The final rerun is stable and exits 0. Early overly strict assertions about canonical restart semantics and a corrupt-save adapter were corrected explicitly; no acceptance or financial assertions were removed.

## Physical evidence and limits

Local primary reference: `C:/Users/henri/Downloads/Diamond Driller's Technical Book.pdf`, PDF page 35, printed page 69, NWL/NWL-U diamond-coring row: core diameter 47.6 mm, hole diameter 75.7 mm. The same spread's printed page 68 gives a separate NWL reaming-shell outside-diameter tolerance of 75.57–75.82 mm. The reviewer re-inspected the rendered spread at `C:/Users/henri/Downloads/threads/drillity-sample-loadouts/evidence/sample-loadout-critic/diamond-pdf35.png`.

The constant is a **nominal system bore**. Comparing that catalogue size to a tender is not a measured cutting-crown outside diameter, a manufacturing-tolerance check or proof of arbitrary component clearance. The final new comments and refusal copy make this distinction. Existing family/core-size metadata still rejects HQ crown with HQ3 barrel despite their equal nominal bore.

Sonic nominal 100/150 mm equipment clearance and usable internal barrel capacity remain **NOT SOURCED**. The 3 m sonic sampling stop remains an authored gameplay run limit. No sonic dimensions or physical-fit acceptance claim were added. Material recovery, TCR/RQD, operation-driven sample quality, browser layout and sustained physical-phone acceptance remain outside this review.

## Reproduction and final results

From the candidate directory:

```text
node tools/checksampletender-adversarial.mjs --baseline ../drillity-coordination/resume-70-baseline-2026-09-08
node tools/checksampleloadouts-adversarial.mjs --baseline ../drillity-coordination/resume-70-baseline-2026-09-08 --catalogue --start
node tools/checksamplegameplay-adversarial.mjs
```

Final logs: `final-tender.log` — 21/21, `sourceStable:true`, exit 0; `final-loadout.log` — 27/27, exit 0; `final-gameplay.log` — 20/20, `sourceStable:true`, exit 0. These are 68 bounded groups, not 68 product acceptance criteria. `results.json` carries detailed new test results, source hashes and limits. `run-02.log` and `run-03.log` retain the earlier failures; `run-04.log` precedes the final added reset and historical migration cases.

## Exact frozen SHA-256

| File | SHA-256 |
| --- | --- |
| `src/game/data.js` | `917a9537359d77c50ac8ea5c71e21065d576380b076e6e0d2328ffed4f5a03b8` |
| `src/game/equipment-support.js` | `c0a7639cf3507e66cc13125345ce5f059d0043a9848a1ef7d6a237a426591bb7` |
| `src/game/progression.js` | `a19167b655339e2e9e0bcca70aecc2a631c809f5a907b0904f8cd5cec54b4c1c` |
| `src/sim/drilling.js` | `3cdc6d6810e01374ce5d914f4c80061d2d08e399a9d9ca471ed40819346fa81e` |
| `tools/checksampletender-adversarial.mjs` | `8476e1041a85dd58fbbb7619441c5766e9b6597a1076847e4d905d92e091920e` |
| `tools/checksamplegameplay-adversarial.mjs` | `ec9e4158f7b7b96f85711488332fad44ed6b30d71e01135ebe0a2560a9c1467d` |
| `tools/checksampleloadouts-adversarial.mjs` | `e22d61e18f3695bf6b778f9df2cbad5e5d1713e8308e76060c7d80b0f7f15ba4` |
