# Accepted recording; shimmer cost remains unresolved

Capture 02 passes the recording-integrity gates. It does **not** establish a useful isolated heat-shimmer saving, explain the historical poor FPS, justify a production graphics change or certify phone performance. The order of the added render submissions dominates the result.

| Comparison | Pairs | Mean on minus off | Median on minus off |
|---|---:|---:|---:|
| On then off | 12 | -14.955520 ms | -17.115648 ms |
| Off then on | 12 | +15.838037 ms | +21.880832 ms |
| All retained pairs | 24 | +0.441259 ms | +1.820672 ms |

The second submission is slower in 19 of 24 pairs. Its second-minus-first median is **20.859392 ms**, mean **15.396779 ms**. The direction follows submission position much more strongly than whether shimmer is drawn. The pooled +0.441 ms is descriptive, not an isolated feature-cost estimate. All pairs remain in the analysis, including the first pair and negative differences. No independence-based confidence interval or selected-sample FPS claim is made.

Each pair follows an original live render and adds two complete `renderer.render(0)` submissions. No simulation update occurs between the pair members. The actual accepted oil contract, supported gear, active drilling state, cameras, exact geometry-buffer bytes, materials, shader uniforms, particle population and adaptive load match under the reviewed protocol. The target is the uniquely identified `vfx:heatShimmer`; all on members observe its render hook once, off members zero times, with zero framebuffer-copy calls. Its recorded strength is 1.05 in all pairs. This is the non-refractive quad path only.

Raw material versions remain present. The capture records 96 direct-draw side witnesses, and accepts only the source-proven +1/+2 transparent DoubleSide bookkeeping within a member. Between consecutive members, the complete identity is literally unchanged. Composer target allocations remain stable; the actual ping-pong role changes are explicitly retained outside the identity comparison. These application-level checks do not prove equal GPU cache, queue, driver or allocation-state cost. The mechanism behind the large second-submission delay is unisolated.

The canonical live interval contains **2,744 frames**, seven natural rod-add/resumption cycles and reaches 190.106 m by the final frame. The 24 diagnostic pairs span depths 0–147.95 m; later frames remain in the live record. All 48 diagnostic queries and 458 normal-render queries completed and were deleted, with zero pending, discarded, disjoint or query errors. All 449 captured input entries match before and after. There are 1,409 retained immutable buffer digests. None of these counts makes the additional-render timing equivalent to normal gameplay FPS.

CDP V2 preserves all **60,290 samples**, including 11 negative deltas, and records 22 moved sample indices. Every cumulative timestamp remains within the original bounds. The trace has 116,607 events. The CPU profile includes setup/drain/serialization outside the 45.0101-second live mark interval; no absolute CPU-profile/Perfetto clock map or CPU-per-phase attribution is asserted. Actual browser: Chrome 152.0.7977.76, revision `0d89dfa2dd7c1ec4b8a14b9f303f887bb63b6174`, V8 15.2.124.19; renderer reports ANGLE Direct3D11 on an NVIDIA RTX 4070 Laptop GPU.

Run wall time: 14:03:22.471–14:05:16.619 UTC. Recorded `performance.timeOrigin` plus live start/end gives **14:03:53.291–14:04:38.301 UTC**. A late-reported 1.5235744-second external conditions test produced its completed report at 14:03:21.803 UTC, 31.488 seconds before the live window. Its source creates that timestamp after the test and source-hash checks, with only writing/logging afterward. The report is preserved as `external-test-timing.json`. This bounds that test work before the live interval; exact OS process-exit time was not recorded, and coordinated quiet is not a measurement of every machine process.

The run records 32 warnings: two existing missing-`FLUSH_MEDIUM` warnings for oil-rotary, including the explicitly wrong air-collar-plume fallback, and texture-serialization warnings. They were not suppressed or repaired by this diagnostic.

Raw report SHA-256: `f4f03965785453a1c79db3b11b8f7d1018cd9876fc85129d0c564cffa123fc46`. Full artifact hashes, query accounting, exact pair rows and cleanup proof are in `capture-status.json` and `paired-analysis.json`. The browser/server closed, port 5209 was independently verified closed and the lease released to idle. No further GPU run was performed.

The next bounded performance task should first remove the two-extra-submission protocol as a confound: use one original render per animation frame, record actual masks, include same-mask sham controls, counterbalance order and prove comparable camera/state/workload. A held representative live state may support a render-only experiment if its frozen scope is explicit; a changing live trajectory needs its own matching and adaptive-feedback evidence. Diagnose the position effect before attributing a pooled timing difference to shimmer. No new harness or production fix is included here.
