#!/usr/bin/env node
/** Independent identity/column boundary tests; no GPU or earned-career claims.
 * All malicious edits are explicit negative fixtures, never player progress.
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import {createGameState,createBus,makeRandom,EVENTS,GROUND} from '../src/core/contract.js';
import {createProgression} from '../src/game/progression.js';
import {createGeology} from '../src/world/geology.js';
const out=process.argv[2]||'research/ordinary-soil-independent.json';
const keys=['document','localStorage'];const originals=keys.map(k=>Object.getOwnPropertyDescriptor(globalThis,k));
const hash=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const sources=['src/world/geology.js','src/game/economy.js','src/game/data.js','src/game/progression.js'];
const manifest=()=>Object.fromEntries(sources.map(p=>[p,hash(p)]));
const report={started:new Date().toISOString(),sourceBefore:manifest(),scope:'Actual lifecycle/API identity tests with synthetic malformed/unaccepted inputs; no GPU or career affordability claim.',cases:[],errors:[]};
globalThis.document={createElement(tag){assert.equal(tag,'canvas');const canvas={width:1,height:1};canvas.getContext=kind=>{
  assert.equal(kind,'2d');return new Proxy({canvas,font:'12px sans-serif',measureText:s=>({width:String(s).length*7}),
    createLinearGradient:()=>({addColorStop(){}}),createRadialGradient:()=>({addColorStop(){}}),
    getImageData:()=>({data:new Uint8ClampedArray(canvas.width*canvas.height*4)})},{get:(o,k)=>k in o?o[k]:(()=>{})});};return canvas;}};
const argsFor=c=>({regionId:c.regionId,applicationId:c.applicationId,targetDepth:c.targetDepth,seed:c.seed,
  difficulty:c.difficulty,holeDiaMm:c.holeDia,methodId:c.methodId,profileMode:c.profileMode,
  commodity:c.commodity??c.target??null,oreConfidence:c.oreConfidence??c.targetConfidence,acceptedContract:c});
async function fixture(){
  const map=new Map();globalThis.localStorage={getItem:k=>map.get(k)??null,setItem:(k,v)=>map.set(k,String(v)),removeItem:k=>map.delete(k)};
  const state=createGameState(),bus=createBus(),ctx={state,bus,rand:makeRandom(907)};
  const p=ctx.progression=createProgression(ctx);await p.init();
  const geo=ctx.geology=createGeology(ctx);await geo.init();
  const board=p.getContracts();return {state,bus,p,geo,board,map,close(){geo.dispose();p.dispose();}};
}
function physical(geo,target){
  const samples=[];for(let i=0;i<=20;i++){const g=geo.getDrillabilityAt(target*i/20);samples.push({id:g.id,ucs:g.ucs,boulder:g.boulder,cavity:g.cavity,fracture:g.fracture});}
  return {strata:geo.strata,samples};
}
async function legacyEquals(geo,args){
  const baseline=createGeology({state:createGameState(),bus:createBus()});
  try{await baseline.init();baseline.generateProfile({...args,acceptedContract:undefined});assert.deepEqual(physical(geo,args.targetDepth),physical(baseline,args.targetDepth));}
  finally{baseline.dispose();}
}
function conforms(geo,c){
  let samples=0;
  for(const bed of c.groundSpec){
    for(let d=bed.top+1e-6;d<bed.bottom-1e-6;d+=.05){
      const g=geo.getDrillabilityAt(d);assert.equal(g.id,bed.id,`wrong physical material at${d}`);assert.equal(g.ucs,GROUND[bed.id].ucs);
      assert.equal(g.boulder,null);assert.equal(g.cavity,null);samples++;
    }
    const g=geo.getDrillabilityAt(bed.bottom-1e-7);assert.equal(g.id,bed.id,'tail feature crosses back into mission');
  }
  assert.ok(samples>0);return samples;
}
async function test(name,fn){const f=await fixture();try{await fn(f);report.cases.push({name,passed:true});}catch(e){report.cases.push({name,passed:false,error:e.message});report.errors.push({name,message:e.message,stack:e.stack});}finally{f.close();}}
try{
  await test('All five actual initial ordinary offers preserve their accepted soil column and physical sampling',async f=>{
    for(const c of f.board){assert.equal(f.p.acceptContract(c).ok,true);assert.equal(f.state.contract,f.p.run.contract);conforms(f.geo,c);assert.equal(f.p.abandonContract().ok,true);}
  });
  await test('Valid regeneration is stable and private accepted soil survives caller mutation',async f=>{
    const c=f.board[1],saved=structuredClone(c);assert.equal(f.p.acceptContract(c).ok,true);const expected=physical(f.geo,c.targetDepth);
    c.groundSpec[0].id='granite';c.groundSpec[1].top=77;
    f.geo.generateProfile(argsFor(c));assert.deepEqual(physical(f.geo,c.targetDepth),expected);conforms(f.geo,saved);
  });
  await test('Each changed physical-context field rejects cached authority',async f=>{
    const c=f.board[1];assert.equal(f.p.acceptContract(c).ok,true);
    for(const [key,value] of Object.entries({seed:c.seed+1,targetDepth:c.targetDepth+1,holeDiaMm:c.holeDia+1,
      regionId:'sahara',applicationId:'water-well',methodId:'core',profileMode:'profile',difficulty:5,
      commodity:'gold',oreConfidence:.99})){
      const args={...argsFor(c),[key]:value};f.geo.generateProfile(args);await legacyEquals(f.geo,args);
    }
  });
  await test('Detached acceptedContract clone cannot authorize soil even when fields match',async f=>{
    const c=f.board[1];assert.equal(f.p.acceptContract(c).ok,true);const args={...argsFor(c),acceptedContract:structuredClone(c)};
    f.geo.generateProfile(args);await legacyEquals(f.geo,args);
  });
  await test('Abandoned prior work cannot regenerate an authorized soil column',async f=>{
    const c=f.board[1];assert.equal(f.p.acceptContract(c).ok,true);assert.equal(f.p.abandonContract().ok,true);
    const args=argsFor(c);f.geo.generateProfile(args);await legacyEquals(f.geo,args);
  });
  await test('Another active run cannot lend authority to the previous contract',async f=>{
    const old=f.board[1];assert.equal(f.p.acceptContract(old).ok,true);f.p.abandonContract();assert.equal(f.p.acceptContract(f.board[2]).ok,true);
    const args=argsFor(old);f.geo.generateProfile(args);await legacyEquals(f.geo,args);
  });
  await test('A detached spoofed event is not progression acceptance',async f=>{
    const c=structuredClone(f.board[1]);f.bus.emit(EVENTS.CONTRACT_ACCEPT,{contract:c});
    assert.equal(f.state.contract,null);assert.equal(f.p.run,null);await legacyEquals(f.geo,argsFor(c));
  });
  const malformed={gap:c=>c.groundSpec[1].top+=.1,overlap:c=>c.groundSpec[1].top-=.1,
    nan:c=>c.groundSpec[0].bottom=NaN,string:c=>c.groundSpec[0].top='0',
    unknown:c=>c.groundSpec[0].id='not-ground',rock:c=>c.groundSpec[0].id='granite',
    incomplete:c=>c.groundSpec.at(-1).bottom-=.1,overdepth:c=>c.groundSpec.at(-1).bottom+=.1,
    zero:c=>c.groundSpec[0].bottom=c.groundSpec[0].top,reverse:c=>c.groundSpec.reverse(),
    empty:c=>c.groundSpec=[],missing:c=>delete c.groundSpec};
  for(const [name,mutate] of Object.entries(malformed))await test(`Malformed ordinary column ${name} cannot override regional physics`,async f=>{
    const c=structuredClone(f.board[1]);mutate(c);assert.equal(f.p.acceptContract(c).ok,true,'ordinary preview is separate from soil validation');
    await legacyEquals(f.geo,argsFor(c));
  });
  await test('Reloaded accepted identity can recapture the same soil without a charge',async f=>{
    const c=f.board[1];assert.equal(f.p.acceptContract(c).ok,true);const expected=physical(f.geo,c.targetDepth),money=f.state.player.money;
    f.p.save();assert.equal(f.p.load(),true);assert.notEqual(f.state.contract,c);assert.equal(f.state.contract,f.p.run.contract);
    f.bus.emit(EVENTS.CONTRACT_ACCEPT,{contract:f.state.contract});assert.deepEqual(physical(f.geo,c.targetDepth),expected);assert.equal(f.state.player.money,money);
  });
}catch(e){report.errors.push({message:e.message,stack:e.stack});}
finally{
  report.sourceAfter=manifest();report.sourceUnchanged=JSON.stringify(report.sourceBefore)===JSON.stringify(report.sourceAfter);
  if(!report.sourceUnchanged)report.errors.push({message:'Source changed during test'});
  keys.forEach((k,i)=>{if(originals[i])Object.defineProperty(globalThis,k,originals[i]);else delete globalThis[k];});
  report.finished=new Date().toISOString();report.passed=report.errors.length===0;
  fs.writeFileSync(out,JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({passed:report.passed,cases:report.cases.length,errors:report.errors,out}));
  if(!report.passed)process.exitCode=1;
}
