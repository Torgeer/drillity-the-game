#!/usr/bin/env node
/** Independent bounded career probe. No injected XP/cash/completion records.
 * Uses actual public progression, simulation update/input/actions and actual
 * geology profile/sampling/crossing updates. No renderer or human session.
 * A stalled controller is an observation, never proof a player cannot finish.
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { createGameState, createBus, makeRandom, EVENTS } from '../src/core/contract.js';
import { createProgression } from '../src/game/progression.js';
import { createDrillSim } from '../src/sim/drilling.js';
import { createGeology } from '../src/world/geology.js';
import { getItem, getRig, defaultLoadoutFor } from '../src/game/data.js';

const root = fileURLToPath(new URL('..', import.meta.url));
const args = process.argv.slice(2);
const opts = { seed: 907, card: 0, seconds: 900, out: 'research/career-journey-independent-907-0.json' };
for (let i=0;i<args.length;i+=2) {
  const key=args[i].replace(/^--/,'');
  assert.ok(Object.hasOwn(opts,key)&&args[i+1],`Unknown/missing argument ${args[i]}`);
  opts[key]=key==='out'?args[i+1]:Number(args[i+1]);
}
for(const key of ['seed','card','seconds']) assert.ok(Number.isFinite(opts[key])&&opts[key]>=0,key);
const hash=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
function manifest(dir=path.join(root,'src'), acc={}) {
  for(const ent of fs.readdirSync(dir,{withFileTypes:true})) {
    const name=path.join(dir,ent.name);
    if(ent.isDirectory())manifest(name,acc);
    else if(/\.(js|css)$/.test(ent.name))acc[path.relative(root,name).replaceAll('\\','/')]=hash(name);
  }
  return acc;
}
const report={started:new Date().toISOString(),options:opts,sourceBefore:manifest(),
  scope:'Actual fresh money/XP; real progression/geology/sim init and fixed-delta public sim/geology updates including crossing events. Canvas drawing sink only, no renderer/GPU. Telemetry-optimal scripted control is not human play or complete game acceptance.',
  fixtures:['In-memory localStorage, initial empty slot','Seeded initial board RNG','1/60 second update cadence','900 second default per-hole controller bound'],
  injectedMoney:0,injectedXP:0,injectedCompletionPayloads:0,checks:[],holes:[],events:[],errors:[]};
const original=Object.getOwnPropertyDescriptor(globalThis,'localStorage');
const originalDocument=Object.getOwnPropertyDescriptor(globalThis,'document');
Object.defineProperty(globalThis,'document',{configurable:true,value:{createElement(tag){
  assert.equal(tag,'canvas','Unexpected DOM creation');
  const canvas={width:1,height:1};
  canvas.getContext=kind=>{
    assert.equal(kind,'2d','GPU contexts are prohibited');
    return new Proxy({canvas,font:'12px sans-serif',measureText:text=>({width:String(text).length*7}),
      createLinearGradient:()=>({addColorStop(){}}),createRadialGradient:()=>({addColorStop(){}}),
      getImageData:()=>({data:new Uint8ClampedArray(canvas.width*canvas.height*4)})},
      {get:(object,key)=>key in object?object[key]:(()=>{})});
  };return canvas;
}}});
const store=new Map();
Object.defineProperty(globalThis,'localStorage',{configurable:true,value:{getItem:k=>store.get(k)??null,setItem:(k,v)=>store.set(k,String(v)),removeItem:k=>store.delete(k)}});
let p,sim,geo;
function recordCheck(label,fn){fn();report.checks.push(label);}
const snapshot=state=>({money:state.player.money,xp:state.player.xp,level:state.player.level,
  stats:structuredClone(state.player.stats),condition:structuredClone(state.garage.condition),
  owned:[...state.garage.owned],rigId:state.garage.rigId,loadout:structuredClone(state.garage.loadout),
  contractId:state.contract?.id??null});
try {
  const state=createGameState(),bus=createBus();
  p=createProgression({state,bus,rand:makeRandom(opts.seed)});await p.init();
  report.initial=snapshot(state);
  recordCheck('Factory fresh career is untouched',()=>{assert.equal(state.player.money,4500);assert.equal(state.player.xp,0);assert.equal(state.player.level,1);assert.equal(state.player.stats.holesDone,0);});
  const completions=[],moneyEvents=[],xpEvents=[];let jamEvents=0;
  bus.on(EVENTS.MONEY_CHANGE,e=>{moneyEvents.push(structuredClone(e));});
  bus.on(EVENTS.XP_GAIN,e=>xpEvents.push(structuredClone(e)));
  bus.on(EVENTS.JAM_CLEARED,()=>jamEvents++);
  bus.on(EVENTS.HOLE_COMPLETE,e=>completions.push(e));
  const ctx={state,bus,progression:p};
  geo=ctx.geology=createGeology(ctx);await geo.init();
  sim=ctx.sim=createDrillSim(ctx);sim.init();
  const board=p.getContracts();
  const beforePreview=JSON.stringify(p.serialise());
  report.board=board.map(c=>({id:c.id,title:c.title,methodId:c.methodId,targetDepth:c.targetDepth,holes:c.holes,payout:c.payout,requiredCerts:c.requiredCerts,preview:p.previewContract(c)}));
  recordCheck('Initial board previews are pure',()=>assert.equal(JSON.stringify(p.serialise()),beforePreview));
  const card=board[opts.card];assert.ok(card,'Selected initial card exists');
  report.contract=structuredClone(card);report.accept=p.acceptContract(card);
  if(report.accept.ok) {
    report.geology=geo.strata.filter(s=>s.top<card.targetDepth).map(s=>({id:s.id,top:s.top,bottom:s.bottom,ucs:s.ucs}));
    for(let h=0;h<card.holes;h++) {
      const before=snapshot(state),count=completions.length;
      const started=sim.startHole(state.contract);assert.equal(started.active,true);
      let frames=0;const phases=new Set(),warnings=new Set();
      while(sim.active&&frames<opts.seconds*60) {
        const t=sim.getTelemetry();phases.add(t.phase);if(t.warning?.kind)warnings.add(t.warning.kind);
        let feed=t.optimal.wob,rotation=t.optimal.rpm,flush=t.optimal.flush;
        if(t.warning?.kind==='boulder'){feed=Math.min(feed,.15);rotation=1;flush=1;}
        if(t.load>.65){feed=Math.min(feed,.15);flush=1;}
        if(t.heat>.8){feed=Math.min(feed,.1);rotation=Math.min(rotation,.3);flush=1;}
        if(t.jam.state!=='free'){feed=0;rotation=.25;flush=1;if(t.jam.rescue.goodNow)sim.pulse('jamRescue');}
        sim.setInput('feed',feed);sim.setInput('rotation',rotation);sim.setInput('flush',flush);
        if(t.rodAdd&&!t.rodAdd.hit&&!t.rodAdd.missed&&t.rodAdd.t>=t.rodAdd.windowStart&&t.rodAdd.t<=t.rodAdd.windowEnd)sim.pulse('rodStab');
        sim.update(1/60);geo.update(1/60,state);p.update(1/60);frames++;
      }
      const t=sim.getTelemetry(),after=snapshot(state);
      report.holes.push({number:h+1,frames,phase:t.phase,reason:t.reason,depth:t.depth,target:t.target,timeSec:t.timeSec,
        before,after,phases:[...phases],warnings:[...warnings],jam:t.jam,warning:t.warning,
        terminalGround:t.stratum,terminalROP:t.rop,terminalOptimal:t.optimal,
        settlement:p.serialise().career?.ledger?.[0]??state.player.career?.ledger?.[0]??null});
      recordCheck('Money reconciles to each actual money event',()=>assert.equal(state.player.money,4500+moneyEvents.reduce((n,e)=>n+e.delta,0)));
      recordCheck('Jam career counter has one write per emitted clearance',()=>assert.equal(state.player.stats.jamsCleared,jamEvents));
      if(completions.length!==count+1){report.observation='Bounded control did not complete this hole; no impossibility claim.';break;}
      recordCheck('One actual completion creates exactly one hole statistic',()=>assert.equal(after.stats.holesDone,before.stats.holesDone+1));
      const retained=JSON.stringify(p.serialise());
      p.completeHole(completions.at(-1));p.completeHole(structuredClone(completions.at(-1)));
      recordCheck('Replayed real completion changes no persisted state/reward',()=>assert.equal(JSON.stringify(p.serialise()),retained));
    }
    if(!state.contract) {
      const bit=state.garage.loadout.bit,quoted=p.priceOf(bit),before=snapshot(state);
      report.purchase={itemId:bit,quote:quoted,result:p.purchase(bit),before};
      if(report.purchase.result.ok)recordCheck('Consumable purchase uses actual quote',()=>assert.equal(state.player.money,before.money-quoted));
      report.purchase.after=snapshot(state);
    }
  }
  report.beforeReload=snapshot(state);const saved=p.save();report.saveResult=saved;
  sim?.dispose();sim=null;geo?.dispose();geo=null;p.dispose();p=null;
  const restored=createGameState(),restoredBus=createBus();p=createProgression({state:restored,bus:restoredBus,rand:makeRandom(opts.seed)});await p.init();
  report.afterReload=snapshot(restored);
  recordCheck('Reload preserves earned money/XP, inventory and completed-hole statistics',()=>{
    for(const key of ['money','xp','level','stats','owned','condition','rigId','loadout'])assert.deepEqual(report.afterReload[key],report.beforeReload[key],key);
  });
  const rig=getRig('core-rig'),loadout=defaultLoadoutFor('core',18);
  report.coreAffordability={earnedLevel:restored.player.level,earnedXP:restored.player.xp,earnedCash:restored.player.money,
    rigPrice:rig.price,tools:Object.fromEntries(Object.entries(loadout).map(([slot,id])=>[slot,{id,price:getItem(id).price}])),
    attempt:p.purchaseRig(rig.id),statement:'A locked/refused purchase at the earned early-career state is not proof core is economically unreachable. No level18/60 completion claimed.'};
  report.events={money:moneyEvents,xp:xpEvents,jamClearances:jamEvents};
  report.status='OBSERVED';
} catch(e) { report.status='PROBE_ERROR';report.errors.push({message:e.message,stack:e.stack});process.exitCode=1; }
finally {
  try{sim?.dispose();geo?.dispose();p?.dispose();}catch(e){report.errors.push({cleanup:e.message});process.exitCode=1;}
  if(original)Object.defineProperty(globalThis,'localStorage',original);else delete globalThis.localStorage;
  if(originalDocument)Object.defineProperty(globalThis,'document',originalDocument);else delete globalThis.document;
  report.sourceAfter=manifest();report.sourceUnchanged=JSON.stringify(report.sourceBefore)===JSON.stringify(report.sourceAfter);
  if(!report.sourceUnchanged){report.errors.push({message:'Production source changed during probe'});process.exitCode=1;}
  report.finished=new Date().toISOString();fs.mkdirSync(path.dirname(path.resolve(root,opts.out)),{recursive:true});
  fs.writeFileSync(path.resolve(root,opts.out),JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify({status:report.status,checks:report.checks.length,holes:report.holes.map(h=>({depth:h.depth,target:h.target,phase:h.phase,money:h.after.money,xp:h.after.xp})),errors:report.errors,out:opts.out,sourceUnchanged:report.sourceUnchanged}));
}
